import { Dispatch, SetStateAction, useEffect, useRef, useState } from 'react';

export interface UpdateStepTypeProps {
    isValidValue: boolean;
    stepNumber: number;
}
export type UpdateStepType = (props: UpdateStepTypeProps) => void;

export interface UseStepProps {
    isComplete?: boolean;
    setHighestStep: Dispatch<SetStateAction<number>>;
    stepNumber?: number;
    updateStep?: UpdateStepType;
}

export const useStep = (initialStep: number = 1) => {
    const [currentStep, setCurrentStep] = useState<number>(initialStep);
    const [isComplete, setIsComplete] = useState<boolean>(false);
    const [highestStep, setHighestStep] = useState<number>(0);
    const [hasTimeoutRef, setHasTimeoutRef] = useState(false);
    const resetStep = () => setCurrentStep(initialStep);
    const incrementStep = () => setCurrentStep(currentStep + 1);
    const timerRef = useRef({});

    useEffect(() => {
        if (highestStep && currentStep >= highestStep) {
            setIsComplete(true);
        } else {
            setIsComplete(false);
        }
    }, [currentStep]);

    useEffect(() => {
        if (hasTimeoutRef && timerRef?.current) {
            clearTimeout(timerRef.current as ReturnType<typeof setTimeout>);
            setHasTimeoutRef(false);
        }
    }, [hasTimeoutRef]);

    const updateStep: UpdateStepType = ({ stepNumber, isValidValue }) => {
        if (!isValidValue) {
            setCurrentStep(stepNumber);
        } else if (isValidValue && currentStep - stepNumber === 0) {
            incrementStep();
        } else if (isValidValue && currentStep - stepNumber > 1) {
            // Update state to the step currently being updated
            setCurrentStep(stepNumber);
            // Increment after a timeout so components are removed
            timerRef.current = setTimeout(() => {
                setCurrentStep(stepNumber + 1);
                setHasTimeoutRef(true);
            }, 250);
        }
    };

    return {
        currentStep,
        incrementStep,
        isComplete,
        resetStep,
        setCurrentStep,
        setHighestStep,
        updateStep
    };
};
