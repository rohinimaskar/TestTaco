import { useEffect, useState } from 'react';

import { RealObject } from '@tb-core/types';
import { FeedbackTypes } from '@tb-public/components/behavior/contact-form-alt';
import { FeedbackTopics } from '@tb-public/components/contact-us/behavior/select-feeedback-topic';
import { OrderReceive, OrderTypes } from '@tb-public/constants/contact-us';
import { getOptions } from '@tb-public/helpers/contact-us/get-options';
import { Options } from '@tb-public/types';

export interface UseTopicOptionsProps {
    digitalTechnical?: RealObject;
    feedBackType?: string;
    orderPlacementType?: string;
    orderReceive?: string;
    orderRestaurant?: RealObject;
}
export const useTopicOptions: (
    props: UseTopicOptionsProps
) => [Options[], (query: string) => void] = ({
    digitalTechnical = {},
    feedBackType,
    orderPlacementType = '',
    orderReceive,
    orderRestaurant = {}
}) => {
    const [feedbackTopic, setFeedbackTopic] = useState('');
    const [options, setOptions] = useState<Options[]>([]);
    const isComplaint = feedBackType === FeedbackTypes.COMPLAINT;
    const isMobileAppOrWebsite = [
        OrderTypes.MOBILE_APP,
        OrderTypes.WEBSITE
    ].includes(orderPlacementType as OrderTypes);

    useEffect(() => {
        let feedbackOptions = getOptions();

        if (!feedBackType) {
            return setOptions(feedbackOptions);
        }

        if (feedbackTopic === FeedbackTopics.ORDERRESTAURANT) {
            // Complaint options for order, service, or restaurant are different when order is via mobile/web
            if (isComplaint && isMobileAppOrWebsite) {
                feedbackOptions = getOptions(
                    orderRestaurant[
                        orderReceive === OrderReceive.DELIVERY
                            ? 'COMPLAINTDIGITALDELIVERY'
                            : 'COMPLAINTDIGITALPICKUP'
                    ]
                );
            } else if (
                isComplaint &&
                OrderTypes.THIRD_PARTY === orderPlacementType
            ) {
                feedbackOptions = getOptions(
                    orderRestaurant['COMPLAINTTHIRDPARTY']
                );
            } else {
                feedbackOptions = getOptions(orderRestaurant[feedBackType]);
            }
        } else if (feedbackTopic === FeedbackTopics.DIGITALSUPPORT) {
            feedbackOptions = getOptions(
                digitalTechnical[
                    isComplaint && isMobileAppOrWebsite
                        ? orderReceive === OrderReceive.DELIVERY
                            ? 'COMPLAINTDELIVERY'
                            : 'COMPLAINTPICKUP'
                        : feedBackType
                ]
            );
        }

        setOptions(feedbackOptions);
    }, [feedbackTopic, feedBackType, orderPlacementType, orderReceive]);

    return [options, setFeedbackTopic];
};
