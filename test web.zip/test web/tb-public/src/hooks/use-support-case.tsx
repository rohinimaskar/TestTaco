import { RealObject } from '@tb-core/types';
import {
    useTopicOptions,
    UseTopicOptionsProps
} from '@tb-public/hooks/use-topic-options';
import {
    useTopicSubject,
    UseTopicSubjectProps
} from '@tb-public/hooks/use-topic-subject';

export type SupportCase = RealObject;

export const useSupportCase = (
    props: UseTopicSubjectProps & UseTopicOptionsProps
) => {
    const [subjectOptions, feedbackObject, setFeedbackObject] = useTopicSubject(
        props
    );
    const { feedBackType, orderPlacementType, orderReceive } = feedbackObject;
    const [feedbackOptions, setFeedBackTopic] = useTopicOptions({
        feedBackType,
        orderPlacementType,
        orderReceive,
        ...props
    });

    return {
        feedbackObject,
        feedbackOptions,
        setFeedBackTopic,
        setFeedbackObject,
        subjectOptions
    };
};
