import { useEffect, useState } from 'react';

import { RealObject } from '@tb-core/types';
import {
    FeedbackTopic,
    OrderTypes,
    PaymentTopicOptions
} from '@tb-public/constants/contact-us';
import { getOptions } from '@tb-public/helpers/contact-us/get-options';
import { Options } from '@tb-public/types/index.d';

export interface TopicSubjectObject {
    [key: string]: string | undefined;
    experienceResponse?: string;
    feedBackSubject?: string;
    feedBackTopic?: string;
    feedBackType?: string;
    orderPlacementType?: OrderTypes;
}

export interface UseTopicSubjectProps {
    delivery?: string[];
    food?: RealObject;
    mobileApp?: RealObject;
    orderAndPaymentIssues?: RealObject;
    payment?: RealObject;
    pickupOfOrder?: RealObject;
    restaurantEnvironment?: string[];
    rewards?: RealObject;
    serviceStaff?: string[];
    website?: RealObject;
}

export const useTopicSubject: (
    props: UseTopicSubjectProps
) => [Options[], TopicSubjectObject, (props: TopicSubjectObject) => void] = ({
    delivery,
    food,
    orderAndPaymentIssues,
    payment,
    pickupOfOrder,
    restaurantEnvironment,
    rewards,
    serviceStaff
}) => {
    const [feedbackObject, setFeedbackObject] = useState<TopicSubjectObject>({
        experienceResponse: '',
        feedBackSubject: '',
        feedBackTopic: '',
        feedBackType: ''
    });
    const [options, setOptions] = useState<Options[]>([]);
    const feedBackType = feedbackObject?.feedBackType || '';

    const setOptionsIfAvailable = (formOptions?: RealObject) => {
        if (formOptions) {
            setOptions(getOptions(formOptions[feedBackType]));
        }
    };

    useEffect(() => {
        switch (feedbackObject.feedBackSubject) {
            case FeedbackTopic.SERVICE_STAFF:
                return setOptions(getOptions(serviceStaff));
            case FeedbackTopic.FOOD:
                return setOptionsIfAvailable(food);
            case FeedbackTopic.RESTAURANT_ENVIRONMENT:
                return setOptions(getOptions(restaurantEnvironment));
            case FeedbackTopic.PAYMENT:
                const { orderPlacementType } = feedbackObject;

                if (payment) {
                    const orderRestaurantOptions = getOptions(
                        payment[feedBackType]
                    );

                    setOptions(
                        orderPlacementType === OrderTypes.KIOSK
                            ? orderRestaurantOptions.filter(
                                  option =>
                                      option.value !==
                                      PaymentTopicOptions.ACCEPTANCE_OF_COUPONS
                              )
                            : orderRestaurantOptions
                    );
                }

                break;
            case FeedbackTopic.DELIVERY:
                return setOptions(getOptions(delivery));
            case FeedbackTopic.REWARDS:
                return setOptionsIfAvailable(rewards);
            case FeedbackTopic.ORDER_AND_PAYMENT_ISSUES:
                return setOptionsIfAvailable(orderAndPaymentIssues);
            case FeedbackTopic.PICKUP_OF_ORDER:
                return setOptionsIfAvailable(pickupOfOrder);
            default:
                return setOptions(getOptions());
        }
    }, [feedbackObject]);

    return [options, feedbackObject, setFeedbackObject];
};
