import { useContext } from 'react';

import { RealObject } from '@tb-core/types';
import { SupportCaseContext } from '@tb-public/components/contact-us/context/support-case';
import { SupportCase } from '@tb-public/hooks/use-support-case';

const useSupportCaseContext = () => {
    const ctx = useContext<SupportCase | RealObject>(SupportCaseContext);

    if (ctx === undefined) {
        throw new Error(
            'useSupportCaseContext must be within SupportCaseProvider'
        );
    }

    return ctx;
};

export default useSupportCaseContext;
