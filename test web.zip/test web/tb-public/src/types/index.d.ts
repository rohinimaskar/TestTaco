import { ChangeEvent } from 'react';

import { RealObject } from '@tb-core/types';

export enum ComplimentFlowPositions {
    COMPLIMENT = 4,
    FEEDBACKTOPIC = 3
}

export enum ContactFormPositions {
    COMPLIMENTCOMPLAINTFLOW = 3,
    FEEDBACKTYPE = 1,
    GENERALFLOW = 2,
    ORDERTYPE = 2
}

export interface ContactFormProps {
    bannerTitle?: string;
    buttonText?: RealObject;
    cta: string;
    delivery?: string[];
    deliveryOptions?: string[];
    description?: string;
    digitalTechnical?: RealObject;
    digitalTechnicalSupport: RealObject;
    experienceDescription?: string;
    experienceDescriptionGeneral?: string;
    feedbackSubject: RealObject;
    feedbackSubjectComplaint?: string;
    feedbackSubjectCompliment?: string;
    feedbackTopic: RealObject;
    feedbackTopicComplaint?: string;
    feedbackTopicCompliment?: string;
    feedbackType?: RealObject;
    food?: RealObject;
    footerText?: string;
    inputErrors: {
        confirmEmail: string;
        email: string;
        phoneNumber: string;
        zipCode: string;
    };
    inputLabels: RealObject;
    inputs: RealObject;
    labels?: RealObject;
    message: string;
    minDateBoundary?: number;
    mobileApp?: RealObject;
    orderReceiveOptions?: string[];
    orderRestaurant?: RealObject;
    orderRestaurantExperience: RealObject;
    orderType?: string;
    orderTypeOptions: RealObject[];
    payment?: RealObject;
    questions?: RealObject;
    regarding?: string;
    response?: string;
    responses?: RealObject;
    restaurantEnvironment?: string[];
    restaurantLocation?: string;
    restaurantPopupTitle: string;
    rewards?: RealObject;
    serviceStaff?: string[];
    submitButtonText?: string;
    subtitle?: string;
    surveyOrder?: string[];
    thirdPartyOptions?: string[];
    thirdPartySection?: RealObject[];
    title: string;
    titleLine1?: string;
    titleLine2?: string;
    tooltips?: Tooltips;
    typeOfFeedback?: string;
    userInformation?: string;
    visitDateTime?: string;
    website?: RealObject;
    yourExperience?: string;
    timeZone?: string;
}

export enum DigitalComplaintPositions {
    DIGITALRELATEDDESCRIPTION = 7,
    DIGITALRELATEDFOLLOWUP = 9,
    DIGITALRELATEDUSERINFO = 8,
    EXPERIENCE = 6,
    FEEDBACKSUBJECT = 5,
    FEEDBACKTOPIC = 4,
    NONDIGITALDATETIME = 9,
    NONDIGITALDESCRIPTION = 7,
    NONDIGITALFOLLOWUP = 12,
    NONDIGITALLOCATION = 10,
    NONDIGITALRELATEDORDERNUMBER = 8,
    NONDIGITALUSERINFO = 11,
    ORDERRECEIVE = 3
}

export enum DigitalComplimentPositions {
    DESCRIPTION = 5,
    FEEDBACKSUBJECT = 4,
    OPTIONALINPUTS = 6
}

export interface DisplaySections {
    dateTime: boolean;
    description: boolean;
    followUp: boolean;
    location: boolean;
    survey: boolean;
    userInformation: boolean;
}

export interface FlowProps {
    currentStep: number;
    experienceDescription?: string;
    inputErrors: ErrorMessageProps;
    inputLabels: RealObject;
    restaurantLocation?: string;
    restaurantPopupTitle?: string;
    sectionIsOptionalLabel?: string;
    setStoreId: Dispatch<SetStateAction<string>>;
    tooltips?: Tooltips;
    userInformation?: string;
}

export enum GeneralFlowPositions {
    DESCRIPTION = 2,
    OPTIONALINPUTS = 3
}

export interface OnChangeProps {
    event: ChangeEvent<HTMLInputElement | HTMLSelectElement>;
    value?: string;
}

export interface Options {
    children: string;
    disabled?: boolean;
    value: string;
}

export enum RestaurantComplaintPositions {
    DATETIME = 6,
    DESCRIPTION = 5,
    EXPERIENCE = 4,
    FEEDBACKSUBJECT = 3,
    FOlLOWUP = 9,
    LOCATION = 7,
    USERINFO = 8
}

export enum RestaurantComplimentPositions {
    DESCRIPTION = 6,
    EXPERIENCE = 5,
    FEEDBACKSUBJECT = 4,
    OPTIONALINPUTS = 7
}

export enum ThirdPartyComplaintPositons {
    DATETIME = 8,
    DELIVERYSERVICE = 3,
    DESCRIPTION = 7,
    EXPERIENCE = 6,
    FOLLOWUP = 11,
    LOCATION = 9,
    ORDERRECEIVE = 4,
    THIRDPARTYISSUE = 5,
    USERINFO = 10
}

export enum ThirdPartySection {
    DELIVERY_OF_ORDER = 'Delivery of Order',
    FOOD = 'Food'
}

export interface Tooltips {
    orderNumberTooltip?: string;
    personalInfoTooltip?: string;
    placeOrderTooltip?: string;
    storeSearchTooltip?: string;
}
