import { RealObject } from '@tb-core/types';

const defaultOption = [
    {
        children: 'Choose One',
        disabled: true,
        value: ''
    }
];

export const getOptions = (items?: RealObject[] | string[]) => {
    const options =
        items?.map((item: RealObject | string) =>
            typeof item === 'object'
                ? { value: item?.value, children: item?.label }
                : { value: item, children: item }
        ) || [];
    return [...defaultOption, ...options];
};
