import { ReactNode } from 'react';

import { PillCollectionData } from '@tb-core/components/behavior/pill-collection';
import { RealObject } from '@tb-core/types';

export interface PillOption {
    children: ReactNode;
    value: string;
}

const getPill: (content: ReactNode, value: string) => PillCollectionData = (
    content,
    value
) =>
    ({
        content,
        themeOptions: ['brand', 'highlight', 'neutral'],
        value
    } as PillCollectionData);

export const getPillOptions = (options?: PillOption[] | string[]) =>
    options
        ?.map((option: PillOption | string) =>
            typeof option === 'string'
                ? getPill(option, option)
                : getPill(option.children, option.value)
        )
        .filter((option: RealObject) => option?.value) || [];
