import {
    SUBISSUE,
    SUBISSUEFOUR,
    SUBISSUETHREE,
    SUBISSUETWO
} from '@tb-public/constants/contact-us';

interface SetCategoriesProps {
    feedbacktopic: string;
    regarding: string;
    typeoffeedback: string;
    yourexperience: string;
}

const setCategories = ({
    feedbacktopic,
    regarding,
    typeoffeedback,
    yourexperience
}: SetCategoriesProps) => {
    const categories: {
        subissue?: string;
        subissue2?: string;
        subissue3?: string;
        subissue4?: string;
    } = {};

    // @todo replace strings with enums
    // Set the subissues based off the other data provided by the user.
    if (feedbacktopic === 'orderRestaurantExperience') {
        if (typeoffeedback === 'COMPLIMENT') {
            if (regarding === 'Service & Staff') {
                categories.subissue = SUBISSUE.PRAISE;
                if (yourexperience !== 'Speed' && yourexperience !== 'Other') {
                    categories.subissue2 = SUBISSUETWO.EMPLOYEERELATED;
                } else if (yourexperience === 'Speed') {
                    categories.subissue2 = SUBISSUETWO.ESTABLISHMENT;
                }
            } else if (regarding === 'Food') {
                categories.subissue = SUBISSUE.PRODUCT;
            } else if (regarding === 'Restaurant Environment') {
                categories.subissue = SUBISSUE.PRAISE;
                categories.subissue2 = SUBISSUETWO.ESTABLISHMENT;
            } else if (regarding === 'Payment' && yourexperience === 'Other') {
                categories.subissue = SUBISSUE.PRAISE;
            }
        } else if (typeoffeedback === 'COMPLAINT') {
            if (regarding === 'Service & Staff') {
                categories.subissue = SUBISSUE.SERVICE;
                if (yourexperience === 'Speed') {
                    categories.subissue2 = SUBISSUETWO.SPEED;
                } else if (yourexperience !== 'Other') {
                    categories.subissue2 = SUBISSUETWO.EMPLOYEE;
                    categories.subissue3 = SUBISSUETHREE.TEAMMEMBERRELATED;
                    categories.subissue4 = SUBISSUEFOUR.HOSPITALITY;
                }
            } else if (regarding === 'Food') {
                categories.subissue = SUBISSUE.PRODUCT;
            } else if (regarding === 'Restaurant Environment') {
                switch (yourexperience) {
                    case 'Hours of Operation':
                        categories.subissue = SUBISSUE.POLICY;
                        categories.subissue2 = SUBISSUETWO.HOURSOFOPERATION;
                        break;
                    case 'Other':
                        categories.subissue = SUBISSUE.ENVIRONMENT;
                        break;
                    default:
                        categories.subissue = SUBISSUE.FACILITIES;
                }
            } else if (regarding === 'Payment') {
                switch (yourexperience) {
                    case 'Incorrect/Overcharged':
                        categories.subissue = SUBISSUE.STOREPAYMENT;
                        break;
                    case 'Pricing of Product':
                        categories.subissue = SUBISSUE.POLICY;
                        categories.subissue2 = SUBISSUETWO.PRICING;
                        break;
                    case 'Duplicate Charge':
                        categories.subissue = SUBISSUE.STOREPAYMENT;
                        categories.subissue2 = SUBISSUETWO.REFUNDREQUESTED;
                        break;
                    case 'Acceptance of Coupons':
                        categories.subissue = SUBISSUE.POLICY;
                        categories.subissue2 = SUBISSUETWO.COUPONREFUSED;
                        break;
                    case 'Other':
                        categories.subissue = SUBISSUE.POLICY;
                        break;
                }
            }
        }
    } else if (feedbacktopic === 'digitalTechnicalSupport') {
        categories.subissue = SUBISSUE.DIGITAL;
        if (typeoffeedback === 'COMPLIMENT') {
            if (regarding === 'Rewards' && yourexperience === 'Other') {
                categories.subissue2 = SUBISSUETWO.OFFERSREWARDS;
            } else if (regarding === 'Delivery Services') {
                categories.subissue2 = SUBISSUETWO.DELIVERYSERVICES;
            }
        } else if (typeoffeedback === 'COMPLAINT') {
            if (regarding === 'Mobile App') {
                switch (yourexperience) {
                    case 'Username/Password':
                        categories.subissue2 = SUBISSUETWO.TECHISSUES;
                        categories.subissue3 = SUBISSUETHREE.PASSWORDRESET;
                        break;
                    case 'Account Details':
                        categories.subissue2 = SUBISSUETWO.TECHISSUES;
                        categories.subissue3 = SUBISSUETHREE.SIGNINISSUES;
                        break;
                    case 'Offers':
                        categories.subissue2 = SUBISSUETWO.OFFERSREWARDS;
                        break;
                    case 'Order Not Received By Store':
                        categories.subissue2 = SUBISSUETWO.STORERELATED;
                        categories.subissue3 = SUBISSUETHREE.NEVERRECEIVEDORDER;
                        break;
                    case 'Payment Error':
                        categories.subissue2 = SUBISSUETWO.TECHISSUES;
                        categories.subissue3 = SUBISSUETHREE.PAYMENTISSUE;
                        break;
                    case 'App Performance':
                        categories.subissue2 = SUBISSUETWO.TECHISSUES;
                        break;
                }
            } else if (regarding === 'Rewards') {
                switch (yourexperience) {
                    case 'Missing Points':
                        typeoffeedback = 'INQUIRY';
                        categories.subissue2 = SUBISSUETWO.OFFERSREWARDS;
                        categories.subissue3 = SUBISSUETHREE.MISSINGPOINTS;
                        break;
                    case 'Missing Reward':
                        typeoffeedback = 'INQUIRY';
                        categories.subissue2 = SUBISSUETWO.OFFERSREWARDS;
                        categories.subissue3 = SUBISSUETHREE.MISSINGOFFER;
                        break;
                    case 'Challenge':
                        categories.subissue2 = SUBISSUETWO.OFFERSREWARDS;
                        categories.subissue3 = SUBISSUETHREE.CHALLENGEPROMO;
                        break;
                    case 'Other':
                        typeoffeedback = 'INQUIRY';
                        categories.subissue2 = SUBISSUETWO.OFFERSREWARDS;
                        break;
                }
            } else if (regarding === 'Website') {
                switch (yourexperience) {
                    case 'Username/Password':
                    case 'Account Details':
                        categories.subissue2 = SUBISSUETWO.TECHISSUES;
                        categories.subissue3 = SUBISSUETHREE.SIGNINISSUES;
                        break;
                    case 'Order Not Received By Store':
                        categories.subissue2 = SUBISSUETWO.STORERELATED;
                        categories.subissue3 = SUBISSUETHREE.NEVERRECEIVEDORDER;
                        break;
                    case 'Payment Error':
                        categories.subissue2 = SUBISSUETWO.TECHISSUES;
                        categories.subissue3 = SUBISSUETHREE.PAYMENTISSUE;
                        break;
                    case 'Website Performance':
                        categories.subissue2 = SUBISSUETWO.TECHISSUES;
                        categories.subissue3 = SUBISSUETHREE.WEBSITE;
                        break;
                }
            } else if (regarding === 'Delivery Services') {
                categories.subissue2 = SUBISSUETWO.DELIVERYSERVICES;
            }
        }
    }

    return { categories, typeoffeedback };
};

export default setCategories;
