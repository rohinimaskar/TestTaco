import { PageProviderProps } from '@tb-core/components/context/webpage';
import { getServerSidePropsInit } from '@tb-core/next/server-side-props-hooks/get-page-props-init';
import DefaultPage from '@tb-public/components/container/default-page';

export const getServerSideProps = getServerSidePropsInit({});

const History = (props: PageProviderProps) => <DefaultPage {...props} />;

export default History;
