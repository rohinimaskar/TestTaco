export { default } from '@tb-core/next/api/loyalty-activate-user';
