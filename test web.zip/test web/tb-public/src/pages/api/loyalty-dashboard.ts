export { default } from '@tb-core/next/api/loyalty/v1/dashboard';
