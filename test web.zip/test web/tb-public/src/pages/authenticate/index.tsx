import { PageContextProps } from '@tb-core/components/context/webpage';
import { getServerSidePropsInit } from '@tb-core/next/server-side-props-hooks/get-page-props-init';
import AuthenticatePage from '@tb-public/components/container/authenticate-page';

export const getServerSideProps = getServerSidePropsInit({});

const Authenticate = (props: PageContextProps) => (
    <AuthenticatePage {...props} />
);

export default Authenticate;
