import { PageProviderProps } from '@tb-core/components/context/webpage';
import { getServerSidePropsInit } from '@tb-core/next/server-side-props-hooks/get-page-props-init';
import FranchisePage from '@tb-public/components/container/franchise-page';

export const getServerSideProps = getServerSidePropsInit({ useRawUrl: true });

const FranchiseWebpageSubPage = (props: PageProviderProps) => (
    <FranchisePage {...props} />
);

export default FranchiseWebpageSubPage;
