import { PageProviderProps } from '@tb-core/components/context/webpage';
import { getServerSidePropsInit } from '@tb-core/next/server-side-props-hooks/get-page-props-init';
import FranchisePage from '@tb-public/components/container/franchise-page';

export const getServerSideProps = getServerSidePropsInit({});

const Franchise = (props: PageProviderProps) => <FranchisePage {...props} />;

export default Franchise;
