import '@tb-core/styles/base.scss';
import '@tb-public/styles/styles.scss';

export { default } from '@tb-core/next/pages/_app_legacy';
