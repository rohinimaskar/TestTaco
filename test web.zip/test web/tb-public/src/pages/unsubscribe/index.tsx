import GlobalHeader from '@tb-core/components/container/headers/global-header';
import PageProvider, {
    PageProviderProps
} from '@tb-core/components/context/webpage';
import WebpageLayout from '@tb-core/components/layout/webpage';
import BottomBody from '@tb-core/components/regions/bottom-body';
import DocumentHeadRegion from '@tb-core/components/regions/document-head';
import FooterRegion from '@tb-core/components/regions/footer';
import LeftAsideRegion from '@tb-core/components/regions/left-aside';
import TopBody from '@tb-core/components/regions/top-body';
import { getServerSidePropsInit } from '@tb-core/next/server-side-props-hooks/get-page-props-init';
import UnsubscribeMain from '@tb-public/components/container/unsubscribe-main';

export const getServerSideProps = getServerSidePropsInit({});

const UnsubscribePage = (props: PageProviderProps) => (
    <PageProvider {...props}>
        <WebpageLayout
            regions={{
                bottomBody: <BottomBody />,
                footer: <FooterRegion />,
                head: <DocumentHeadRegion />,
                header: <GlobalHeader />,
                leftAside: <LeftAsideRegion />,
                main: <UnsubscribeMain />,
                topBody: <TopBody inlineSvgs={['icons.svg']} />
            }}
        />
    </PageProvider>
);

export default UnsubscribePage;
