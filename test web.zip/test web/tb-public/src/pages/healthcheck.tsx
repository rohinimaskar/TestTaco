// Used only for AWS container health-check
export default () => <>The app is healthy!</>;
