export { default, getServerSideProps } from '@tb-public/pages/newsroom/[slug]';
