import { PageProviderProps } from '@tb-core/components/context/webpage';
import { getServerSidePropsInit } from '@tb-core/next/server-side-props-hooks/get-page-props-init';
import InfoPage from '@tb-public/components/container/info-page';

export const getServerSideProps = getServerSidePropsInit({ useRawUrl: true });

const InfoWebpageSubPage = (props: PageProviderProps) => (
    <InfoPage {...props} />
);

export default InfoWebpageSubPage;
