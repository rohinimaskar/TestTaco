import GlobalHeader from '@tb-core/components/container/headers/global-header';
import LocationModal from '@tb-core/components/container/location-modal';
import LoyaltyModals from '@tb-core/components/container/loyalty-modals';
import PageProvider, {
    PageProviderProps
} from '@tb-core/components/context/webpage';
import WebpageLayout from '@tb-core/components/layout/webpage';
import BottomBody from '@tb-core/components/regions/bottom-body';
import DocumentHeadRegion from '@tb-core/components/regions/document-head';
import FooterRegion from '@tb-core/components/regions/footer';
import LeftAsideRegion from '@tb-core/components/regions/left-aside';
import LoyaltyAsideRegion from '@tb-core/components/regions/loyalty-aside';
import TopBody from '@tb-core/components/regions/top-body';
import IntlPollyfillSnippet from '@tb-core/components/resource/pollyfills';
import { getServerSidePropsInit } from '@tb-core/next/server-side-props-hooks/get-page-props-init';
import ContactMain from '@tb-public/components/container/contact-main';
import { useWebview } from '@tb-public/hooks/use-webview';

export const getServerSideProps = getServerSidePropsInit({});

const ContactUsPage = (props: PageProviderProps) => {
    const { generic } = props.content.pageData.topicMeta;

    const { isLayoutReady } = useWebview();

    return (
        <PageProvider {...props}>
            {isLayoutReady ? (
                <WebpageLayout
                    regions={{
                        bottomBody: (
                            <BottomBody>
                                <LocationModal
                                    headerText={generic?.restaurantPopupTitle}
                                    selectButtonText={generic?.selectButtonText}
                                />
                                <LoyaltyModals />
                            </BottomBody>
                        ),
                        footer: <FooterRegion />,
                        head: (
                            <DocumentHeadRegion>
                                <IntlPollyfillSnippet />
                            </DocumentHeadRegion>
                        ),
                        header: <GlobalHeader />,
                        leftAside: <LeftAsideRegion />,
                        main: <ContactMain />,
                        rightAside: <LoyaltyAsideRegion />,
                        topBody: <TopBody inlineSvgs={['icons.svg']} />
                    }}
                />
            ) : null}
        </PageProvider>
    );
};

export default ContactUsPage;
