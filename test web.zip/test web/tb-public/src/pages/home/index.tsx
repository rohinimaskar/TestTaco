import SVG from 'react-inlinesvg';

import PageProvider from '@tb-core/components/context/page';
import withNextConfig from '@tb-core/components/hoc/with-next-config';
import GlobalLayout from '@tb-core/components/layout/global';
import { s3AssetPath } from '@tb-core/helpers/contentful/s3-asset-path';
import { assetPath } from '@tb-core/helpers/next-env';
import { ContentfulPageProps } from '@tb-core/types/contentful';
import MainRegion from '@tb-public/components/container/main';
import PageLayout from '@tb-public/components/layout/page';

// Our GetServerSideProps page hook.
export { getServerSideProps } from '@tb-core/next/server-side-props-hooks/get-page-props';

// @deprecated to be removed later, this is the old homepage
const Index = (props: ContentfulPageProps) => (
    <PageProvider {...props}>
        <GlobalLayout>
            {props.pageData?.icons.map((iconsUrl: string, i: number) => (
                <SVG
                    key={i}
                    src={
                        assetPath + s3AssetPath('/_static/web/icons/', iconsUrl)
                    }
                    uniquifyIDs={false}
                />
            ))}
        </GlobalLayout>
        <PageLayout MainRegion={MainRegion as any} />
    </PageProvider>
);

export default withNextConfig(Index);
