import GlobalHeader from '@tb-core/components/container/headers/global-header';
import LoyaltyModals from '@tb-core/components/container/loyalty-modals';
import PageProvider, {
    PageContextProps
} from '@tb-core/components/context/webpage';
import WebpageLayout from '@tb-core/components/layout/webpage';
import BottomBody from '@tb-core/components/regions/bottom-body';
import DocumentHeadRegion from '@tb-core/components/regions/document-head';
import FooterRegion from '@tb-core/components/regions/footer';
import LeftAsideRegion from '@tb-core/components/regions/left-aside';
import LoyaltyAsideRegion from '@tb-core/components/regions/loyalty-aside';
import TopBody from '@tb-core/components/regions/top-body';
import { ContentfulPageModel } from '@tb-core/helpers/contentful/page-props-util';
import { getServerSidePropsInit } from '@tb-core/next/server-side-props-hooks/get-page-props-init';
import Article from '@tb-public/components/styled/article';

// Our GetServerSideProps page hook.
export const getServerSideProps = getServerSidePropsInit({
    pageModel: ContentfulPageModel.ARTICLE
});

// This is to allow for content author to test out multiple experiences of the homepage
const ArticlePage = (props: PageContextProps) => (
    <PageProvider {...props}>
        <WebpageLayout
            regions={{
                bottomBody: (
                    <BottomBody>
                        <LoyaltyModals />
                    </BottomBody>
                ),
                footer: <FooterRegion />,
                head: <DocumentHeadRegion />,
                header: <GlobalHeader />,
                leftAside: <LeftAsideRegion />,
                main: <Article />,
                rightAside: <LoyaltyAsideRegion />,
                topBody: <TopBody />
            }}
        />
    </PageProvider>
);

export default ArticlePage;
