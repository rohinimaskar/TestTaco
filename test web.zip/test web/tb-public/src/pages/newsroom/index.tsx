import GlobalHeader from '@tb-core/components/container/headers/global-header';
import LoyaltyModals from '@tb-core/components/container/loyalty-modals';
import PageProvider, {
    PageContextProps
} from '@tb-core/components/context/webpage';
import WebpageLayout from '@tb-core/components/layout/webpage';
import BottomBody from '@tb-core/components/regions/bottom-body';
import DocumentHeadRegion from '@tb-core/components/regions/document-head';
import FooterRegion from '@tb-core/components/regions/footer';
import LeftAsideRegion from '@tb-core/components/regions/left-aside';
import LoyaltyAsideRegion from '@tb-core/components/regions/loyalty-aside';
import TopBody from '@tb-core/components/regions/top-body';
import { ContentfulPageModel } from '@tb-core/helpers/contentful/page-props-util';
import { getServerSidePropsInit } from '@tb-core/next/server-side-props-hooks/get-page-props-init';
import ArticleList from '@tb-public/components/styled/article-list';

// TODO: This is a new Query style for getting a listing page
export const getServerSideProps = getServerSidePropsInit({
    enableArticleIndex: true,
    pageModel: ContentfulPageModel.WEBPAGE
});

// This is to allow for content author to test out multiple experiences of the homepage
const ArticleIndex = (props: PageContextProps) => (
    <PageProvider {...props}>
        <WebpageLayout
            regions={{
                bottomBody: (
                    <BottomBody>
                        <LoyaltyModals />
                    </BottomBody>
                ),
                footer: <FooterRegion />,
                head: <DocumentHeadRegion />,
                header: <GlobalHeader />,
                leftAside: <LeftAsideRegion />,
                main: <ArticleList />,
                rightAside: <LoyaltyAsideRegion />,
                topBody: <TopBody />
            }}
        />
    </PageProvider>
);

export default ArticleIndex;
