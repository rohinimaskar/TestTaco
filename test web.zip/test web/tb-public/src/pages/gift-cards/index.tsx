import MiniCartModal from '@tb-core/components/composites/mini-cart-modal';
import CheckGiftCardBalanceModal from '@tb-core/components/container/check-gift-card-balance-modal';
import ContentModuleMain from '@tb-core/components/container/content-module-main';
import GlobalHeader from '@tb-core/components/container/headers/global-header';
import LoyaltyModals from '@tb-core/components/container/loyalty-modals';
import PageProvider, {
    PageProviderProps
} from '@tb-core/components/context/webpage';
import WebpageLayout from '@tb-core/components/layout/webpage';
import BottomBody from '@tb-core/components/regions/bottom-body';
import DocumentHeadRegion from '@tb-core/components/regions/document-head';
import FooterRegion from '@tb-core/components/regions/footer';
import LeftAsideRegion from '@tb-core/components/regions/left-aside';
import LoyaltyAsideRegion from '@tb-core/components/regions/loyalty-aside';
import TopBody from '@tb-core/components/regions/top-body';
import { getServerSidePropsInit } from '@tb-core/next/server-side-props-hooks/get-page-props-init';
import { useWebview } from '@tb-public/hooks/use-webview';

export const getServerSideProps = getServerSidePropsInit({});

const GiftCardWebpageLanding = (props: PageProviderProps) => {
    const { isLayoutReady } = useWebview();

    return (
        <PageProvider {...props}>
            {isLayoutReady ? (
                <WebpageLayout
                    regions={{
                        bottomBody: (
                            <BottomBody>
                                <CheckGiftCardBalanceModal />
                                <MiniCartModal />
                                <LoyaltyModals />
                            </BottomBody>
                        ),
                        footer: <FooterRegion />,
                        head: <DocumentHeadRegion />,
                        header: <GlobalHeader />,
                        leftAside: <LeftAsideRegion />,
                        main: <ContentModuleMain />,
                        rightAside: <LoyaltyAsideRegion />,
                        topBody: (
                            <TopBody
                                inlineSvgs={props.content.pageData?.icons}
                            />
                        )
                    }}
                />
            ) : null}
        </PageProvider>
    );
};

export default GiftCardWebpageLanding;
