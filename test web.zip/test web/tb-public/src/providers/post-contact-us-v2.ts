import { datadogLogs } from '@datadog/browser-logs';
import { dataDogJSON } from '@tb-core/helpers/analytics/data-dog/json';
import Fetch from '@tb-core/helpers/fetch';
import { getFormValues } from '@tb-core/helpers/form/get-form-values';
import { tbApiHost } from '@tb-core/helpers/next-env';
import { contactUsSubmitv2Url } from '@tb-core/next/api/urls';
import { SupportFormProps } from '@tb-public/components/contact-us/context/support-case';

// @todo remove subissues after DAAS update is complete
export interface ContactRequestBody {
    city?: string;
    comments: string;
    date?: Date;
    deliveryservice?: string;
    email?: string;
    feedbackresponse?: string;
    feedbacktopic?: string;
    firstname?: string;
    lastname?: string;
    ordernumber?: string;
    orderplacementtype?: string;
    orderreceive?: string;
    phonenumber?: string;
    regarding?: string;
    state?: string;
    storenumber?: string;
    streetaddress?: string;
    subissue2?: string;
    subissue3?: string;
    subissue4?: string;
    subissue?: string;
    thirdpartyissue?: string;
    time?: string;
    typeoffeedback: string;
    yourexperience?: string;
    zipcode?: string;
}

interface PostContactUsProps {
    form: HTMLFormElement;
    storeNumber?: string;
    formState: SupportFormProps;
}

export default async function postContactUs({
    form,
    formState,
    storeNumber
}: PostContactUsProps) {
    const result = form ? getFormValues(form) : null;

    if (!result || Object.keys(result).length === 0) {
        return;
    }

    const {
        city,
        comments,
        date,
        email,
        feedbackresponse,
        state,
        time
    } = result;

    const body: ContactRequestBody = {
        city,
        comments,
        date: date ? new Date(date) : undefined,
        deliveryservice: result['delivery-service'],
        email,
        feedbackresponse,
        firstname: result['first-name'],
        lastname: result['last-name'],
        ordernumber: result['order-number'],
        orderreceive: formState.orderReceive,
        phonenumber: result['phone-number'],
        state,
        storenumber: storeNumber ? storeNumber : undefined,
        streetaddress: result['street-address'],
        time,
        zipcode: result['zip-code'],
        ...formState
    };

    let res: Response;
    try {
        res = await Fetch({
            body: JSON.stringify(body),
            method: 'POST',
            url: tbApiHost + contactUsSubmitv2Url,
            useDefaultHost: false
        });
    } catch (e) {
        console.error('Contact Us API Post request failed!', e);
        // Exception to alpha per Datadog specifications
        const error = dataDogJSON(
            'Contact-Us',
            'Contact-Us API Calls',
            `Contact Us API Post request failed!: ${e}`,
            {}
        );

        datadogLogs.logger.log(
            'Contact Us API Post request failed!',
            error,
            'error'
        );

        return {} as Response;
    }

    if (!res.ok) {
        const resData = {
            requestHttpMethod: 'POST',
            responseCode: res.status,
            status: res.statusText,
            url: res.url
        };

        const error = dataDogJSON(
            'Contact-Us',
            'Contact-Us API Calls',
            'Contact Us request failed!',
            resData
        );

        datadogLogs.logger.log(
            'Contact Us API Post request failed!',
            error,
            'error'
        );

        return {} as Response;
    }

    return res.json() as Promise<Response>;
}
