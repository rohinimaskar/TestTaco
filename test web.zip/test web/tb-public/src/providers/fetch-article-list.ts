import { datadogLogs } from '@datadog/browser-logs';

import Fetch from '@tb-core/helpers/fetch';

import { ArticleListPropsUtilOptions } from '@tb-core/helpers/contentful/article-list-props-util';
import { contentfulArticlesApiUrl } from '@tb-core/next/api/urls';

export default async function fetchArticleList(
    args: ArticleListPropsUtilOptions
) {
    const res = await Fetch({
        body: JSON.stringify({
            args
        }),
        host: '',
        method: 'POST',
        url: contentfulArticlesApiUrl
    });

    if (!res.ok) {
        const errors = await res.json();
        datadogLogs.logger.log('getNewsroomArticlesError', errors, 'error');
        return { articleList: { items: [] } };
    }

    const { articleList } = await res.json();

    return articleList;
}
