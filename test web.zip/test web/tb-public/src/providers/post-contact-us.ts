import { datadogLogs } from '@datadog/browser-logs';
import { dataDogJSON } from '@tb-core/helpers/analytics/data-dog/json';
import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import Fetch from '@tb-core/helpers/fetch';
import { getFormValues } from '@tb-core/helpers/form/get-form-values';
import { contactUsSubmitUrl } from '@tb-core/next/api/urls';
import setCategories from '@tb-public/helpers/contact-us/set-categories';
import { ContactRequestBody } from '@tb-public/providers/post-contact-us-v2';

interface PostContactUsProps {
    form?: HTMLFormElement;
    storeNumber?: string;
}

export default async function postContactUs({
    form,
    storeNumber
}: PostContactUsProps) {
    const result = form ? getFormValues(form) : null;

    if (!result || Object.keys(result).length === 0) {
        return;
    }

    const {
        city,
        comments,
        date,
        email,
        feedbackresponse,
        feedbacktopic,
        orderplacementtype,
        state,
        time
    } = result;
    const { categories, typeoffeedback } = setCategories(result);

    const body: ContactRequestBody = {
        city,
        comments,
        date: date ? new Date(date) : undefined,
        email,
        feedbackresponse,
        feedbacktopic,
        firstname: result['first-name'],
        lastname: result['last-name'],
        orderplacementtype,
        phonenumber: result['phone-number'],
        state,
        storenumber: storeNumber ? storeNumber : undefined,
        streetaddress: result['street-address'],
        time,
        typeoffeedback,
        zipcode: result['zip-code'],
        ...categories
    };

    let res: Response;
    try {
        res = await Fetch({
            body: JSON.stringify(body),
            method: 'POST',
            url: devProxyResolve(contactUsSubmitUrl),
            useDefaultHost: false
        });
    } catch (e) {
        console.error('Contact Us API Post request failed!', e);
        // Exception to alpha per Datadog specifications
        const error = dataDogJSON(
            'Contact-Us',
            'Contact-Us API Calls',
            `Contact Us API Post request failed!: ${e}`,
            {}
        );

        datadogLogs.logger.log(
            'Contact Us API Post request failed!',
            error,
            'error'
        );

        return {} as Response;
    }

    if (!res.ok) {
        const resData = {
            requestHttpMethod: 'POST',
            responseCode: res.status,
            status: res.statusText,
            url: res.url
        };

        const error = dataDogJSON(
            'Contact-Us',
            'Contact-Us API Calls',
            'Contact Us request failed!',
            resData
        );

        datadogLogs.logger.log(
            'Contact Us API Post request failed!',
            error,
            'error'
        );

        return {} as Response;
    }

    return res.json() as Promise<Response>;
}
