import { datadogLogs } from '@datadog/browser-logs';
import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import Fetch, { toError } from '@tb-core/helpers/fetch';
import { giftCardServiceUrl } from '@tb-core/next/api/urls';
import { GiftCardServiceProps } from '@tb-public/components/container/gift-card-service-form';

export default async function postGiftCardService({
    ...data
}: GiftCardServiceProps) {
    const body = {
        p_address: data.address,
        p_cardnumber: data.cardnumber,
        p_city: data.city,
        p_email: data.email,
        p_firstname: data.firstname,
        p_isagree: data.isagree,
        p_lastname: data.lastname,
        p_phonenumber: data.phonenumber,
        p_reasoncomments: data.reasoncomments,
        p_reasonforrequest: data.reasonforrequest,
        p_replymethod: data.replymethod,
        p_securitycode: data.securitycode,
        p_state: data.state,
        p_zipcode: data.zipcode
    };

    let res: Response | undefined;

    try {
        res = await Fetch({
            body: JSON.stringify(body),
            credentials: 'omit',
            headers: {
                'Content-Type': 'application/json'
            },
            host: '',
            method: 'POST',
            url: devProxyResolve(giftCardServiceUrl)
        });
    } catch (e) {
        const error = toError(e);
        datadogLogs.logger.log(
            'Gift Card Service API Post request failed!',
            error,
            'error'
        );
    }

    return {
        status: res?.status
    };
}
