export enum FeedbackTopic {
    'DELIVERY' = 'Delivery',
    'FOOD' = 'Food',
    'ORDER_AND_PAYMENT_ISSUES' = 'Order and Payment Issues',
    'PAYMENT' = 'Payment',
    'PICKUP_OF_ORDER' = 'Pickup of Order',
    'RESTAURANT_ENVIRONMENT' = 'Restaurant Environment',
    'REWARDS' = 'Rewards',
    'SERVICE_STAFF' = 'Service & Staff'
}

export enum OrderTypes {
    'DRIVE_THRU' = 'Drive-Thru',
    'FRONT_COUNTER' = 'Front Counter',
    'KIOSK' = 'Kiosk',
    'MOBILE_APP' = 'Mobile App',
    'THIRD_PARTY' = '3rd Party App',
    'WEBSITE' = 'Website'
}

export enum OrderReceive {
    'DELIVERY' = 'Delivery',
    'PICK_UP' = 'Pick-Up'
}

export enum PaymentTopicOptions {
    'ACCEPTANCE_OF_COUPONS' = 'Acceptance of Coupons'
}

export enum SUBISSUE {
    'DIGITAL' = 'Digital',
    'ENVIRONMENT' = 'Environment',
    'FACILITIES' = 'Facilities',
    'POLICY' = 'Policy',
    'PRAISE' = 'Praise',
    'PRODUCT' = 'Product',
    'SERVICE' = 'Service',
    'STOREPAYMENT' = 'Store Payment'
}

export enum SUBISSUETWO {
    'COUPONREFUSED' = 'Coupon Refused',
    'DELIVERYSERVICES' = 'Delivery Services',
    'EMPLOYEE' = 'Employee',
    'EMPLOYEERELATED' = 'Employee Related',
    'ESTABLISHMENT' = 'Establishment',
    'HOURSOFOPERATION' = 'Hours of Operation',
    'OFFERSREWARDS' = 'Offers/Rewards',
    'PRICING' = 'Pricing',
    'REFUNDREQUESTED' = 'Refund Requested',
    'SPEED' = 'Speed',
    'STORERELATED' = 'Store Related',
    'TECHISSUES' = 'Tech Issues'
}

export enum SUBISSUETHREE {
    'CHALLENGEPROMO' = 'Challenge/Promo',
    'MISSINGOFFER' = 'Missing Offer',
    'MISSINGPOINTS' = 'Missing Points',
    'NEVERRECEIVEDORDER' = 'Never Received Order',
    'PASSWORDRESET' = 'Password Reset',
    'PAYMENTISSUE' = 'Payment Issue',
    'SIGNINISSUES' = 'Sign In Issues',
    'TEAMMEMBERRELATED' = 'Team Member Related',
    'WEBSITE' = 'Website'
}

export enum SUBISSUEFOUR {
    'HOSPITALITY' = 'Hospitality'
}

export enum ThirdPartyIssue {
    'FOOD' = 'Food',
    'OTHER' = 'Other'
}
