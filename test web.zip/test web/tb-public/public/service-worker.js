self.importScripts('https://js.appboycdn.com/web-sdk/3.2/service-worker.js');
