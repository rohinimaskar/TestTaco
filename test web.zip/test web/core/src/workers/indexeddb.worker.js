// The IndexedDB for this worker instance.
let db;

// Create the listener for messages.
addEventListener('message', function({ data }) {
    // Feature detect `self.indexedDB`
    if (!self.indexedDB) {
        postError('IndexedDB is not supported by the client.');
        return;
    }

    // Only set the DB once per worker instance.
    // And only when the message occurs.
    if (!db) {
        // Open access to IndexedDB.
        openIndexedDB(data).addEventListener('success', function() {
            routeAction(data);
        });
    } else {
        routeAction(data);
    }
});

/**
 * Create the transaction object.
 * @param {string} storeName Name of the ObjectStore to access
 * @param {string} type ('readonly'|'readwrite) The type of transaction
 */
function createTransaction(storeName, type) {
    const transaction = db.transaction([storeName], type);

    transaction.onerror = function(event) {
        postError(`Unable to create a transaction for ${storeName}.`);
    };

    return transaction.objectStore(storeName);
}

/**
 * Delete the cart from IndexedDB using the entry ID.
 * @param {MessageEvent.Data} {
 *      @param {string} id The entry ID
 *      @param {string} storeName Name of the ObjectStore to access
 * }
 */
function deleteEntry({ id, storeName }) {
    const request = createTransaction(storeName, 'readwrite');
    const deleteRequest = request.delete(id);

    deleteRequest.onsuccess = function() {
        getAll({ storeName });
    };

    deleteRequest.onerror = function() {
        postError(`Could not delete the entry for ${id}`);
    };
}

/**
 * Delete all cart items from IndexedDB.
 * @param {MessageEvent.Data} {
 *      @param {string} storeName Name of the ObjectStore to access
 * }
 */
function deleteAll({ storeName }) {
    const request = createTransaction(storeName, 'readwrite');
    const cursorRequest = request.openCursor();

    cursorRequest.onsuccess = function(e) {
        const cursor = e.target.result;

        if (cursor) {
            request.delete(cursor.key);
            cursor.continue();
        } else {
            postSuccess();
        }
    };

    cursorRequest.onerror = function() {
        postError(
            'There was an error with the IDBCursorRequest when deleting all items'
        );
    };
}

/**
 * Return the data from the ObjectStore using the entry ID.
 * @param {MessageEvent.Data} {
 *      @param {string} id The entry ID
 *      @param {string} storeName Name of the ObjectStore to access
 * }
 */
function get({ id, storeName }) {
    const objectStore = createTransaction(storeName, 'readonly');
    const getRequest = objectStore.get(id);

    getRequest.onsuccess = function(e) {
        if (!getRequest.result) {
            return postError(`Entry not found for ${id}.`);
        }

        // Send the result.
        postSuccess([getRequest.result]);
    };

    getRequest.onerror = function() {
        postError(`Could not get an entry for ${id}`);
    };
}

/**
 * Return all records from the ObjectStore.
 * @param {MessageEvent.Data} {
 *      @param {string} storeName Name of the ObjectStore to access
 * }
 */
function getAll({ storeName }) {
    const objectStore = createTransaction(storeName, 'readonly');
    const cursorRequest = objectStore.openCursor();
    const records = [];

    cursorRequest.onsuccess = function(e) {
        const cursor = e.target.result;

        if (cursor) {
            // `cursor.value` contains the current record being iterated through.
            records.push(cursor.value);
            // Continue to the next record.
            cursor.continue();
        } else {
            // No more records
            postSuccess(records);
        }
    };

    cursorRequest.onerror = function() {
        postError('There was an error with the IDBCursorRequest');
    };
}

/**
 * Opens a new request to the ObjectStore.
 * @param {MessageEvent.Data} {
 *      @param {string} storeKey The ObjectStore's lookup key.
 *      @param {string} storeName Name of the ObjectStore to access
 * }
 */
function openIndexedDB({ storeKey, storeName }) {
    const request = self.indexedDB.open(storeName);

    request.onerror = function() {
        postError('Unable to access IndexedDB.');
    };

    request.onsuccess = function() {
        db = request.result;
    };

    request.onupgradeneeded = function(event) {
        db = event.target.result;
        db.createObjectStore(storeName, { keyPath: storeKey });
    };

    return request;
}

/**
 * Post an error payload back to the worker listeners.
 * @param {string} message The error message
 */
function postError(message) {
    self.postMessage({
        data: [],
        message,
        status: 0
    });
}

/**
 * Post a message payload back to the worker listeners.
 * @param {Records} data All store records.
 */
function postSuccess(data = []) {
    self.postMessage({
        data,
        message: 'OK',
        status: 1
    });
}

/**
 * Add the data into IndexedDB or update the entry if it is already in the table.
 * @param {MessageEvent.Data} {
 *      @param {object} data
 *      @param {string} storeName Name of the ObjectStore to access
 * }
 */
function put({ data, storeKey, storeName }) {
    const objectStore = createTransaction(storeName, 'readwrite');
    const putRequest = objectStore.put(data, data[storeKey]);

    putRequest.onsuccess = function() {
        getAll({ storeName });
    };

    putRequest.onerror = function() {
        postError('Unable to update the store.');
    };
}

/**
 * Routes message event data based on the action.
 * @param {MessageEvent.Data} {
 *      @param {'delete' | 'get' | 'getAll' | 'put'} action.
 *      @param {MessageEvent.Data} eventData Rest of the message event data.
 * }
 */
function routeAction({ action, ...eventData }) {
    switch (action) {
        // Delete a record.
        case 'delete':
            deleteEntry(eventData);
            break;

        case 'deleteAll':
            deleteAll(eventData);
            break;

        // Retrieve one record.
        case 'get':
            get(eventData);
            break;

        // Retrieve all records.
        case 'getAll':
            getAll(eventData);
            break;

        // Add or update a record.
        case 'put':
            put(eventData);
            break;

        default:
            postError(
                `Type property provided is not valid. Received ${action}.`
            );
    }
}
