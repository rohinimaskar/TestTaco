// Create the listener for messages.
addEventListener('message', function({ data }) {
    const { cart, menu } = data;
    if (cart.length) {
        const cartValidation = () => {
            let productGroup;
            const validCart = cart.map(cartItem => {
                let happierHourPrice;
                for (const { products } of menu.menuProductCategories) {
                    let productMatch = products.find(
                        menuProduct => menuProduct.code === cartItem.plu
                    );
                    if (productMatch) {
                        productGroup = productMatch.primaryCategory;
                    } else {
                        for (const product of products) {
                            if (product.variantOptions) {
                                productMatch = product.variantOptions.find(
                                    variant => variant.code === cartItem.plu
                                );
                                if (productMatch) {
                                    happierHourPrice =
                                        productMatch.happierHourPrice;
                                    productGroup = product.primaryCategory;
                                }
                            }
                        }
                    }
                }
                return {
                    ...cartItem,
                    ...(happierHourPrice && {
                        happierHourPrice
                    }),
                    productGroup
                };
            });
            postSuccess(validCart);
        };
        cartValidation();
    }
});

/**
 * Post a message payload back to the worker listeners.
 * @param {CartSummaryProduct[]} data All valid products.
 */
function postSuccess(data = []) {
    self.postMessage({
        data,
        message: 'OK',
        status: 1
    });
}
