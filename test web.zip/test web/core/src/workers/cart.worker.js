addEventListener('message', function(event) {
    const { id_token, cart, type, endpoint } = event.data;

    switch (type) {
        case 'put': //add or update cart
            put(id_token, cart, endpoint);
            break;
        case 'get': //retrieve cart
            get(id_token, endpoint);
            break;
        case 'delete':
            deleteCart(id_token, endpoint);
            break;
        default:
            self.postMessage({
                status: 0,
                message: 'Type property provided is not valid.'
            });
    }
});

/**
 * Get the cart for a user from DynamoDB
 * @param {string} id_token
 * @param {string} endpoint
 * @example
 *      cartMicroserviceWorker.send({
 *          endpoint: cartUrl,
 *          id_token: ClientSideCart.id_token,
 *          type: 'get'
 *       });
 */
function get(id_token, endpoint) {
    const getRequest = createRequest(id_token, 'GET', endpoint);

    getRequest.onload = function() {
        if (getRequest.status === 200) {
            self.postMessage({
                status: 1,
                message: 'OK',
                data: JSON.parse(this.response)
            });
        } else {
            self.postMessage({
                status: 0,
                message: `Error ${getRequest.status}: ${getRequest.statusText}`
            });
        }
    };

    getRequest.send(null);
}

/**
 * Send the cart object to the API. Will save/update the object.
 * @param {string} id_token
 * @param {object} cart
 * @param {string} endpoint
 * @example
 *      cartMicroserviceWorker.send({
 *          cart: {},
 *          endpoint: cartUrl,
 *          id_token: ClientSideCart.id_token,
 *          type: 'put'
 *       });
 */
function put(id_token, cart, endpoint) {
    const putRequest = createRequest(id_token, 'PUT', endpoint);

    putRequest.onload = function() {
        if (putRequest.status === 200) {
            self.postMessage({ status: 1, message: 'OK' });
        } else {
            self.postMessage({
                status: 0,
                message: `Error ${putRequest.status}: ${putRequest.statusText}`
            });
        }
    };

    putRequest.send(cart);
}

/**
 * Delete the cart object saved on DynamoDB
 * @param {string} id_token
 * @param {string} endpoint
 */
function deleteCart(id_token, endpoint) {
    put(id_token, {}, endpoint);
}

/**
 * Create an XMLHttp Request of the type passed as a parameter
 * Sets the header for the request with the id_token
 * @param {string} id_token
 * @param {string} type
 * @param {string} endpoint
 */
function createRequest(id_token, type, endpoint) {
    const request = new XMLHttpRequest();

    request.open(type, location.origin + endpoint, true);

    request.setRequestHeader('Authorization', `Bearer ${id_token}`);
    request.setRequestHeader(
        'Content-Type',
        'application/x-www-form-urlencoded'
    );

    return request;
}
