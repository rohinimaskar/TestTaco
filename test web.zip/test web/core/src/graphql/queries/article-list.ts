import { ArticleListPropsUtilOptions } from '@tb-core/helpers/contentful/article-list-props-util';

export const articleListQuery = ({
    type = 'newsroom',
    limit = 5,
    skip = 0,
    category = [],
    year,
    date,
    direction,
    slug_not
}: ArticleListPropsUtilOptions) => `
    webpageArticleCollection(
      limit: ${limit}
      skip: ${skip}
      preview: $isPreview
      where: {
        type: "${type}"
        ${
            category.length > 0
                ? `category: { value_in: [${category.map(c => `"${c}"`)}] }`
                : ''
        }
        ${
            year && /([0-9]){4}/.test(year)
                ? `publishedDate_gte: "${new Date(year).toISOString()}"
                publishedDate_lt: "${new Date(
                    String(parseInt(year, 10) + 1)
                ).toISOString()}"`
                : ''
        }
        ${
            date
                ? `publishedDate${direction ? '_' + direction : ''}: "${date}"`
                : ''
        }
        ${slug_not ? `slug_not: "${slug_not}"` : ''}
      }
      order: publishedDate_DESC
    ) {
      total
      items {
        subtitle,
        content {
          json
        },
        featuredImage,
        title,
        publishedDate
        slug
        type
        categoryCollection {
          items {
            label
            value
            articleType
          }
        }
        
      }
    }
  `;
