const categoriesQuerySlug = 'web-cls';

export const categoriesQuery = `
    webpageCollection(limit: 1, preview: $isPreview, where: {
        slug: "${categoriesQuerySlug}"
    }) {
        items {
            contentGroupCollection(limit: 1) {
                items {
                    entriesCollection {
                        items {
                            ...productCategoryFields
                        }
                    }
                }
            }
        }
    }
`;
