/**
 * If modifying this query, please copy changes to
 * `/utils/contentful/helpers/query` to keep the static build script up to date
 * @see {@link /utils/contentful/helpers/query}
 *
 * Note: The entire query string was shifted one tab space to the left in order
 *       to reduce query string size to avoid 400 errors
 */
export const pageQuery = (pageSlug: string) => `
  webpageCollection(
    limit: 1
    preview: $isPreview
    where: { slug: "${pageSlug}" }
  ) {
    items {
      colorTheme {
        ...colorThemeFields
      }
      slug
      seoTitle
      seoDescription
      seoCanonicalUrl
      metaTagsCollection(limit: 10) {
        items {
          ...metaTagFields
        }
      }
      icons
      antiFlicker
      layout {
        topicMetadataCollection(limit: 10) {
          items {
            ...topicMetadataFields
          }
        }
        flashMessageCollection(limit: 2) {
          items {
            type
            entryTitle,
            message {
              json
            }
          }
        }
        pageControls
        mainNavigation {
          linksCollection(limit: 10) {
            items {
              ...linkFields
            }
          }
        }
        footerHero {
          ... footerHeroFields
        }
        utilityNavigation {
          linksCollection(limit: 2) {
            items {
              ...linkFields
            }
          }
        }
        footerNavigation {
          linksCollection(limit: 20) {
            items {
              ...linkFields
            }
          }
        }
        footerNavigationGroupCollection {
          ...footerNavigationGroupFields
        }
        legalNavigation {
          linksCollection(limit: 20) {
            items {
              ...linkFields
            }
          }
        }
        socialMedia {
          socialIconsCollection(limit: 10) {
            items {
              ...linkFields
            }
          }
        }
        footerCopy {
          ...footerCopyFields
        }
        icons
      }
      topicMetadataCollection(limit: 10) {
        items {
          ...topicMetadataFields
        }
      }
      contentGroupCollection(limit: 25) {
        items {
          contentfulMetadata {
            tags {
              id
            }
          }
          wordmark {
            __typename
            ... on Image {
              ...imageFields
            }
            ... on Svg {
              id
            }
          }
          entryTitle,
          title
          subtitle
          horizontalPosition
          contentLink {
            ... on Link {
              label
              url
              gaDataLayerConfig
            }
          }
          daypart
          setToPtZone
          promoStartDateTime
          promoEndDateTime
          description {
            json
            links {
              entries {
                inline {
                  __typename
                  sys {
                    id
                  }
                  ... on OneTrustEmbed {
                    type
                  }
                  ... on Image {
                    ...imageFields
                  }
                  ...iFrameModuleFields
                }
                block {
                  __typename
                  sys {
                    id
                  }
                  ...iFrameModuleFields
                }
              }
            }
          }
          footnoteExcerpt {
            json
          }
          footnote {
            json
            links {
              entries {
                inline {
                  __typename
                  ... on Image {
                    sys {
                      id
                    }
                    ...imageFields
                  }
                }
              }
            }
          }
          fragmentIdentifier
          imageAlt
          imageSrc
          imageSrcset
          backgroundImage {
            ... on Image {
              alt
              src
              srcset
              title
            }
            ... on EmbeddedVideo {
              mediaType
              mobileUrl
              url
            }
          }
          type
          heroSize
          colorTheme {
            ...colorThemeFields
          }
        }
      }
    }
  }
`;
