export const articleCategoriesQuery = (
    categoryValue = '',
    categoryType = ''
) => `
    articleCategoryCollection(
        limit: 20
        preview: $isPreview
        where: {
            ${categoryValue && `value: "${categoryValue}"`}
            ${categoryType && `articleType_contains_all: "${categoryType}"`}
        }
    ) {
        items {
            label
            value
            articleType
        }
    }
`;
