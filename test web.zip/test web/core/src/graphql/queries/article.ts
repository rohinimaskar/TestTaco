/**
 * If modifying this query, please copy changes to
 * `/utils/contentful/helpers/query` to keep the static build script up to date
 * @see {@link /utils/contentful/helpers/query}
 *
 * Note: The entire query string was shifted one tab space to the left in order
 *       to reduce query string size to avoid 400 errors
 */
export const articleQuery = (pageSlug: string) => `
  webpageArticleCollection(
    limit: 1
    preview: $isPreview
    where: { slug: "${pageSlug}" }
  ) {
    items {
      internalName
      slug
      seoTitle
      seoDescription
      seoCanonicalUrl
      type
      publishedDate
      title
      subtitle
      featuredImage
      content {
        json
        links {
          entries {
            inline {
              __typename
              sys {
                id
              }
              ... on Image {
                ...imageFields
              }
              ...iFrameModuleFields
              ...videoPlayerFields
            }
            block {
              __typename
              sys {
                id
              }
              ... on Image {
                ...imageFields
              }
              ...iFrameModuleFields
              ...videoPlayerFields
            }
          }
        }
      }
      boilerplate {
        text {
          json
        }
      }
      legal {
        json
      }
      categoryCollection {
        items {
          label
          value
          articleType
        }
      }
      seoTitle
      seoDescription
      seoCanonicalUrl
      metaTagsCollection(limit: 10) {
        items {
          ...metaTagFields
        }
      }

      topicMetadataCollection(limit: 10) {
        items {
          ...topicMetadataFields
        }
      }
      layout {
        topicMetadataCollection(limit: 10) {
          items {
            ...topicMetadataFields
          }
        }
        flashMessageCollection(limit: 2) {
          items {
            type
            entryTitle,
            message {
              json
            }
          }
        }
        pageControls
        mainNavigation {
          linksCollection(limit: 10) {
            items {
              ...linkFields
            }
          }
        }
        footerNavigation {
          linksCollection(limit: 20) {
            items {
              ...linkFields
            }
          }
        }
        footerHero {
          ... footerHeroFields
        }
        footerNavigationGroupCollection {
          ...footerNavigationGroupFields
        }
        legalNavigation {
          linksCollection(limit: 20) {
            items {
              ...linkFields
            }
          }
        }
        socialMedia {
          socialIconsCollection(limit: 10) {
            items {
              ...linkFields
            }
          }
        }
        footerCopy {
          ...footerCopyFields
        }
        icons
      }
    }
  }
`;
