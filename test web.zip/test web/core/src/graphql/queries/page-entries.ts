export const pageEntries = (pageSlug: string) => `
webpageCollection(limit: 1, preview: $isPreview, where: {
    slug: "${pageSlug}"
}) {
    items {
        contentGroupCollection(limit: 25) {
            items {
                entriesCollection {
                    items {
                        __typename
                        ... on WebpageArticle {
                            slug
                            type
                            publishedDate
                            articleTitle: title
                            subtitle
                            featuredImage
                            content {
                              json
                            }
                        }
                        ...linkFields
                        ...videoPlayerFields
                        ... on Image { src }
                        ... on WebpageContent {
                            entryTitle
                            colorTheme {
                                ... colorThemeFields
                            }
                            wordmark {
                                ...imageFields
                            }
                            subtitle
                            itemTitle: title
                            contentLink {
                                ... on Link {
                                    label
                                    url
                                    gaDataLayerConfig
                                }
                            }
                            description {
                                json
                            }
                            backgroundImage {
                                ...imageFields
                            }
                            entriesCollection(limit: 4) {
                                items {
                                    __typename
                                    ... on Link {
                                        label
                                        linkId
                                        url
                                        gaDataLayerConfig
                                    }
                                }
                            }
                            footnoteExcerpt {
                                json
                            }
                            footnote {
                                json
                            }
                            daypart
                        }
                        ... on Card {
                            graphic {
                                ...imageFields
                            },
                            title {
                                text
                            },
                            message {
                                text
                            }
                        }
                        ... on Faq {
                            question
                            answer {
                                json
                                links {
                                    entries {
                                        inline {
                                            __typename
                                            ... on Image {
                                                sys {
                                                    id
                                                }
                                                ...imageFields
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        ... on FormControl {
                            ...formControlFields
                        }
                    }
                }
            }
        }
    }
}`;
