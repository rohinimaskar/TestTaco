export const colorThemeFields = `
    fragment colorThemeFields on ColorTheme {
        containerBackground
        containerText
        font
        titleText
        legalText
        legalBackground
        primaryButtonBackground
        primaryButtonBorder
        primaryButtonText
        secondaryButtonBackground
        secondaryButtonBorder
        secondaryButtonText
        webLink
        moduleUiActive
        moduleUiInactive
    }
`;
