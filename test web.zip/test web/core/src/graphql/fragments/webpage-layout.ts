export const webpageLayoutFields = `
    fragment webpageLayoutFields on WebpageLayout {
        pageControls
        mainNavigation {
            linksCollection(limit: 10) {
                items {
                    ...linkFields
                }
            }
        }
        footerHero {
            ... footerHeroFields
        }
        footerNavigation {
            linksCollection(limit: 20) {
                items {
                    ...linkFields
                }
            }
        }
        footerNavigationGroupCollection {
            ...footerNavigationGroupFields
        }
        legalNavigation {
            linksCollection(limit: 20) {
                items {
                    ...linkFields
                }
            }
        }
        socialMedia {
            socialIconsCollection(limit: 10) {
                items {
                    ...linkFields
                }
            }
        }
        footerCopy {
           ...footerCopyFields
        }
        icons
    }
`;
