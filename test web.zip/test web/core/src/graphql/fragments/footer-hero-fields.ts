export const footerHeroFields = `
    fragment footerHeroFields on WebpageContent {
      title
      contentLink {
          ... on Link {
              label
              url
              gaDataLayerConfig
          }
      }
      backgroundImage {
          ...imageFields
      }
    }
  `;
