/**
 * If modifying the fragments, please copy changes to
 * `/utils/contentful/helpers/fragments` to keep the static build script up to date
 * @see {@link /utils/contentful/helpers/fragments}
 */
export * from './color-theme-fields';
export * from './embedded-video-fields';
export * from './footer-hero-fields';
export * from './footer-copy-fields';
export * from './footer-navigation-group-fields';
export * from './form-control-fields';
export * from './iframe-module';
export * from './image-fields';
export * from './link-fields';
export * from './metatag-fields';
export * from './product-category-fields';
export * from './topic-metadata-fields';
export * from './video-player-fields';
