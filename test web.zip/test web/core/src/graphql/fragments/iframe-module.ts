export const iFrameModuleFields = `
    fragment iFrameModuleFields on IFrameModule {
    height
    iFrameTitle: title
    mobileHeight
    type
    url
}`;
