export const embeddedVideoFields = `
    fragment embeddedVideo on Video {
        mediaType
        mobileUrl
        url
    }
`;
