export const footerNavigationGroupFields = `
  fragment footerNavigationGroupFields on WebpageLayoutFooterNavigationGroupCollection {
    items {
      title
      linksCollection(limit: 10) {
        items {
        ...linkFields
        }
      }
    }
  }
`;
