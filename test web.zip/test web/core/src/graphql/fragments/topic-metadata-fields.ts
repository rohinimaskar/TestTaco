export const topicMetadataFields = `
    fragment topicMetadataFields on TopicMetadata {
        data
        topic
    }
`;
