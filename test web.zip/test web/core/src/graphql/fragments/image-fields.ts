export const imageFields = `
    fragment imageFields on Image {
        alt
        title
        src
        srcset
        alignment
    }
`;
