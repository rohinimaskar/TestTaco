export const productCategoryFields = `
    fragment productCategoryFields on ProductCategory {
        contentfulMetadata {
            tags {
                id
            }
        }
        label
        hideFromMenu
        graphic {
            ... on Svg {
              id
            }
        }
        seoCanonicalUrl
        seoDescription
        seoFooterDescription {
            json
        }
        seoLocalizedCanonicalUrl
        seoLocalizedDescription
        seoLocalizedFooterDescription {
            json
        }
        seoLocalizedTitle
        seoTitle
        slug
        subtitle
        webImageUrl
    }
`;
