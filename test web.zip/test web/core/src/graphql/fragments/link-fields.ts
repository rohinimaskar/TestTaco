export const linkFields = `
    fragment linkFields on Link {
        label
        url
        gaDataLayerConfig
        graphic {
            __typename
            ... on Image {
                alt
                title
                src
                srcset
            }
            ... on Svg {
                id
            }
            ... on Graphic {
                alt
                title
                graphic {
                    __typename
                    ... on Image {
                        alt
                        title
                        src
                        srcset
                    }
                    ... on Svg {
                        id
                    }
                }
            }
        }
        childLinksCollection (limit: 10) {
            items {
              label
              url
            }
          }
    }
`;
