export const metatagFields = `
    fragment metaTagFields on MetaTag {
        description
        name
        property
    }
`;
