export const footerCopyFields = `
fragment footerCopyFields on WebpageLayoutFooterCopy {
    json
    links {
        entries {
            inline {
                __typename
                sys {
                    id
                }
                ... on Image {
                    ...imageFields
                }
            }
            block {
                __typename
                sys {
                    id
                }
                ... on Image {
                    ...imageFields
                }
            }
        }
    }
}
`;
