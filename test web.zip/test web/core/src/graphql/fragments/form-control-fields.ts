export const formControlFields = `
    fragment formControlFields on FormControl {
        characterLimit
        characterLimitLabel
        controlName
        label
        placeholder
        required
        type
    }
`;
