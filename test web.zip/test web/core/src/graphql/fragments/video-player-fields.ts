export const videoPlayerFields = `
    fragment videoPlayerFields on VideoPlayer {
        __typename
        name
        enableControls
        video {
            __typename
            ... on EmbeddedVideo {
                mediaType
                url
            }
            ... on TwitchEmbed {
                autoplay
                channelId
                collection
                controls
                embedEverything
                errorImage  {
                    ...imageFields
                }
                errorMessage
                fullscreen
                muted
                theme
                timeCodeStart
                videoId
            }
            ... on YouTubeVideo {
                includeChat
                showRelated
                videoId
            }
        }
    }
`;
