import { IngredientCardProps } from '@tb-core/components/composites/products/ingredient-card';
import { webOrigin } from '@tb-core/helpers/next-env';
import { VariantOption } from '@tb-core/types/products';

const IngredientAdapter = ({
    modifierType,
    priceData,
    productImageUrl,
    ...props
}: VariantOption) => {
    const lowerCaseModifier = modifierType ? modifierType.toLowerCase() : '';
    const modifier =
        lowerCaseModifier === 'minus'
            ? 'no'
            : lowerCaseModifier === 'add'
            ? ''
            : lowerCaseModifier;

    return {
        ...props,
        imageSrc: webOrigin + productImageUrl + '_269x269.jpg', // @TODO get this dynamically from the JSON
        modifier,
        price: priceData?.value
    } as IngredientCardProps;
};

export default IngredientAdapter;
