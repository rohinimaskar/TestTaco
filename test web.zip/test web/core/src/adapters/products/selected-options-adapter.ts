import { Option } from '@tb-core/hooks/product/use-customize';
import { CSCItemModifier } from '@tb-core/types/client-side-cart';

type selectedOptionsAdapterProps = (
    selectedOptions?: Array<
        Pick<Option, 'code' | 'includedWithStyle' | 'onTheSide' | 'opt'>
    >
) => CSCItemModifier[];

const selectedOptionToModifier = (
    option: Pick<Option, 'code' | 'includedWithStyle' | 'onTheSide' | 'opt'>
) => ({
    includedWithStyle: option.includedWithStyle || false,
    opt: option.opt,
    // TODO: Look into adding isOnTheSide to all the different options
    ots: !!option.onTheSide,
    plu: option.onTheSide || option.code
});

export const SelectedOptionsAdapter: selectedOptionsAdapterProps = selectedOptions => {
    if (!selectedOptions) {
        return [] as CSCItemModifier[];
    }
    return selectedOptions.map(selectedOptionToModifier);
};
