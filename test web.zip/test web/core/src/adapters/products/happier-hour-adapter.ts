import {
    getDaypartDate,
    getFormattedDate,
    getLocalTime,
    getSubtractedDate
} from '@tb-core/helpers/browser/datetime';
import { DayPart, StoreTime } from '@tb-core/types/stores';

export interface DayPartContent {
    daypart: DayPart;
    endTime: StoreTime;
    startTime: StoreTime;
}

/**
 * This function determines what is the appropriate Happy Hour Banner message to display based
 * on the store local time, happy hour start time, and happy hour end time
 *
 * @param dayPartContent - contains all of the daypart content passed in from the menu OCC call
 * @param timeZone - the time zone of the selected store
 * @return happyHourDescription - the description message of the happy hour banner
 *         happyHourTitle - the title of the happy hour banner
 */
export const HappierHourAdapter = (
    dayPartContent: DayPartContent,
    timeZone: string
) => {
    let happyHourDescription = '';
    let happyHourTitle = '';

    // grab the current time and convert it to store local time
    const currentDate = getLocalTime(new Date(), timeZone);

    // convert 'preset' minutes and 'before end time' minutes to ms
    const presetMinutes = dayPartContent.daypart.presetMinutes * 60000;
    const beforeEndTimeMinutes =
        dayPartContent.daypart.beforeEndTimeMinutes * 60000;

    // grab the start/preset times
    const startTime = getFormattedDate(
        dayPartContent.startTime.formattedHour,
        getDaypartDate(
            dayPartContent.startTime.hour,
            dayPartContent.startTime.minute
        )
    );
    const presetStartTime = getSubtractedDate(startTime, presetMinutes);

    // grab the end/beforeEnd times
    const endTime = getFormattedDate(
        dayPartContent.endTime.formattedHour,
        getDaypartDate(
            dayPartContent.endTime.hour,
            dayPartContent.endTime.minute
        )
    );
    const beforeEndTime = getSubtractedDate(endTime, beforeEndTimeMinutes);

    // check if 'start'/'end' message should be displayed
    if (currentDate >= presetStartTime && currentDate < beforeEndTime) {
        happyHourDescription = dayPartContent.daypart.startMessageDetail;
        happyHourTitle = dayPartContent.daypart.startMessageTitle;
    } else if (currentDate >= beforeEndTime && currentDate <= endTime) {
        happyHourDescription = dayPartContent.daypart.endMessageDetail;
        happyHourTitle = dayPartContent.daypart.endMessageTitle;
    } else {
        // otherwise display 'after' message by default
        happyHourDescription = dayPartContent.daypart.afterMessageDetail;
        happyHourTitle = dayPartContent.daypart.afterMessageTitle;
    }

    return { happyHourDescription, happyHourTitle };
};
