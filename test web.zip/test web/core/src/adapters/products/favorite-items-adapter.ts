import { FavoriteProduct } from '@tb-core/types/favorites';
import { Product } from '@tb-core/types/products';

export const favoriteItemAdapter = (item: Product) => {
    const favoriteProduct = {
        calories: item.calories,
        favProductId: item.code,
        favoriteName: item.name,
        plu: item.code,
        thumbnailURL: item?.images?.[0]?.url
    };

    return favoriteProduct as FavoriteProduct;

    // switch (item.itemType) {
    //     case 'Product':
    //         return {
    //             calories: item.calories,
    //             favProductId: hasModifiers
    //                 ? `${item.code}-${sortedModifierPLUs}`
    //                 : item.code,
    //             favoriteName: hasModifiers ? favoriteName : item.name,
    //             ...(hasModifiers && { modifiers: handleModifiers() }),
    //             plu: item.code
    //             // thumbnailURL: item?.images[0].url
    //         } as FavoriteProduct;

    //     case 'ComboProduct' || 'Combo':
    //         return {
    //             calories: item.calories,
    //             favoriteName
    //         };
    //     default:
    //         '';
    //         break;
    // }
};
