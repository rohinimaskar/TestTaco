import IngredientAdapter from '@tb-core/adapters/products/ingredient-adapter';
import { VariantOption } from '@tb-core/types/products';

const IngredientsAdapter = (list: VariantOption[]) =>
    list?.map((item: VariantOption) => IngredientAdapter(item));

export default IngredientsAdapter;
