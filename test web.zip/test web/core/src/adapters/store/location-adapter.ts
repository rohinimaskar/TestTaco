import { StoreInfo, StoreObj } from '@tb-core/types/stores';

export const locationAdapter: (parameters: StoreObj) => StoreInfo = ({
    address,
    autoCheckIn,
    capabilities,
    currentOnlineAvailable,
    formattedDistance,
    geoPoint,
    storeNumber,
    timeZone,
    todayBusinessHours
}) => {
    const storeInfo: StoreInfo = {
        autoCheckIn,
        capabilities,
        currentOnlineAvailable,
        formattedAddress: {
            address: address?.line1,
            storeCity: address?.town,
            storeState: address?.region.isocode.replace(
                `${address?.country.isocode}-`,
                ''
            ),
            storeZip: address?.postalCode
        },
        formattedDistance,
        geoPoint: { lat: geoPoint.latitude, lng: geoPoint.longitude },
        storeId: storeNumber,
        timeZone,
        todayBusinessHours
    };
    return storeInfo;
};
