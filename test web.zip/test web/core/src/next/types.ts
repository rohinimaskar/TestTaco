import { GraphicProps } from '@tb-core/components/simple/graphic';
import { RichContent } from '@tb-core/components/styled/rich-text/index.d';
import { RealObject } from '@tb-core/types';

export interface PageContentProps {
    antiFlicker?: boolean;
    backLink?: RealObject;
    content: RichContent[];
    description?: RichContent;
    footnoteText?: RichContent;
    layout: RealObject;
    masthead?: RealObject[];
    metaTags?: RealObject;
    name: string;
    path: string;
    seoCanonical: string;
    seoDescription?: string;
    seoTitle: string;
    title?: string;
    titleGraphic?: GraphicProps;
    topicMetadata: RealObject;
}

export interface PageProps {
    pageData: PageContentProps;
}

export interface ServerSideProps<T = RealObject> {
    pageData: T;
}
