import Fetch from '@tb-core/helpers/fetch';

const getStaticPageData = async (isProdContent: boolean, path: string = '') => {
    let pageData = {};

    try {
        const res = await Fetch({
            host: isProdContent
                ? 'https://www.tacobell.com'
                : 'https://www-rel2-q.nonprod.tb-aws.com',
            url: path
        });

        pageData = await res.json();
    } catch {
        console.error('Could not fetch data.');
    }

    return pageData;
};

export default getStaticPageData;
