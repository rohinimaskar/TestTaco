import { GetStaticProps } from 'next';

import WebpageAdapter from '@tb-core/adapters/contentful/graphql/webpage-adapter';
import {
    colorThemeFields,
    footerCopyFields,
    footerHeroFields,
    footerNavigationGroupFields,
    formControlFields,
    iFrameModuleFields,
    imageFields,
    linkFields,
    metatagFields,
    topicMetadataFields,
    videoPlayerFields
} from '@tb-core/graphql/fragments';
import { pageEntries, pageQuery } from '@tb-core/graphql/queries';
import Fetch from '@tb-core/helpers/fetch';
import { interpolate } from '@tb-core/helpers/interpolate';
import { contentfulHost } from '@tb-core/helpers/next-env';
import {
    contentfulEnv,
    contentfulSpace,
    contentfulToken
} from '@tb-core/helpers/next-env';
import { nextContentfulGraphicQlUrl } from '@tb-core/next/api/urls';

const doContentfulQuery = async (body: BodyInit) => {
    const headers = {
        Authorization: `Bearer ${contentfulToken}`,
        'Content-Type': 'application/json'
    };
    const url = interpolate(nextContentfulGraphicQlUrl, {
        environment: contentfulEnv || 'master',
        space: contentfulSpace
    });
    let res: Response;

    try {
        res = await Fetch({
            body,
            credentials: 'omit',
            headers,
            host: '',
            method: 'POST',
            url
        });
    } catch (e) {
        console.error('Contentful GraphQL request error', e);
        return { props: {} };
    }

    if (!res.ok) {
        const errors = (await res.json()).errors;
        console.error('Satic Props - Contentful GraphQL response not ok!', {
            message: res.statusText,
            status: res.status,
            ...(errors &&
                errors.length > 0 && {
                    code: errors[0].extensions?.contentful,
                    ctfMessage: errors[0].message
                })
        });
        return { props: {} };
    }
    const pageData = (await res.json()).data;

    return pageData;
};

const buildContentfulQuery = (
    slug: string,
    isPreview: boolean,
    isEntries: boolean = false
) => {
    let fragments = `
        ${colorThemeFields}
        ${imageFields}
        ${linkFields}
        `;

    fragments += isEntries
        ? `
            ${formControlFields}
            ${videoPlayerFields}
            `
        : `
            ${footerCopyFields}
            ${footerHeroFields}
            ${footerNavigationGroupFields}
            ${iFrameModuleFields}
            ${metatagFields}
            ${topicMetadataFields}
        `;

    // Contentful query
    const query = `
    query ($isPreview: Boolean) {
        ${isEntries ? pageEntries(slug) : pageQuery(slug)}
    }
    ${fragments}
`;
    return JSON.stringify({
        query,
        variables: { isPreview }
    });
};

interface StaticPropsInit {
    slug: string;
}

export const getStaticPropsInit = ({ slug = '/' }: StaticPropsInit) => {
    const getServerSideProps: GetStaticProps = async () => {
        const isPreview = contentfulHost === 'preview.contentful.com';
        const body = buildContentfulQuery(slug, isPreview);
        const entriesBody = buildContentfulQuery(slug, isPreview, true);

        const [pageData, pageEntries] = await Promise.all([
            doContentfulQuery(body),
            doContentfulQuery(entriesBody)
        ]);

        const pageProps = {
            content: WebpageAdapter(
                pageData.webpageCollection,
                pageEntries.webpageCollection
            )
        };

        return {
            props: pageProps
        };
    };
    return getServerSideProps;
};
