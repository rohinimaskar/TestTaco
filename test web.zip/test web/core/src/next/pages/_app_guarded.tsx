import { NextRouter } from 'next/router';
import React from 'react';

import { ProductCategoriesProviderProps } from '@tb-core/components/context/product-categories';
import { PageContextProps } from '@tb-core/components/context/webpage';
import RouteGuard from '@tb-core/components/util/route-guard';

interface ECommerceWebAppProps {
    Component: (
        pageProps: PageContextProps & ProductCategoriesProviderProps
    ) => JSX.Element;
    pageProps: PageContextProps & ProductCategoriesProviderProps;
    router: NextRouter;
}

const ECommerceWebApp = ({ Component, pageProps }: ECommerceWebAppProps) => (
    <RouteGuard>
        <Component {...pageProps} />
    </RouteGuard>
);

export default ECommerceWebApp;
