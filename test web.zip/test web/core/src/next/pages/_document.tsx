import Document, { Head, Html, Main, NextScript } from 'next/document';
import React from 'react';

import GDataLayer from '@tb-core/components/tags/g-data-layer';
import GtmInstall from '@tb-core/components/tags/gtm-install';
import { assetPath, googleTagManagerId } from '@tb-core/helpers/next-env';

export default class ECommerceWebDocument extends Document {
    render() {
        return (
            <Html lang="en">
                <Head>
                    {googleTagManagerId && (
                        <>
                            <GDataLayer />

                            {/* Global Tag Manager */}
                            {/* tslint:disable-next-line: max-line-length */}
                            {/* https://github.com/zeit/next.js/blob/canary/examples/with-google-analytics/pages/_document.js */}
                            <GtmInstall id={googleTagManagerId} />
                        </>
                    )}
                    <link
                        rel="shortcut icon"
                        href={`${assetPath}/_static/icons/favicon.ico`}
                    />
                    <link
                        href={`${assetPath}/_static/styles/global.css`}
                        rel="stylesheet"
                    />
                </Head>
                <body>
                    <Main />
                    <NextScript />
                </body>
            </Html>
        );
    }
}
