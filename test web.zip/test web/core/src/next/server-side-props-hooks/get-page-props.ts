import { GetServerSideProps } from 'next';

import { getPageData } from '@tb-core/helpers/contentful/get-page-data';
import { basePath } from '@tb-core/helpers/next-env';

export const getServerSideProps: GetServerSideProps = async ({ req }) => {
    // Resolve to a base path with the pathname.
    const resolvedUrl = basePath + (req.url || '').split('?')[0];
    // Resolve url prefix, inclusion of a slash or not.
    const urlSlashPrefix =
        /^\//.test(resolvedUrl || '') && resolvedUrl !== '/' ? '' : '/';
    // Drop the trailing slash from the url.
    const pagePath = urlSlashPrefix + resolvedUrl.replace(/\/$/, '');

    return getPageData(pagePath);
};
