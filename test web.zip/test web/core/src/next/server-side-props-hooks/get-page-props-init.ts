import { GetServerSideProps } from 'next';

import { ProductIgnoreList } from '@tb-core/constants/products';
import articleCategoryPropsUtil from '@tb-core/helpers/contentful/article-category-props-util';
import articleListPropsUtil, {
    mapUrlToArticleType
} from '@tb-core/helpers/contentful/article-list-props-util';
import articlePropsUtil from '@tb-core/helpers/contentful/article-props-util';
import menuPropsUtil from '@tb-core/helpers/contentful/menu-props-util';
import pagePropsUtil, {
    ContentfulPageModel,
    PagePropsUtilOptions
} from '@tb-core/helpers/contentful/page-props-util';
import { storeNationalId } from '@tb-core/helpers/next-env';
import customizedProductPropsUtil from '@tb-core/helpers/products/customized-product-props-util';
import productPropsUtil from '@tb-core/helpers/products/product-props-util';
import { getQueryStoreId } from '@tb-core/helpers/store';
import { normalizeProductSSRPort } from '@tb-core/helpers/utils';
import {
    PageHeaderOptions,
    setHeaders
} from '@tb-core/helpers/utils/page-headers';
import { getStore } from '@tb-core/providers/server-side/stores/get-store';
import { Store } from '@tb-core/types';

type PagePropsOptions = PagePropsUtilOptions & {
    enableMenu?: boolean; // indicates if menu should be fetched
    enableArticleIndex?: boolean; // indicate if news index should be fetched
    enableProduct?: boolean; // indicates if product information should be fetched
    enableStore?: boolean; // indicates if store information should be fetched
    headerOptions?: PageHeaderOptions;
};

/*

add optional req headers
determine page "type" - which props util to use - articlee or webpage

*/

export const getServerSidePropsInit = ({
    enableMenu = false,
    enableArticleIndex = false,
    enableProduct = false,
    enableStore = false,
    headerOptions,
    ...options
}: PagePropsOptions) => {
    const getServerSideProps: GetServerSideProps = async ({
        req,
        res,
        ...ctx
    }) => {
        let storeDataPromise: Promise<Store | {}> = Promise.resolve({});
        let storeId;
        const cookieStoreId = req?.cookies?.store_id;
        const customizedProductId = ctx?.query?.customizedProduct;

        if (enableStore && req.url) {
            storeId =
                getQueryStoreId(req.url) || cookieStoreId || storeNationalId;

            // we don't want to get the store data for national store
            if (storeId !== storeNationalId) {
                storeDataPromise = getStore(storeId);
            }

            setHeaders(res, storeId, headerOptions);
        } else {
            setHeaders(res, storeNationalId, headerOptions);
        }

        const ignoreList: string[] = Object.keys(ProductIgnoreList);
        const productSlug = String(ctx?.params?.product);
        const propsUtil =
            options.pageModel &&
            options.pageModel === ContentfulPageModel.ARTICLE
                ? articlePropsUtil
                : pagePropsUtil;

        const pagePropsPromise = propsUtil(req.url, {
            ...options,
            ...ctx
        });

        const articleListPromise = enableArticleIndex
            ? articleListPropsUtil({
                  category: ctx.query.category
                      ? Array.isArray(ctx.query.category)
                          ? ctx.query.category
                          : ctx.query.category.split(',')
                      : undefined,
                  type: mapUrlToArticleType(req.url),
                  year: ctx.query.year && String(ctx.query.year)
              })
            : Promise.resolve({ articles: { items: [] } });

        const articleCategoryPromise = enableArticleIndex
            ? articleCategoryPropsUtil(mapUrlToArticleType(req.url))
            : Promise.resolve({ articleCategories: { items: [] } });

        const menuPropsPromise = enableMenu
            ? menuPropsUtil(String(ctx?.params?.category), storeId)
            : Promise.resolve({ products: [] });
        const host = normalizeProductSSRPort(req.headers.host);

        const productPropsPromise =
            enableProduct && !ignoreList.includes(productSlug)
                ? productPropsUtil(productSlug, host, storeId)
                : Promise.resolve({ product: null });
        const customizedProductPropsPromise =
            typeof customizedProductId === 'string'
                ? customizedProductPropsUtil(customizedProductId, host)
                : Promise.resolve({ customizedProduct: null });

        // Asynchrously Wait all Server Side Promises ( pagePropsPromise contains 3 more Promises )
        const customizedProductProps = await customizedProductPropsPromise;
        const menuProps = await menuPropsPromise;
        const pageProps = await pagePropsPromise;
        const productProps = await productPropsPromise;
        const articleListProps = await articleListPromise;
        const articleCategoryProps = await articleCategoryPromise;
        const storeData = await storeDataPromise;

        if (
            pageProps.notFound ||
            (enableMenu && typeof menuProps.products === 'undefined') ||
            (enableProduct && !productProps.product?.code)
        ) {
            return {
                notFound: true
            };
        }

        return {
            props: {
                ...pageProps,
                ...menuProps,
                ...productProps,
                ...articleListProps,
                ...articleCategoryProps,
                ...customizedProductProps,
                storeData
            }
        };
    };

    return getServerSideProps;
};
