import { NextApiRequest, NextApiResponse } from 'next';

import { toCookieString } from '@tb-core/helpers/cookies';
import NextApi from '@tb-core/helpers/next-api';
import { nextUserUrl } from '@tb-core/next/api/urls';

export default async (nextReq: NextApiRequest, nextRes: NextApiResponse) => {
    const {
        cookies,
        query: { store }
    } = nextReq;
    const headers = {
        // Assemble cookie as a proper cookies string.
        cookie: toCookieString(cookies)
    };

    NextApi({
        headers,
        nextReq,
        nextRes,
        payload: {
            store
        },
        url: nextUserUrl
    });
};
