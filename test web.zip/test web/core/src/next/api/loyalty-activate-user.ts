import { NextApiRequest, NextApiResponse } from 'next';

import NextApi from '@tb-core/helpers/next-api';
import { serviceUrl } from '@tb-core/helpers/next-env';
import { loyaltyActivateUserUrl } from '@tb-core/next/api/urls';

export default async (nextReq: NextApiRequest, nextRes: NextApiResponse) => {
    const { body, method } = nextReq;

    NextApi({
        body,
        method: method as 'POST',
        nextReq,
        nextRes,
        url: serviceUrl + loyaltyActivateUserUrl,
        useDefaultHost: false
    });
};
