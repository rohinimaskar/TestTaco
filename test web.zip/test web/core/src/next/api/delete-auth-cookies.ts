import { NextApiRequest, NextApiResponse } from 'next';

export default async (_nextReq: NextApiRequest, nextRes: NextApiResponse) => {
    nextRes.setHeader('Set-Cookie', [
        'JSESSIONID=deleted; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT',
        'JSESSIONID=deleted; path=/tacobellwebservices; expires=Thu, 01 Jan 1970 00:00:00 GMT',
        'tacobellstorefrontRememberMe=deleted; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT',
        'acceleratorSecureGUID=deleted; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT',
        'id_token=deleted; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT',
        'access_token=deleted; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT',
        'low_token=deleted; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT',
        'refresh_token=deleted; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT',
        'is_first_time_user=deleted; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT',
        'is_first_time_user_loyalty=deleted; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT',
        'TBAuthenticatedState=deleted; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT'
    ]);

    nextRes.status(200).end();
};
