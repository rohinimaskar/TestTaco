import { NextApiRequest, NextApiResponse } from 'next';

import NextApi from '@tb-core/helpers/next-api';
import { tbApiHost } from '@tb-core/helpers/next-env';
import { microserviceCartUrl } from '@tb-core/next/api/urls';

export default async (nextReq: NextApiRequest, nextRes: NextApiResponse) => {
    const {
        cookies: { ['id_token']: idToken },
        body,
        method
    } = nextReq;
    const headers = {
        Authorization: `Bearer ${idToken}`
    };

    NextApi({
        body,
        headers,
        method: method as 'GET' | 'PUT',
        nextReq,
        nextRes,
        url: tbApiHost + microserviceCartUrl,
        useDefaultHost: false
    });
};
