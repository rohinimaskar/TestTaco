import { basePath, routes } from '@tb-core/helpers/next-env';

/**
 * Resolves an HREF by removing the assumed base-path.
 * @param basePath The base-path to be ignored in said href.
 * @param href The HREF to resolve by removing the assumed base-path.
 */
export function basePathResolve(href: string) {
    if (basePath && href && basePath !== href) {
        const newHref = href.replace(basePath, '');
        return newHref;
    }

    // Return empty string as Href since we'll assume Href is intentially left blank.
    return href;
}

/**
 * Get the index of a route within a list of routes.
 * Returns -1 if the route couldn't be found.
 * @param routes A list of routes to find the index of given route.
 * @param routeToFind The route to find the index of from a list of routes.
 */
export function indexOfRoute(routeToFind = '') {
    const index = routes.findIndex((route: string) => {
        if (route.includes('/*')) {
            // Match to everything before the first Astrisk (*) in the route path.
            const routePrefix = route.split('*')[0];
            return routeToFind?.indexOf(routePrefix) === 0;
        }

        return routeToFind === route;
    });

    return index;
}

/**
 * Get the text value from a React element.
 * Returns a string containing the text content.
 * @param rootChild The main React element.
 */
export function getTextFromChildren(rootChild: JSX.Element | string | number) {
    let res = '';
    const getText = (child: JSX.Element | string | number) => {
        if (typeof child === 'string' || typeof child === 'number') {
            res += child;
        } else if (Array.isArray(child)) {
            child.forEach(c => getText(c));
        } else if (child && child.props) {
            const { children } = child.props;

            if (Array.isArray(children)) {
                children.forEach(c => getText(c));
            } else {
                getText(children);
            }
        }
    };

    getText(rootChild);

    return res;
}

/**
 * Normalizes the port in the host URL if it's pointing to localhost.
 * It replaces the port with `:3000`. Otherwise, it returns the host as is.
 *
 * @param {string} host - The host URL that may include a port.
 * @returns {string} - The adjusted host URL with the port replaced if applicable.
 */
export const normalizeProductSSRPort = (host?: string) =>
    host && host.includes('localhost')
        ? host.replace(/(:3[0-9]{3})/, ':3000')
        : host;
