import {
    OrderDetails,
    UseGetCurrentOrderStatusProps
} from '@tb-core/hooks/order/use-get-current-order-status';
import {
    DeliveryStatuses,
    DeliveryStatusText,
    PickUpMethods,
    Statuses,
    SubStatusTextProps
} from '@tb-core/types/order.d';

interface GetSubStatusProps {
    deliverySubStatusText: DeliveryStatusText;
    status: Statuses;
}

interface GetDeliverySubStatusProps {
    deliveryStatus?: DeliveryStatuses;
    deliverySubStatusText: DeliveryStatusText;
}

interface GetSubStatusTextProps {
    orderSubStatusText: SubStatusTextProps;
    pickupMethod: PickUpMethods;
    status: Statuses;
}

type GetOrderSubStatusProps = UseGetCurrentOrderStatusProps &
    GetSubStatusProps &
    OrderDetails;

export const getOrderSubStatus = ({
    deliveryStatus,
    deliverySubStatusText,
    pendingCancellation,
    qrCodeEnabled = false,
    status,
    ...props
}: GetOrderSubStatusProps) => {
    // No sub status text needed if "Cancelled" or "Cancelling"
    if (Statuses.CANCELLED === status) {
        return;
    }

    // Cancelling status is determined by pendingCancellation property
    if (pendingCancellation) {
        return props.orderSubStatusText?.cancelling;
    }

    // Check whether delivery or standard order. Delivery will read deliveryStatus property
    if (deliveryStatus) {
        return getDeliverySubStatus({
            deliveryStatus,
            deliverySubStatusText
        });
    }

    // Defy orders with In-Store and Drive-Thru pick up methods have different text than
    // regular in -store and drive thru orders.It is a Defy store when qrCodeEnabled is true
    return qrCodeEnabled
        ? getDefySubStatusText({
              status,
              ...props
          })
        : getSubStatusText({
              status,
              ...props
          });
};

const getDeliverySubStatus = ({
    deliverySubStatusText,
    deliveryStatus
}: GetDeliverySubStatusProps) => {
    switch (deliveryStatus) {
        case DeliveryStatuses.DELIVERY_CREATED:
        case DeliveryStatuses.DASHER_CONFIRMED:
            return deliverySubStatusText.RECEIVED;
        case DeliveryStatuses.DASHER_ENROUTE_TO_PICKUP:
        case DeliveryStatuses.DASHER_CONFIRMED_STORE_ARRIVAL:
            return deliverySubStatusText.PREPARING;
        case DeliveryStatuses.DASHER_PICKED_UP:
        case DeliveryStatuses.DASHER_ENROUTE_TO_DROPOFF:
        case DeliveryStatuses.DASHER_CONFIRMED_CONSUMER_ARRIVAL:
        case DeliveryStatuses.DELIVERY_ATTEMPTED:
            return deliverySubStatusText.IN_TRANSIT;
        case DeliveryStatuses.DASHER_DROPPED_OFF:
            return deliverySubStatusText.DELIVERED;
    }
};

export const getSubStatusText = ({
    orderSubStatusText,
    pickupMethod,
    status
}: GetSubStatusTextProps) => {
    switch (pickupMethod) {
        case PickUpMethods.Priority_Pickup_Lane:
            return orderSubStatusText?.priorityPickupLane[status];
        case PickUpMethods.Pickup_Shelves:
            return orderSubStatusText?.pickUpShelves[status];
        case PickUpMethods.In_Store:
            return orderSubStatusText?.inside[status];
        case PickUpMethods.Drive_Thru:
            return orderSubStatusText?.driveThru[status];
        default:
            return orderSubStatusText?.defaultText[status];
    }
};

export const getDefySubStatusText = ({
    orderSubStatusText,
    pickupMethod,
    status
}: GetSubStatusTextProps) => {
    switch (pickupMethod) {
        case PickUpMethods.In_Store:
            return orderSubStatusText?.defyInside[status];
        case PickUpMethods.Drive_Thru:
            return orderSubStatusText?.defyDriveThru[status];
        default:
            return orderSubStatusText?.defaultText[status];
    }
};
