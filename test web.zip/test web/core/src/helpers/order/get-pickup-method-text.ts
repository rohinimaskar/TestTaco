import { PickUpMethods, PickUpText } from '@tb-core/types/order.d';

export const getPickUpMethodText = (pickupMethod?: string) => {
    switch (pickupMethod) {
        case PickUpMethods.Drive_Thru:
            return PickUpText.DRIVE_THRU;
        case PickUpMethods.In_Store:
            return PickUpText.INSIDE;
        case PickUpMethods.Pickup_Shelves:
            return PickUpText.PICK_UP_SHELVES;
        case PickUpMethods.Priority_Pickup_Lane:
            return PickUpText.PRIORITY_PICK_UP_LANE;
        default:
            return '';
    }
};
