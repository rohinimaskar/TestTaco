import { RealObject } from '@tb-core/types';

interface GetOrderHistoryStatusTextProps {
    deliveryStatus?: string;
    pendingCancellation: boolean;
    status: string;
    statusText: RealObject;
}

export const getOrderHistoryStatusText = ({
    deliveryStatus,
    pendingCancellation,
    status,
    statusText
}: GetOrderHistoryStatusTextProps) =>
    pendingCancellation
        ? statusText.CANCELLING
        : deliveryStatus
        ? statusText[deliveryStatus]
        : statusText[status];
