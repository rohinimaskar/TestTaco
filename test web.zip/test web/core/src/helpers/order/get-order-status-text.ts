import {
    DeliveryStatuses,
    DeliveryStatusText,
    Statuses,
    StatusText
} from '@tb-core/types/order.d';

interface GetOrderStatus {
    deliveryStatus?: DeliveryStatuses;
    deliveryStatusText: DeliveryStatusText;
    orderStatusText: StatusText;
    pendingCancellation?: boolean;
    status: Statuses;
}

interface GetDeliveryStatusProps {
    deliveryStatus: DeliveryStatuses;
    deliveryStatusText: DeliveryStatusText;
}

export const getOrderStatusText = ({
    deliveryStatus,
    deliveryStatusText,
    orderStatusText,
    pendingCancellation,
    status
}: GetOrderStatus) => {
    if (pendingCancellation) {
        return orderStatusText.CANCELLING;
    }

    return deliveryStatus // Base status message text off of deliveryStatus if it is defined
        ? getDeliveryStatus({
              deliveryStatus,
              deliveryStatusText
          })
        : orderStatusText[status];
};

export const getDeliveryStatus = ({
    deliveryStatus,
    deliveryStatusText
}: GetDeliveryStatusProps) => {
    switch (deliveryStatus) {
        case DeliveryStatuses.DELIVERY_CREATED:
        case DeliveryStatuses.DASHER_CONFIRMED:
            return deliveryStatusText.RECEIVED;
        case DeliveryStatuses.DASHER_ENROUTE_TO_PICKUP:
        case DeliveryStatuses.DASHER_CONFIRMED_STORE_ARRIVAL:
            return deliveryStatusText.PREPARING;
        case DeliveryStatuses.DASHER_PICKED_UP:
        case DeliveryStatuses.DASHER_ENROUTE_TO_DROPOFF:
        case DeliveryStatuses.DASHER_CONFIRMED_CONSUMER_ARRIVAL:
        case DeliveryStatuses.DELIVERY_ATTEMPTED:
            return deliveryStatusText.IN_TRANSIT;
        case DeliveryStatuses.DASHER_DROPPED_OFF:
            return deliveryStatusText.DELIVERED;
        case DeliveryStatuses.DELIVERY_CANCELLED:
            return deliveryStatusText.CANCELLED;
        default:
            return deliveryStatusText.RECEIVED;
    }
};
