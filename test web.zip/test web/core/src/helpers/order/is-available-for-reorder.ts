import { OrderEntry } from '@tb-core/types/order.d';

/**
 * Find if any item in the entries array can be re-ordered
 */
export const isAvailableForReorder = (entries: OrderEntry[]) =>
    !entries.some(
        entry =>
            !entry.availableForReorder ||
            entry.product.isDigitalProduct ||
            entry.product.isPassRedemptionItem
    );
