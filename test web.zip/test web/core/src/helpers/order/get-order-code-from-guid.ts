import { Order } from '@tb-core/types/order';

type GetOrderCodeFromGuidProps = (guid: string, orders?: Order[]) => string;

export const getOrderCodeFromGuid: GetOrderCodeFromGuidProps = (
    guid,
    orders
) => {
    const matchingOrder = orders?.find((order: Order) => order.guid === guid);
    return matchingOrder?.code || '';
};
