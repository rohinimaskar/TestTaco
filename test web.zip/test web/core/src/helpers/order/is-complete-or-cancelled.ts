import { Statuses } from '@tb-core/types/order.d';

export const isCompleteOrCancelled = (status: string) =>
    status === Statuses.ORDER_COMPLETE || status === Statuses.CANCELLED;
