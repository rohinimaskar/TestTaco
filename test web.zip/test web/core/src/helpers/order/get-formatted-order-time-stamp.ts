export const getFormattedOrderTimeStamp = (timeStamp?: string) =>
    timeStamp
        ? new Date(timeStamp).toLocaleString(undefined, {
              day: 'numeric',
              hour: 'numeric',
              minute: 'numeric',
              month: 'numeric',
              weekday: 'long',
              year: undefined
          })
        : '';
