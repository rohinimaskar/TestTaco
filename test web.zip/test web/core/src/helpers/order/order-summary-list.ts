import { CSCItemModifierType } from '@tb-core/constants/client-side-cart';
import { EntryCustomization, ModifierLabels } from '@tb-core/types/order';
import { Product } from '@tb-core/types/products';

export interface SeparatorResultInterface {
    added: string[];
    modified: string[];
    removed: string[];
}

export const separator = (
    data: EntryCustomization[],
    modifierLabels: ModifierLabels,
    grill?: Partial<Product>
): SeparatorResultInterface => {
    const res: SeparatorResultInterface = {
        added: [],
        modified: [],
        removed: []
    };

    if (grill?.description) {
        res.added.push(grill.description);
    }

    data?.forEach(el => {
        // If group is a protein and the modifier type is 'ADD'
        // we want to label the modifier action as 'Modified'
        // because it is a substitute and not adding extra protein
        if (
            el.group === 'proteins' &&
            el.modifier.modifierType === CSCItemModifierType.ADD
        ) {
            res.modified.push(el.modifier.name);
            return;
        }

        switch (el.modifier.modifierType) {
            case CSCItemModifierType.ADD:
                res.added.push(el.modifier.name);
                break;
            case CSCItemModifierType.EASY:
                res.modified.push(`${el.modifier.name} ${modifierLabels.easy}`);
                break;
            case CSCItemModifierType.EXTRA:
                res.modified.push(
                    `${el.modifier.name} ${modifierLabels.extra}`
                );
                break;
            case CSCItemModifierType.MINUS:
                res.removed.push(el.modifier.name);
                break;
            case CSCItemModifierType.SIDE:
                res.modified.push(
                    `${el.modifier.name}  ${modifierLabels.onTheSide}`
                );
                break;
        }
    });

    return res;
};
