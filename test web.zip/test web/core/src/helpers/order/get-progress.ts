import { DeliveryStatuses, Statuses } from '@tb-core/types/order.d';

type GetProgressType = (status?: string, deliveryStatus?: string) => string;

export const getProgress: GetProgressType = (status, deliveryStatus) => {
    if (deliveryStatus) {
        switch (deliveryStatus) {
            case DeliveryStatuses.DELIVERY_CREATED:
            case DeliveryStatuses.DASHER_CONFIRMED:
                return '25';
            case DeliveryStatuses.DASHER_ENROUTE_TO_PICKUP:
            case DeliveryStatuses.DASHER_CONFIRMED_STORE_ARRIVAL:
                return '50';
            case DeliveryStatuses.DASHER_PICKED_UP:
            case DeliveryStatuses.DASHER_ENROUTE_TO_DROPOFF:
            case DeliveryStatuses.DASHER_CONFIRMED_CONSUMER_ARRIVAL:
            case DeliveryStatuses.DELIVERY_ATTEMPTED:
                return '75';
            case DeliveryStatuses.DASHER_DROPPED_OFF:
                return '100';
            default:
                return '0';
        }
    } else {
        switch (status) {
            case Statuses.ORDER_PLACED:
            case Statuses.ORDER_CONFIRMED:
                return '30';
            case Statuses.ORDER_CHECKED_IN:
                return '60';
            case Statuses.ORDER_COMPLETE:
                return '100';
            default:
                return '0';
        }
    }
};
