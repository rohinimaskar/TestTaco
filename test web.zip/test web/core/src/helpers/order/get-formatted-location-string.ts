import { interpolate } from '@tb-core/helpers/interpolate';
import { Address } from '@tb-core/types/order.d';

export const getFormattedLocationString = ({ region, ...address }: Address) => {
    const locationString = '{line1}\n{town}, {region} {postalCode}';

    return interpolate(locationString, {
        region: region.isocodeShort,
        ...address
    });
};
