/**
 *
 * Helper to set pickup method icon based on selectedPickupMethod
 * in sessionStorage
 */
import { PickupMethod, pickupMethodIcons } from '@tb-core/types/location.d';

export const getPickupMethodIcon = (storePickupMethod?: PickupMethod) => {
    if (storePickupMethod && pickupMethodIcons[storePickupMethod]) {
        return pickupMethodIcons[storePickupMethod];
    } else {
        console.error(
            `Can't find icon for unknown pickup method: ${storePickupMethod} - this will also cause Place Order to fail!`
        );
        return undefined;
    }
};
