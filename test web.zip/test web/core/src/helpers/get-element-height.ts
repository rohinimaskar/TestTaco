/**
 * Returns the height of the first instance of an element. Accepts an id or class identifier.
 * @param { identifier }
 */
export default function getElementHeight(identifier: string = '') {
    let offset = 0;
    if (identifier.length && typeof document !== 'undefined') {
        const feaEl: HTMLElement | null = document.querySelector(identifier);
        offset = feaEl !== null ? feaEl.offsetHeight : 0;
    }
    return offset;
}
