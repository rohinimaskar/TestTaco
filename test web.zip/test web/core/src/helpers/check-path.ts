/**
 *
 *
 * Checks current url path
 *
 * @param {path} - path of current page Url
 * @returns {boolean}
 */

import { useRouter } from 'next/router';

export const checkPath = (path: string | string[]) => {
    const { asPath } = useRouter();

    return typeof path === 'string' ? path === asPath : path.includes(asPath);
};
