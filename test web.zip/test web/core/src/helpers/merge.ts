import { RealObject } from '@tb-core/types';
// The worker
// Things to implement (research):
//  1. determine whether object is Array or Object Literal,
//  2. deep clone/copy of arrays & object literals,
//  3. looping through objects using "for in"
// Note: you'll need to loop through arrays too.
// https://blog.logrocket.com/4-different-techniques-for-copying-objects-in-javascript-511e422ceb1e/

type ModifyObjectFunction<T> = (obj: T) => void;

export default function merge<T>(
    obj: RealObject,
    fn: ModifyObjectFunction<T>,
    useRecursive = false
): T {
    // Deep clone baseState (simple version)...
    if (!useRecursive) {
        const stringifiedDraftObject = JSON.stringify(obj);
        const parsedDraftObject = stringifiedDraftObject
            ? JSON.parse(stringifiedDraftObject)
            : {};

        fn(parsedDraftObject);

        return parsedDraftObject;
    }

    // Deep clone baseState (recursive version)...
    const draftState = deep(obj);

    // Call state manipulator w/ the draftState as an argument.
    fn(draftState);

    // Returned draftState is assumed to have been manipulated, and when returned is
    // considered the nextState.
    return draftState;
}

function deep(obj: any) {
    if (typeof obj !== 'object' || obj === null) {
        return obj;
    }

    if (Array.isArray(obj)) {
        return deepArray(obj);
    }

    return deepObject(obj);
}

function deepObject(source: any) {
    const result: { [key: string]: any } = {};

    Object.keys(source).forEach(key => {
        const value = source[key];
        result[key] = deep(value);
    }, {});

    return result;
}

function deepArray(collection: any[]): any[] {
    return collection.splice(0);
}
