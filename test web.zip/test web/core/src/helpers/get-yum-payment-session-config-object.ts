import { datadogLogs } from '@datadog/browser-logs';
import { devProxy } from '@tb-core/helpers/browser/dev-proxy';
import { getAccessToken } from '@tb-core/helpers/client/auth';
import Fetch, { toError } from '@tb-core/helpers/fetch';
import { yumPaymentSessionConfigUrl } from '@tb-core/next/api/urls';
import {
    YumPaymentMethodType,
    YumPaymentSessionConfigResponse
} from '@tb-core/types/checkout/yum-payment';
import { tbApiHost } from './next-env';

export interface YumPaymentSessionConfigPayload {
    customerId: string;
    deviceId?: string;
    emailId?: string;
    isGuest: boolean;
    language: string;
    paymentMethods: YumPaymentMethodType[];
}

/**
 * Get Yum Payment Session Config Object
 */
export async function getYumPaymentSessionConfigObject(
    sessionConfigPayload: YumPaymentSessionConfigPayload,
    guestAccessToken: string // guestAccessToken: will be empty string if Logged in User
) {
    let res: Response;
    const bearerToken = guestAccessToken
        ? guestAccessToken
        : await getAccessToken();

    try {
        res = await Fetch({
            body: JSON.stringify(sessionConfigPayload),
            headers: {
                Authorization: `Bearer ${bearerToken}`,
                'Content-Type': 'application/json'
            },
            method: 'POST',
            ...devProxy({ host: tbApiHost, url: yumPaymentSessionConfigUrl })
        });
    } catch (e) {
        const error = toError(e);
        console.error('Get Yum Payment Session Config Object Failed', error);
        datadogLogs.logger.log(
            'getYumPaymentSessionConfigObject',
            error,
            'error'
        );
        return { success: false } as YumPaymentSessionConfigResponse;
    }

    if (!res.ok) {
        const errors = await res.json();
        datadogLogs.logger.log('getYumPaymentConfigObject', errors, 'error');
        return { ...errors, success: false } as YumPaymentSessionConfigResponse;
    }

    const parsedResult = await res.json();

    return {
        ...parsedResult,
        success: true
    } as Promise<YumPaymentSessionConfigResponse>;
}
