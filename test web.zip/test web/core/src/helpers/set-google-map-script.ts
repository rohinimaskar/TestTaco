import { datadogLogs } from '@datadog/browser-logs';

import { webOrigin } from '@tb-core/helpers/next-env';

/**
 * Checks for existing google maps script
 * and if the script doesn't exist create it.
 *
 * @param googleMapsUrl
 * @returns
 */

export const setGoogleMapScript = ({
    googleMapsUrl,
    loadedHandler
}: {
    googleMapsUrl: string;
    loadedHandler?: () => void;
}) => {
    if (googleMapsUrl === '') {
        console.error('googleMapsUrl blank string');
        return;
    }
    try {
        const existingScript = document.getElementById('googleMaps');
        const mapsUrl = webOrigin + googleMapsUrl;

        // If Google maps script doesn't exist, create it.
        if (!existingScript) {
            const googleMapScript = document.createElement('script');
            googleMapScript.src = mapsUrl;
            googleMapScript.id = 'googleMaps';
            googleMapScript.async = true;
            googleMapScript.defer = true;
            document.body.appendChild(googleMapScript);

            return googleMapScript;
        } else {
            loadedHandler?.();
        }
        return existingScript;
    } catch (error) {
        const errorMsg = JSON.stringify({
            error: `Error creating google map script, ${error}`
        });
        datadogLogs.logger.log(
            'Setting google map script failed',
            { errorMsg },
            'error'
        );
    }
};
