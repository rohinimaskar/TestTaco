import appboy from '@braze/web-sdk';

import { brazeHost, brazeKey } from '@tb-core/helpers/next-env';

let isBrazeInitialized = false;

export const initializeBraze = async (email: string) => {
    // initialization for braze https://js.appboycdn.com/web-sdk/latest/doc/modules/appboy.html#initializationoptions

    const braze = appboy.initialize(brazeKey, {
        baseUrl: brazeHost,
        manageServiceWorkerExternally: true
    });

    if (braze) {
        isBrazeInitialized = true;
        /**
         * changeUser method will identify new user by passing in a unique Id,
         * in this case their hashed user email
         */
        const hashedUserEmail = await (
            await import('@tb-core/helpers/sha-generator')
        ).createHash(email);

        appboy.changeUser(hashedUserEmail);

        /**
         * This method will request permissions, and should be gated behind some behavior
         */
        appboy.registerAppboyPushMessages();

        /**
         * show all In-App Messages without custom handling
         */
        // appboy.display.automaticallyShowNewInAppMessages();

        /**
         * sample
         */
        appboy.subscribeToInAppMessage(inAppMessage => {
            let shouldDisplay = true;

            if (inAppMessage instanceof appboy.InAppMessage) {
                // Read the key-value pair for msg-id
                const msgId = inAppMessage.extras['msg-id'];

                // If this is our push primer message
                if (msgId === 'push-primer') {
                    // We don't want to display the soft push prompt to...
                    // ...users on browsers that don't support push, or if the user
                    // has already granted/blocked permission
                    if (
                        !appboy.isPushSupported() ||
                        appboy.isPushPermissionGranted() ||
                        appboy.isPushBlocked()
                    ) {
                        shouldDisplay = false;
                    }
                    // @ts-ignore buttons does not exist on InAppMessages
                    if (inAppMessage.buttons[0] != null) {
                        // Prompt the user when the first button is clicked
                        // @ts-ignore buttons does not exist on InAppMessages
                        inAppMessage.buttons[0].subscribeToClickedEvent(() => {
                            appboy.registerAppboyPushMessages();
                        });
                    }
                }
            }

            // Display the message
            if (shouldDisplay) {
                appboy.display.showInAppMessage(inAppMessage);
            }
        });

        // start (or continue) a session
        appboy.openSession();

        // This triggers the custom message with the ID prime-for-push
        appboy.logCustomEvent('prime-for-push');
    }
    return appboy || braze;
};

export const brazeCustomEvent = (event: string) => {
    if (appboy && isBrazeInitialized) {
        appboy.logCustomEvent(event);
    }
};
