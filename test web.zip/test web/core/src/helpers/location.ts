import { PickupMethod } from '@tb-core/types/location.d';

export const isPickupMethodInStore = (method: PickupMethod) => {
    switch (method) {
        case PickupMethod.DriveThru:
        case PickupMethod.DriveThruPriorityPickupLane:
            return false;
        default:
            return true;
    }
};
