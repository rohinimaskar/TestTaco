/**
 * returns true if N represents a whole number
 */
export const isWholeNumber = (n: number, denominator: number): boolean =>
    (n / denominator) % 1 === 0;
