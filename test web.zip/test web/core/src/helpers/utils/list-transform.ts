/**
 * Moves any item in array to a desired position
 * @param array
 * @param from
 * @param to
 * @returns Copy of array with item in new position
 */
export const moveItemInArray = (array: any[], from: number, to: number) => {
    const arrayCopy = [...array];
    const itemToMove = arrayCopy.splice(from, 1)[0];

    arrayCopy.splice(to, 0, itemToMove);

    return arrayCopy;
};
