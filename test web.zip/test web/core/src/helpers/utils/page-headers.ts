import { ServerResponse } from 'http';

import { interpolate } from '@tb-core/helpers/interpolate';
import { envId } from '@tb-core/helpers/next-env';

export interface PageHeaderOptions {
    pageId?: string;
    storeEdgeCacheTag?: boolean;
}

/**
 * Sets server response headers
 * @param storeId
 * @param headerOptions
 */
export const setHeaders = (
    res: ServerResponse,
    storeId: string,
    headerOptions?: PageHeaderOptions
) => {
    const { pageId, storeEdgeCacheTag } = headerOptions || {};
    let edgeCacheTags = 'PAGE_{envId}_WEB2';

    if (storeEdgeCacheTag) {
        edgeCacheTags +=
            ', STORE_{envId}_{storeId}' +
            (pageId ? ', STORE_{envId}_{pageId}_{storeId}' : '');
    }

    edgeCacheTags += pageId ? ', PAGE_{envId}_{pageId}' : '';

    // This will allow cache purge via Akamai specific edge cache tag
    res.setHeader(
        'Edge-Cache-Tag',
        interpolate(edgeCacheTags, {
            envId,
            pageId: headerOptions?.pageId,
            storeId
        })
    );
};
