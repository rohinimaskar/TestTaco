export const decodeBase64 = (encodedString: string) =>
    Buffer.from(encodedString, 'base64').toString('utf8');
