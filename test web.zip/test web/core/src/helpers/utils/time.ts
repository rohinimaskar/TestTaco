// If they are the same, it returns 0.
export const compareTime = (timeOne: string, timeTwo: string) => {
    const [hoursOne, minutesOne, ampmOne] = timeOne.split(/[:,\s]+/);
    const [hoursTwo, minutesTwo, ampmTwo] = timeTwo.split(/[:,\s]+/);

    const hourOne = convertHourTo24Format(hoursOne, ampmOne);
    const hourTwo = convertHourTo24Format(hoursTwo, ampmTwo);
    const convertedTimeOne = Number(hourOne + minutesOne);
    const convertedTimeTwo = Number(hourTwo + minutesTwo);

    return convertedTimeOne < convertedTimeTwo
        ? -1
        : convertedTimeOne > convertedTimeTwo
        ? 1
        : 0;
};

const convertHourTo24Format = (hour: string, ampm: string) =>
    (hour + (ampm.toUpperCase() === 'PM' && hour !== '12' ? 12 : 0)).toString();

export const getCurrentTime = () => {
    const now = new Date();
    const hours = now.getHours();
    const minutes = now
        .getMinutes()
        .toString()
        .padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const hour = hours % 12 || 12;
    return `${hour}:${minutes} ${ampm}`;
};
