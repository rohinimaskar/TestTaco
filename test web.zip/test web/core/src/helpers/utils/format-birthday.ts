export const formatBirthday = (value: string) => {
    return new Date(value).toLocaleString('default', {
        day: 'numeric',
        month: 'long',
        timeZone: 'UTC'
    });
};

export const formatBirthdayMMDD = (value: string) => {
    return new Date(value).toLocaleDateString(undefined, {
        day: '2-digit',
        month: '2-digit',
        timeZone: 'UTC'
    });
};

export const formatBirthdayMMDDToISOString = (month: number, day: number) => {
    const currYear = new Date().getFullYear();
    const date = new Date(currYear, month, day).toISOString().split('T')[0];
    return date;
};
