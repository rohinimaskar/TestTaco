export const parseBoolean = (input: any) => {
    return input.toString().match(/^(true|[1-9][0-9]*|[0-9]*[1-9]+|yes)$/i)
        ? true
        : false;
};
