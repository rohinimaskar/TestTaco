/**
 *
 * @param url
 * @returns updates url to v4 yum api url
 */
export const setProviderUrl = (url: string) => url.replace(/v2|v3/, 'v4');
