/**
 * Convert 1D array into 2D
 * @param array
 * @param chunkAmount
 */

export const matrixArray = (array: any[], chunkAmount: number) =>
    array.reduce((previous, current, index) => {
        index % chunkAmount === 0
            ? previous.push([current])
            : previous[previous.length - 1].push(current);

        return previous;
    }, []);
