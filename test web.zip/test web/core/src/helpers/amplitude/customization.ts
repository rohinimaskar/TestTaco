import { ComboItem } from '@tb-core/components/products/styled/combo-item-card/combo-item-card';
import { CSCItemModifierType } from '@tb-core/constants/client-side-cart';
import { isArrayOfCustomizationOptions } from '@tb-core/helpers/products/modifiers';
import {
    CSCComboItem,
    CSCItemModifier,
    CSCItemTemplate,
    CSCModifierDetail
} from '@tb-core/types/client-side-cart';

import {
    CustomizationOptions,
    Product,
    VariantOption
} from '@tb-core/types/products';

export interface AmplitudeCustomizationOptions extends VariantOption {
    isSwapped?: boolean;
}

export interface CustomizationsList {
    customized_add?: string[];
    customized_minus?: string[];
    customized_easy?: string[];
    customized_extra?: string[];
    customized_swap?: string[];
    customized_swap_value?: string[];
}

/**
 * Finds a customization option by its PLU within customization options.
 * @param {CustomizationOptions} customizationOptions
 * @param {string} plu
 * @returns {AmplitudeCustomizationOptions | CSCItemModifier | undefined}
 */
export const findCustomizationOptionsByPLU = (
    customizationOptions: CustomizationOptions,
    plu: string
): AmplitudeCustomizationOptions | CSCItemModifier | undefined => {
    for (const [key, options] of Object.entries(customizationOptions)) {
        if (!isArrayOfCustomizationOptions(options)) {
            continue;
        }

        const matchedOption = options
            .flatMap(item => item.variantOptions)
            .find(variant => variant.code === plu);

        if (matchedOption) {
            if (
                key === 'proteinOptions' &&
                matchedOption.modifierType === CSCItemModifierType.ADD
            ) {
                return { ...matchedOption, isSwapped: true };
            }
            return matchedOption;
        }
    }
};

/**
 * Creates a filtered list of customization options for Amplitude events.
 * Processes an array of customization options, categorizes them, and returns an object
 * containing only non-empty customization lists, or a string "none" if there are no customizations.
 * @param {AmplitudeCustomizationOptions[]} customizationOptionsArray
 * @returns {CustomizationsList | string} An object containing the categorized customization lists
 * or "none" if no customizations.
 */
export const createCustomizedListForAmplitude = (
    customizationOptionsArray: AmplitudeCustomizationOptions[]
): CustomizationsList | string => {
    const customizationsList: Partial<CustomizationsList> = {};
    const addCustomization = (key: keyof CustomizationsList, value: string) => {
        const customizationValues = customizationsList[key] ?? [];
        customizationValues.push(value);
        customizationsList[key] = customizationValues;
    };

    // Filter and process swapped items first because they are also
    // categorized as 'ADD' under modifierType.  We want swapped items
    // only appear in 'customized_swap' and not duplicated in 'customized_add'.
    customizationOptionsArray
        .filter(item => item?.isSwapped)
        .forEach(item => {
            addCustomization('customized_swap', item.name);
            addCustomization(
                'customized_swap_value',
                item?.priceData?.formattedValue || '$0.00'
            );
        });

    customizationOptionsArray
        .filter(item => !item?.isSwapped)
        .forEach(item => {
            switch (item.modifierType) {
                case 'ADD':
                    addCustomization('customized_add', item.name);
                    break;
                case 'MINUS':
                    addCustomization('customized_minus', item.name);
                    break;
                case 'EASY':
                    addCustomization('customized_easy', item.name);
                    break;
                case 'EXTRA':
                    addCustomization('customized_extra', item.name);
                    break;
                default:
                    break;
            }
        });
    const filterCustomizations = (
        obj: Partial<CustomizationsList>
    ): Partial<CustomizationsList> => {
        return Object.keys(obj).reduce((acc, key) => {
            const value = obj[key as keyof CustomizationsList];
            if (value && value.length > 0) {
                return {
                    ...acc,
                    [key]: value
                };
            }
            return acc;
        }, {});
    };
    const filteredCustomizedList = filterCustomizations(customizationsList);

    return Object.keys(filteredCustomizedList).length > 0
        ? filteredCustomizedList
        : 'none';
};

/**
 * Processes product groups and combo items, filtering for items with modifiers,
 * and returns an array of customizations for each item.
 * @param {ComboItem[] | undefined} productGroups
 * @param {CSCComboItem[]} items
 * @returns {CustomizationsList[]}
 */
export const createCustomizedListArrayForComboProducts = (
    productGroups: ComboItem[] | undefined,
    items: CSCComboItem[]
): CustomizationsList[] => {
    if (!productGroups) {
        return [];
    }

    const customizationsArray: CustomizationsList[] = [];
    const comboItemWithModifiers = items.filter(
        item => item.modifiers && item.modifiers.length > 0
    );

    comboItemWithModifiers.forEach(comboItem => {
        const productGroup = productGroups.find(
            product => product.groupID === comboItem.groupCode
        );
        const swappedItem = productGroup?.swapList?.find(
            swapItem => swapItem.code === comboItem.plu
        );

        if (swappedItem?.customizationOptions) {
            const swappedCustomizationOptions =
                swappedItem.customizationOptions;
            const comboModifiers: AmplitudeCustomizationOptions[] = [];

            comboItem.modifiers?.forEach(modifier => {
                if (modifier) {
                    const customizationOption = findCustomizationOptionsByPLU(
                        swappedCustomizationOptions,
                        String(modifier.plu)
                    );

                    if (isAmplitudeCustomizationOptions(customizationOption)) {
                        comboModifiers.push(customizationOption);
                    }
                }
            });

            if (comboModifiers.length > 0) {
                const modifier = createCustomizedListForAmplitude(
                    comboModifiers
                );

                if (modifier && typeof modifier !== 'string') {
                    customizationsArray.push(modifier);
                }
            }
        }
    });

    return customizationsArray;
};

export const createCustomizedListForProduct = (
    customizationOptions: CustomizationOptions,
    customizations: number[]
): CustomizationsList | string => {
    const customizationsArray = customizations.map(plu =>
        findCustomizationOptionsByPLU(customizationOptions, String(plu))
    );

    const filteredCustomizationsArray = customizationsArray.filter(
        (option): option is AmplitudeCustomizationOptions =>
            option !== undefined && isAmplitudeCustomizationOptions(option)
    );
    const customizationList = createCustomizedListForAmplitude(
        filteredCustomizationsArray
    );

    return customizationList;
};

/**
 * Creates a string of customization options from an array of CustomizationsList objects.
 * @param {CustomizationsList[]} modifiers -
 * @returns {string} A comma-separated string summarizing the customization options based on the
 * provided modifiers. The string format will include prefixes like "Added", "Removed", and "Modified",
 * as well as labels for easy and extra customizations.
 */
export const createAmplitudeCustomizationString = (
    modifiers: CustomizationsList[]
): string => {
    const customizationLabels: string[] = [];

    const labelMapping: Record<string, string> = {
        customized_add: 'Added',
        customized_minus: 'Removed',
        customized_swap: 'Modified'
    };

    modifiers.forEach(modifier => {
        Object.entries(modifier).forEach(([key, items]) => {
            if (items && Array.isArray(items)) {
                if (key === 'customized_easy' || key === 'customized_extra') {
                    const easyOrExtraLabel =
                        key === 'customized_easy' ? 'EASY' : 'EXTRA';
                    customizationLabels.push(
                        items
                            .map(
                                item => `Modified ${item} (${easyOrExtraLabel})`
                            )
                            .join(', ')
                    );
                } else {
                    const label = labelMapping[key];
                    if (label) {
                        customizationLabels.push(
                            items.map(item => `${label} ${item}`).join(', ')
                        );
                    }
                }
            }
        });
    });

    return customizationLabels.join(', ');
};

/**
 * Processes cart line items and generates a customization options list
 * for Amplitude analytics, including single products and combo items with modifiers.
 * @param {CSCItemTemplate[]} cartLineItems
 * @param {Product[]} pdpProductsJson
 * @returns {CustomizationsList | string}
 */
export const createCustomizedListForAmplitudeFromCart = (
    cartLineItems: CSCItemTemplate[],
    pdpProductsJson: Product[]
): CustomizationsList[] | string => {
    const customizedListForAmplitude: CustomizationsList[] = [];

    const convertModifiersToAmplitudeObjects = (
        plu: string,
        modifiers: CSCModifierDetail[]
    ): AmplitudeCustomizationOptions[] => {
        return modifiers.flatMap(modifier => {
            const currentProduct = pdpProductsJson.find(
                product => product.code === plu
            );

            if (currentProduct?.customizationOptions) {
                const variantCustomizationOption = findCustomizationOptionsByPLU(
                    currentProduct.customizationOptions,
                    modifier.plu
                );

                if (
                    isAmplitudeCustomizationOptions(variantCustomizationOption)
                ) {
                    return variantCustomizationOption;
                }
            }
            return [];
        });
    };

    const addModifiers = (plu: string, modifiers: CSCModifierDetail[]) => {
        const amplitudeModifiers = convertModifiersToAmplitudeObjects(
            plu,
            modifiers
        );
        const customization = createCustomizedListForAmplitude(
            amplitudeModifiers
        );

        if (typeof customization !== 'string') {
            customizedListForAmplitude.push(customization);
        }
    };

    cartLineItems.forEach(cartItem => {
        if (cartItem.modifiers?.length) {
            addModifiers(cartItem.plu, cartItem.modifiers);
        }

        cartItem.items?.forEach(comboItem => {
            if (comboItem.modifiers?.length) {
                addModifiers(comboItem.plu, comboItem.modifiers);
            }
        });
    });

    return customizedListForAmplitude.length > 0
        ? customizedListForAmplitude
        : 'none';
};

export const isAmplitudeCustomizationOptions = (
    options: AmplitudeCustomizationOptions | CSCItemModifier | undefined
): options is AmplitudeCustomizationOptions => {
    return (
        typeof options === 'object' &&
        'code' in options &&
        'modifierType' in options &&
        'name' in options &&
        (options.isSwapped === undefined ||
            typeof options.isSwapped === 'boolean')
    );
};

export const isAmplitudeCustomizationOptionsArray = (
    optionsArray: AmplitudeCustomizationOptions[] | undefined
): optionsArray is AmplitudeCustomizationOptions[] =>
    Array.isArray(optionsArray) &&
    optionsArray.every(isAmplitudeCustomizationOptions);
