import { AddressComponent } from '@tb-core/types/location.d';

export interface AddressType {
    level: string;
    value: keyof AddressComponent;
}

export interface GetPlaceDetailAddressComponentsProps {
    components: AddressComponent[];
    types: AddressType[];
}

const GetPlaceDetailAddressComponents = ({
    components,
    types
}: GetPlaceDetailAddressComponentsProps) => {
    const address: string[] = [];

    types.map((type: AddressType) => {
        // Find the appropriate part of the address wanted based on the level specified
        const res:
            | AddressComponent
            | undefined = components.find((component: AddressComponent) =>
            component.types.includes(type.level)
        );
        // Return either the long_name or short_name, passed as "value" along with level
        if (res) {
            address.push(res[type.value]); // Add into the address array for formatting
        }
    });

    // Format the address
    const formattedAddress: string = address.toString().replace(/,/g, ', ');

    return formattedAddress;
};

export default GetPlaceDetailAddressComponents;
