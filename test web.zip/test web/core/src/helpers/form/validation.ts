export const isEmail = (email: string) => {
    return /(.+)@(.+){2,}\.(.+){2,}/.test(email);
};
