export const getFormValues = (form: HTMLFormElement) =>
    Object.values(form).reduce((obj, field) => {
        if (field.type === 'radio' && field.checked) {
            // Get values from checked radio buttons
            obj[field.name] = field.value;
        } else if (field.type !== 'radio' && field.value) {
            // Get values from other inputs
            obj[field.name] = field.value;
        }
        return obj;
    }, {});
