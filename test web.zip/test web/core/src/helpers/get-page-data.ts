import fetch from 'isomorphic-unfetch';
import { useEffect, useState } from 'react';

// @TODO Delete this file - not currently used.
const GetPageData = (url: string, onFetchSuccess?: (response: any) => void) => {
    const [data, updateData] = useState(undefined);

    useEffect(() => {
        const abortController = new AbortController();
        const signal = abortController.signal;

        async function fetchData() {
            try {
                const response = await fetch(url, { signal });
                const json = await response.json();
                if (onFetchSuccess) {
                    await onFetchSuccess(json);
                }
                updateData(json);
            } catch (e) {
                if (!abortController.signal.aborted) {
                    console.error('Data request failed!', e);
                }
            }
        }
        fetchData();
        return () => {
            if (typeof abortController.abort === 'function') {
                abortController.abort();
            }
        };
    }, []);

    return data;
};

export default GetPageData;
