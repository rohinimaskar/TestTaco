export const getLoginHref = (isLoggedIn?: boolean) =>
    isLoggedIn ? '/profile' : '/login';

export const getLoginTitle = (isLoggedIn?: boolean) =>
    isLoggedIn ? 'Profile' : 'Login';
