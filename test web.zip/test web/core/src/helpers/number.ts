/**
 * Converts a provided String to a Number. If string provided is undefined or NaN,
 * value defaults to 0.
 *
 * @param toConvert - the String param to convert.
 * @return A Number resulting from the converted String.
 */
export const convertStringToNumber = (
    toConvert: string | undefined
): number => {
    const toReturn = Number(toConvert);
    return isNaN(toReturn) ? 0 : toReturn;
};
