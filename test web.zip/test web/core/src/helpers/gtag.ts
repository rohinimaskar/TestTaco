import { RealObject } from '@tb-core/types';

type GTagWindow = Window &
    typeof globalThis & {
        dataLayer?: any[];
    };

/**
 * Adds a new entry to the dataLayer.
 * https://developers.google.com/gtagjs/devguide/configure
 *
 * Only use after the global site tag has been installed.
 * Only use this in the browser.
 */
export const gtag = (...args: [string, string, RealObject]) => {
    const win: GTagWindow = window;

    if (win && win.dataLayer) {
        win.dataLayer.push(args);
    }
};

/**
 * Adds a new event entry to the dataLayer.
 * https://developers.google.com/gtagjs/devguide/configure
 *
 * Only use after the global site tag has been installed.
 * Only use this in the browser.
 */
export const event = (action: string, eventAttributes: any) => {
    gtag('event', action, eventAttributes);

    // @TODO Why do we need event callback logic here?
    if (typeof eventAttributes.event_callback !== 'undefined') {
        // @TODO Why do we need `setTimeout`?
        setTimeout(eventAttributes.event_callback, 1000);
    }
};
