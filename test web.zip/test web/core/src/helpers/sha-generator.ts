export const createHash = async (input: string, normalize = false) => {
    const value = normalize ? input.trim().toLowerCase() : input;
    const textAsBuffer = new TextEncoder().encode(value);
    const hashBuffer = await globalThis.crypto.subtle.digest(
        'SHA-256',
        textAsBuffer
    );
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hash = hashArray
        .map(item => item.toString(16).padStart(2, '0'))
        .join('');
    return hash;
};
