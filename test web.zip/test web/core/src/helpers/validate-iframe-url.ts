type IframeType = 'Spotify Podcast' | 'NutritionX' | 'OneTrust';

export default function isValidIframeUrl(
    str: string,
    type?: IframeType | string
) {
    try {
        const url = new URL(str);

        if (!type) {
            return false;
        }

        if (type === 'Spotify Podcast') {
            return url.hostname === 'open.spotify.com';
        }

        return false;
    } catch {
        return false;
    }
}
