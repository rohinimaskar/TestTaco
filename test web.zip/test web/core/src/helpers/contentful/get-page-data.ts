import {
    contentfulEnv,
    contentfulHost,
    contentfulSpace,
    contentfulToken
} from '@tb-core/helpers/next-env';
import getEntries from '@tb-core/providers/contentful/get-entries';
import { ContentfulDeliveryHost } from '@tb-core/types/contentful';

export const getPageData = async (pagePath: string) => {
    let items = [{ fields: {} }];

    if (contentfulToken) {
        items = await getEntries({
            accessToken: contentfulToken,
            environment: contentfulEnv,
            host: contentfulHost as ContentfulDeliveryHost,
            search: {
                'fields.path': pagePath
            },
            space: contentfulSpace,
            type: 'page'
        });
    } else {
        // @TODO Missing credentials - log some error to server logs. Logs TBD.
    }

    return {
        props: { pageData: items[0].fields } // will be passed to the page component as props
    };
};
