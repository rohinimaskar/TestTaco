import { articleCategoriesQuery } from '@tb-core/graphql/queries';
import { contentfulHost } from '@tb-core/helpers/next-env';
import contentfulQuery from '@tb-core/providers/contentful/graphql/query';

import { ArticleType } from './article-list-props-util';
export interface PagePropsUtilOptions {
    pageSlug?: string;
    productCategories?: boolean;
    useRawUrl?: boolean;
}

export default async function articleCategoryPropsUtil(type?: ArticleType) {
    // `isPreview` must correlate to the HOST + related ACCESS_TOKEN.
    const isPreview = contentfulHost === 'preview.contentful.com';

    // Contentful query
    const query = `
        query ($isPreview: Boolean) {
            ${articleCategoriesQuery(undefined, type)}
        }
    `;
    // ${fragmentsArticle}

    const categoryPromise = contentfulQuery({
        isPreview,
        query
    });

    const categories = await categoryPromise;
    // console.log('article list data', { articleList });

    if (
        !categories.articleCategoryCollection ||
        categories.articleCategoryCollection.items.length <= 0
    ) {
        return { articleCategories: { items: [] } };
    }

    return {
        articleCategories: categories.articleCategoryCollection
    };
}
