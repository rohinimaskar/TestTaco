import { GenericContentProps } from '@tb-core/types';

/**
 * Takes the results of initial Page query and secondary entriesCollection query...
 *      ...and merges together
 */
const mergeEntriesIntoContentGroups = (
    content: GenericContentProps[],
    entriesQuery: any
) => {
    content.map((entry, n) => {
        // check if module has associated colorTheme in theme object:
        const {
            entriesCollection
        } = entriesQuery?.items[0].contentGroupCollection.items[n];

        entry.entriesCollection = entriesCollection;
    });
};

export default mergeEntriesIntoContentGroups;
