import WebpageAdapter from '@tb-core/adapters/contentful/graphql/webpage-adapter';
import { ProductCategoriesProviderProps } from '@tb-core/components/context/product-categories';
import { PageContextProps } from '@tb-core/components/context/webpage';
import {
    colorThemeFields,
    footerCopyFields,
    footerHeroFields,
    footerNavigationGroupFields,
    iFrameModuleFields,
    imageFields,
    linkFields,
    metatagFields,
    topicMetadataFields
} from '@tb-core/graphql/fragments';
import { articleQuery, pageQuery } from '@tb-core/graphql/queries';
import { fragmentsArticle } from '@tb-core/helpers/contentful/article-props-util';
import minifyQuery from '@tb-core/helpers/contentful/minify-query';
import { basePath, contentfulHost } from '@tb-core/helpers/next-env';
import { indexOfRoute } from '@tb-core/helpers/utils';
import contentfulQuery from '@tb-core/providers/contentful/graphql/query';
import productCategoriesPropsUtil from './categories-props-util';
import pageEntriesPropsUtil from './page-entries-props-util';

export enum ContentfulPageModel {
    WEBPAGE = 'Webpage',
    ARTICLE = 'Article'
}

export interface PagePropsUtilOptions {
    pageSlug?: string;
    pageModel?: ContentfulPageModel;
    productCategories?: boolean;
    useRawUrl?: boolean;
}

export const fragmentsWebpage = `
    ${colorThemeFields}
    ${footerCopyFields}
    ${footerHeroFields}
    ${footerNavigationGroupFields}
    ${iFrameModuleFields}
    ${imageFields}
    ${linkFields}
    ${metatagFields}
    ${topicMetadataFields}
    `;

const pagePropsUtil = async (
    rawUrl = '',
    {
        pageSlug = '',
        productCategories = false,
        pageModel = ContentfulPageModel.WEBPAGE,
        useRawUrl = false
    }: PagePropsUtilOptions
) => {
    // `isPreview` must correlate to the HOST + related ACCESS_TOKEN.
    const isPreview = contentfulHost === 'preview.contentful.com';
    // Resolve to a base path with the pathname when `useRawlUrl` is false.
    const resolvedUrl = (useRawUrl ? '' : basePath) + rawUrl.split('?')[0];
    // Resolve url prefix, inclusion of a slash or not.
    const urlSlashPrefix =
        /^\//.test(resolvedUrl || '') && resolvedUrl !== '/' ? '' : '/';
    // Drop the trailing slash from the url.
    const url = urlSlashPrefix + resolvedUrl.replace(/\/$/, '');
    // Match against routes - "no match" will throw an error.
    const urlInRoute = indexOfRoute(url);
    const urlPageSlug = pageSlug || url;

    const notFound = { notFound: true };
    if (urlInRoute === -1) {
        return notFound;
    }

    // Contentful query
    const query = minifyQuery(`
            query ($isPreview: Boolean) {
                ${
                    pageModel === ContentfulPageModel.WEBPAGE
                        ? pageQuery(urlPageSlug)
                        : articleQuery(urlPageSlug)
                }
            }
            ${
                pageModel === ContentfulPageModel.WEBPAGE
                    ? fragmentsWebpage
                    : fragmentsArticle
            }
        `);

    // @TODO Incorporate contentfulEnv & contentfulHost into the query.
    // Pass query into QraphQL Service
    const pageContentPromise = contentfulQuery({
        isPreview,
        query
    });

    // Retrieve product categories separately since it exceeds GraphQL response limit
    const productCategoriesContentPromise: Promise<
        ProductCategoriesProviderProps | {}
    > = productCategories ? productCategoriesPropsUtil() : Promise.resolve({});

    // Retrieve page theme colors separately since it exceeds GraphQL response limit
    const pageContentEntriesPromise = pageEntriesPropsUtil(urlPageSlug);

    // Asynchrously Wait for all 3 Promises
    const pageContent = await pageContentPromise;
    const pageContentEntries = await pageContentEntriesPromise;
    const productCategoriesContent = await productCategoriesContentPromise;

    if (!pageContent.webpageCollection) {
        throw Error(
            `Contentful Query Failed - ${{
                isPreview,
                query
            }}`
        );
    } else if (pageContent.webpageCollection.items.length <= 0) {
        return notFound;
    }

    // @ts-ignore TODO ECEXP-2911 - fix type mismatch with addition  of statusCode in PageContextProps
    const pageProps: PageContextProps &
        Partial<ProductCategoriesProviderProps> = {
        ...productCategoriesContent,
        content: WebpageAdapter(
            pageContent.webpageCollection,
            pageContentEntries
        ),
        ctx: {
            // ...ctx,
            url
        }
    };

    return pageProps;
};

export default pagePropsUtil;
