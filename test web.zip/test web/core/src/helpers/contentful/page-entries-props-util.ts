import {
    colorThemeFields,
    formControlFields,
    imageFields,
    linkFields,
    videoPlayerFields
} from '@tb-core/graphql/fragments';
import { pageEntries } from '@tb-core/graphql/queries';
import minifyQuery from '@tb-core/helpers/contentful/minify-query';
import { contentfulHost } from '@tb-core/helpers/next-env';
import contentfulQuery from '@tb-core/providers/contentful/graphql/query';

/*
 * @return a list of ProductCategories from Contentful
 */
const pageEntriesPropsUtil = async (pageSlug: string = '') => {
    let entriesContent;
    // `isPreview` must correlate to the HOST + related ACCESS_TOKEN.
    const isPreview = contentfulHost === 'preview.contentful.com';

    const fragments = `
        ${colorThemeFields}
        ${formControlFields}
        ${imageFields}
        ${linkFields}
        ${videoPlayerFields}
        `;

    // Contentful query
    const query = minifyQuery(`
            query ($isPreview: Boolean) {
                ${pageEntries(pageSlug)}
            }
            ${fragments}
        `);

    // @TODO Incorporate contentfulEnv & contentfulHost into the query.
    // Pass query into QraphQL Service
    entriesContent = await contentfulQuery({
        isPreview,
        query
    });

    if (!entriesContent.webpageCollection) {
        throw Error(`Error retrieving page entries - Requested ${pageSlug}`);
    } else if (entriesContent.webpageCollection.items.length <= 0) {
        return { notFound: true };
    }

    return entriesContent.webpageCollection;
};

export default pageEntriesPropsUtil;
