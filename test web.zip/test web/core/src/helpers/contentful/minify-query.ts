/**
 * Replace multiple spaces, and new line characters with a single space
 * Returned string should remain a valid graphql query
 *
 * @param str a graphql query
 * @returns { string }
 */
export default function minifyQuery(str: string) {
    return str.replace(/[\r\n\s]+/g, ' ');
}
