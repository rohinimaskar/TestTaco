import { createClient, EntryCollection } from 'contentful';

import { toError } from '@tb-core/helpers/fetch';
import {
    ContentfulEntry,
    ContentfulGetContentArgs
} from '@tb-core/types/contentful';

export const getContent = async ({
    clientConfig: { accessToken, environment, host, space },
    contentType = '',
    searchParams = {}
}: ContentfulGetContentArgs) => {
    // Contentful setup
    const client = createClient({
        accessToken,
        environment: environment || 'master',
        host,
        space
    });

    let entries: Partial<EntryCollection<ContentfulEntry>> = [];

    if (contentType) {
        try {
            entries = await client.getEntries({
                ...searchParams,
                content_type: contentType,
                // How many levels deep we want to go when returning content.
                include: 10
            });
        } catch (error) {
            const err = toError(error);
            throw Error(
                `Caught Exception: ${err.message || JSON.stringify(err)}`
            );
        }
    }

    return entries;
};
