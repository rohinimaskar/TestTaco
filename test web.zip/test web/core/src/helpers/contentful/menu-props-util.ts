import { storeNationalId, webOrigin } from '@tb-core/helpers/next-env';
import getMenu from '@tb-core/providers/get-menu';
import { MenuProductCategory, Product } from '@tb-core/types/products';

export type MenuProp = Pick<MenuProductCategory, 'products'>;

const menuPropsUtil = async (
    category: string = '',
    storeId: string = storeNationalId
): Promise<MenuProp> => {
    const menu = await getMenu(storeId, webOrigin, true);
    const categoryMenu = menu.menuProductCategories.find(
        productCategory => productCategory.code === category
    );

    // if category is invalid, return p products as undefined to render 404 page
    if (!categoryMenu) {
        return { products: undefined };
    }
    return {
        products: categoryMenu?.products
            ? categoryMenu.products.filter(
                  ({ isAvailableInStore, sellableStartDate }: Product) =>
                      isAvailableInStore && !sellableStartDate
              )
            : []
    };
};

export default menuPropsUtil;
