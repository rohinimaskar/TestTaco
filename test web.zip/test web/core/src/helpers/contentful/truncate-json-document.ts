/**
 * Truncate Contentful Rich Text Document to a max character length
 */
const MAX_LENGTH = 110;

export default function truncateJsonDocument(content: any, maxLength?: number) {
    const limit =
        typeof maxLength !== 'undefined' && maxLength > 0
            ? maxLength
            : MAX_LENGTH;

    let count = 0;
    let truncateNodesAtIndex = -1;

    // ARTIFICIAL LIMIT: Cut 'content' to 1 block level node of the document
    content.json.content.length = 1;

    content.json.content[0].content.every(
        (node: Record<string, any>, index: number) => {
            const remaining = limit - count;
            const length = node.value.length;

            // If this node exceeds the remiaining char count:
            if (node.value && length > remaining) {
                // trim the string to remainig and break at the space
                node.value = node.value.substring(0, remaining);
                const len = node.value.lastIndexOf(' ');
                node.value =
                    node.value.substring(0, len > -1 ? len : remaining) + '...';

                truncateNodesAtIndex = index + 1;

                // return false to break loop
                return false;
            }

            count += length;
            return true;
        }
    );

    if (truncateNodesAtIndex > -1) {
        content.json.content[0].content.length = truncateNodesAtIndex;
    }

    return content;
}
