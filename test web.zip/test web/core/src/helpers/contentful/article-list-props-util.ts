import { articleListQuery } from '@tb-core/graphql/queries';
import { contentfulHost } from '@tb-core/helpers/next-env';
import contentfulQuery from '@tb-core/providers/contentful/graphql/query';

export type ArticleType = 'newsroom' | 'stories';

export interface ArticleListPropsUtilOptions {
    category?: string[];
    date?: string;
    direction?: 'lt' | 'gt';
    limit?: number;
    skip?: number;
    type?: ArticleType;
    year?: string;
    slug_not?: string;
}

export const mapUrlToArticleType = (str: string = ''): ArticleType =>
    str?.includes('/newsroom') ? 'newsroom' : 'stories';

export default async function articleListPropsUtil({
    category,
    year,
    date,
    direction,
    limit,
    skip,
    slug_not,
    type
}: ArticleListPropsUtilOptions) {
    // `isPreview` must correlate to the HOST + related ACCESS_TOKEN.
    const isPreview = contentfulHost === 'preview.contentful.com';

    // Contentful query
    const query = `
    query ($isPreview: Boolean) {
        ${articleListQuery({
            category,
            date,
            direction,
            limit,
            skip,
            slug_not,
            type,
            year
        })}
    }
    `;

    const articleListPromise = contentfulQuery({
        isPreview,
        query
    });

    const articleList = await articleListPromise;

    if (
        !articleList.webpageArticleCollection ||
        articleList.webpageArticleCollection.items.length <= 0
    ) {
        return { articleList: { items: [] } };
    }

    return {
        articleList: articleList.webpageArticleCollection
    };
}
