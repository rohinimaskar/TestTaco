import ProductCategoriesAdapter from '@tb-core/adapters/contentful/graphql/product-categories-adapter';
import { productCategoryFields } from '@tb-core/graphql/fragments';
import { categoriesQuery } from '@tb-core/graphql/queries';
import { contentfulHost } from '@tb-core/helpers/next-env';
import contentfulQuery from '@tb-core/providers/contentful/graphql/query';
/*
 * @return a list of ProductCategories from Contentful
 */
const productCategoriesPropsUtil = async () => {
    let content;
    // `isPreview` must correlate to the HOST + related ACCESS_TOKEN.
    const isPreview = contentfulHost === 'preview.contentful.com';

    // Contentful query
    const query = `
            query ($isPreview: Boolean) {
                ${categoriesQuery}
            }
            ${productCategoryFields}
        `;

    // @TODO Incorporate contentfulEnv & contentfulHost into the query.
    // Pass query into QraphQL Service
    content = await contentfulQuery({
        isPreview,
        query
    });

    if (
        !content.webpageCollection ||
        content.webpageCollection.items.length <= 0
    ) {
        throw Error('Error retrieving Web CLS');
    }

    return ProductCategoriesAdapter(
        content.webpageCollection.items[0].contentGroupCollection.items[0]
            .entriesCollection
    );
};

export default productCategoriesPropsUtil;
