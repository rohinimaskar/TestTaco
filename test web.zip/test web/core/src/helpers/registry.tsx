import { RealObject } from '@tb-core/types';

const RegistryDecoratorFactory = () => {
    const registry: RealObject = {};

    const decorator: ((key: string) => (target: any) => typeof target) & {
        registry: RealObject;
    } = key => target => {
        registry[key] = target;
        return target;
    };

    decorator.registry = registry;

    return decorator;
};

export default RegistryDecoratorFactory;
