import { storeNationalId } from '@tb-core/helpers/next-env';
import useStoreContext from '@tb-core/hooks/use-store-context';

export const productUrlWithStoreId = (url: string = ''): string => {
    const { storeId } = useStoreContext();

    if (storeId && storeId !== storeNationalId) {
        return `${url}?store=${storeId}`;
    }

    return url;
};
