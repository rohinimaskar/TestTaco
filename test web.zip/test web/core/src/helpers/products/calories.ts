import { CSCItemModifierType } from '@tb-core/constants/client-side-cart';
import { convertStringToNumber } from '@tb-core/helpers/number';
import { getVariant } from '@tb-core/helpers/products/variant';
import { CartProductDetails } from '@tb-core/hooks/use-cart-product';
import { RealObject } from '@tb-core/types';
import { CustomizationOption } from '@tb-core/types/products';

/**
 * Returns the rounded calories
 * Reference: https://tacobeta.atlassian.net/wiki/spaces/ECOM/pages/593500370/Calorie+Calculation+Rules
 * @param calories any calorie amount
 */
export const getRoundedCalories = (calories: number) => {
    let roundedCalories = calories;

    if (calories < 5) {
        // round to 0
        roundedCalories = 0;
    } else if (calories < 50) {
        // round to the nearest 5
        roundedCalories = Math.round(calories / 5) * 5;
    } else {
        // accurateTotal >= 50, round to the nearest 10
        roundedCalories = Math.round(calories / 10) * 10;
    }

    return roundedCalories;
};

export const getSwapListCalories = (swapList: RealObject[]): number[] => {
    // if calorie is a range, spilt the 2 numbers and get the max value
    // because parseInt a range would return the first number
    const caloriesList = swapList.map(item => {
        if (item?.calories.includes('-')) {
            const spiltCalorieRange = item?.calories.split('-');

            return Math.max(...spiltCalorieRange);
        }

        return parseInt(item?.calories, 10);
    });

    return caloriesList;
};

export const minMaxCalories = (calories: number[]): string => {
    const filterIntegers = calories.filter(calorie => !isNaN(calorie));

    return `${Math.min(...filterIntegers)} - ${Math.max(...filterIntegers)}`;
};

export const swapListAsCalorieRange = (swapList: RealObject[]) =>
    minMaxCalories(getSwapListCalories(swapList));

export const getProductTotalCalories = (productList: CartProductDetails[]) => {
    let total = '0';
    let min = 0;
    let max: number | null = null;

    productList.forEach((item: CartProductDetails) => {
        let includesRange = false;

        if (!item || !item.calories) {
            return '0';
        }

        if (item.calories.includes('-')) {
            includesRange = true;
        }

        if (includesRange) {
            const splitElements = item.calories.split('-');
            if (!max && min > 0) {
                max = min + Number(splitElements[1]);
                min += Number(splitElements[0]);
            } else if (includesRange && !max) {
                min += Number(splitElements[0]);
                max = Number(splitElements[1]);
            } else if (includesRange && max) {
                min += Number(splitElements[0]);
                max += Number(splitElements[1]);
            }
        } else if (max) {
            min += Number(item.calories);
            max += Number(item.calories);
        } else {
            min += Number(item.calories);
        }

        total = `${min}${max ? `-${max}` : ''}`;
    });

    return total;
};

export const calorieDifference = (calorie1: string, calorie2: string): string =>
    String(convertStringToNumber(calorie1) - convertStringToNumber(calorie2));

export const calculateIncludedCalorieDifference = (
    accurateCalorie: string,
    calories: string,
    customizationOption: CustomizationOption
) => {
    const addVariant = getVariant(customizationOption, CSCItemModifierType.ADD);
    const accurateCalorieDiff = calorieDifference(
        accurateCalorie,
        addVariant?.accurateCalorie || ''
    );
    const caloriesDiff = calorieDifference(
        calories,
        addVariant?.calories || ''
    );
    return { accurateCalorieDiff, caloriesDiff };
};
