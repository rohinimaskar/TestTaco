import {
    ComboItem,
    DefaultDrinkProduct,
    DefaultFoodProduct,
    DrinkItem,
    FoodItem
} from '@tb-core/components/products/styled/combo-item-card/combo-item-card';
import {
    CartProductDetails,
    CartProductItem
} from '@tb-core/hooks/use-cart-product';

export const isDrinkItem = (comboItem: ComboItem): comboItem is DrinkItem =>
    typeof (comboItem as DrinkItem).defaultVariantProduct !== 'undefined';

export const isFoodItem = (comboItem: ComboItem): comboItem is FoodItem =>
    typeof (comboItem as FoodItem).defaultBaseProduct !== 'undefined';

export const getDefaultProduct = (
    comboItem: ComboItem
): DefaultDrinkProduct | DefaultFoodProduct =>
    isDrinkItem(comboItem)
        ? comboItem.defaultVariantProduct
        : comboItem.defaultBaseProduct;

export const getSwapItem = (comboItem: ComboItem, code: string) => {
    if (isDrinkItem(comboItem)) {
        let selectedVariant;
        comboItem.swapList.find(
            item =>
                (selectedVariant = item.variantOptions.find(
                    variant => variant.code === code
                ))
        );
        return selectedVariant || getDefaultProduct(comboItem);
    } else if (comboItem.swapList) {
        return (
            comboItem.swapList.find(item => item.code === code) ||
            getDefaultProduct(comboItem)
        );
    }
    return getDefaultProduct(comboItem);
};

export const updateComboALCProductList = (item: CartProductItem) => {
    if (!item?.productGroups) {
        return [];
    }

    return item.productGroups.map(productGroup => {
        const defaultProduct = getDefaultProduct(productGroup);
        const data: CartProductDetails = {
            calories: defaultProduct.calories,
            groupCode: productGroup?.groupID || '',
            plu: item.isBYOB ? '' : defaultProduct.code,
            price: 0,
            qty: productGroup?.defaultQuantity || 1,
            selectedOptions: []
        };

        return data;
    });
};
