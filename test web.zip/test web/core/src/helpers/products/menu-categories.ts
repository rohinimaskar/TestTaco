import { ContentfulMetaDataUserTags } from '@tb-core/constants/contentful';
import { ContentfulProductCategory } from '@tb-core/types/contentful/products';

export const getMenuCategories = (
    categories: ContentfulProductCategory[],
    isLoggedIn: boolean | undefined,
    favoritesEnabled?: boolean
) => {
    if (isLoggedIn) {
        if (!favoritesEnabled) {
            return categories.filter(
                category =>
                    !category.slug.includes('favorites') &&
                    !category.hideFromMenu
            );
        }
        return categories.filter(category => !category.hideFromMenu);
    } else {
        return categories.filter(
            category =>
                !category.hideFromMenu &&
                !category.contentfulMetadata?.tags?.some(
                    tag => tag.id === ContentfulMetaDataUserTags.USER_LOGGED_IN
                )
        );
    }
};
