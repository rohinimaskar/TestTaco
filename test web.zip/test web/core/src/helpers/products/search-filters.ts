import { Product } from '@tb-core/types/products';

const tlpPassPlus = ['550516'];

const tlpProductsPlus = [
    '550518',
    '550519',
    '550520',
    '550521',
    '550522',
    '550523',
    '550524'
];

export const tacoLoversPassDisabled = () => {
    const blackList = tlpPassPlus.concat(tlpProductsPlus);
    return (product: Product): boolean => !blackList.includes(product.code);
};

export const tacoLoversPassFilter = (isCurrentSubscriber: boolean = false) => {
    const blackList = isCurrentSubscriber ? tlpPassPlus : tlpProductsPlus;
    return (product: Product): boolean => !blackList.includes(product.code);
};
