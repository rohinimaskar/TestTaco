import IngredientsAdapter from '@tb-core/adapters/products/ingredients-adapter';
import ProteinOptionsAdapter from '@tb-core/adapters/products/protein-options-adapter';
import StylesAdapter from '@tb-core/adapters/products/styles-adapter';
import { IngredientCardProps } from '@tb-core/components/composites/products/ingredient-card';
import {
    CSCItemModifierOptions,
    CSCItemModifierType
} from '@tb-core/constants/client-side-cart';
import { KitchenMessages, StylePLU } from '@tb-core/constants/products';
import { calculateIncludedCalorieDifference } from '@tb-core/helpers/products/calories';
import {
    isArrayOfCustomizationOptions,
    isStyleOption
} from '@tb-core/helpers/products/modifiers';
import {
    styleTypesMap,
    updateStyleOptionCategory
} from '@tb-core/helpers/products/styles';
import { LocalCart } from '@tb-core/hooks/client-side-cart/use-cart';
import { Option } from '@tb-core/hooks/product/use-customize';
import { RealObject } from '@tb-core/types';
import {
    CSCItem,
    CSCItemDetail,
    CSCItemModifier,
    CSCItemTemplate,
    CSCModifierDetail
} from '@tb-core/types/client-side-cart';
import {
    CustomizationOption,
    CustomizationOptions,
    Price,
    Product,
    StyleOption,
    VariantOption
} from '@tb-core/types/products';

export const createModifierString = (modifiers: CSCItemModifier[]) =>
    modifiers
        .map(
            (modifier: RealObject) => modifier.opt + modifier.ots + modifier.plu
        )
        .join('');

/**
 *
 * @param modType string value of modifier type.
 * @param onTheSide boolean value determining if item should be on the side
 * @returns
 */
export const getModifierSuffix = (
    modType: string,
    onTheSide: boolean,
    onTheSideLabel?: string
) => {
    if (modType?.match(/^EASY|EXTRA$/)) {
        return ` (${modType.toLowerCase()})`;
    } else if (onTheSide) {
        return ` ${onTheSideLabel}`;
    }
    return '';
};

/**
 * sort modifiers by name, then on the side value, then plu
 */
export const sortModifiers = (modifiers: any) =>
    modifiers.sort((a: RealObject, b: RealObject) => {
        if (a.opt > b.opt) {
            return 1;
        } else if (a.opt < b.opt) {
            return -1;
        }
        if (a.ots > b.ots) {
            return 1;
        } else if (a.ots < b.ots) {
            return -1;
        }
        if (a.plu > b.plu) {
            return 1;
        } else if (a.plu < b.plu) {
            return -1;
        }
        return 0;
    });

const createModifierData = (
    isOnTheSide: boolean,
    includedWithStyle: boolean,
    opt: CSCItemModifierOptions,
    variantOption: VariantOption | IngredientCardProps
) => {
    const getOptionPrice = () => {
        if (
            (opt === CSCItemModifierOptions.PROTEIN ||
                opt === CSCItemModifierOptions.INCLUDE) &&
            'price' in variantOption
        ) {
            return variantOption.price;
        } else if (
            'priceData' in variantOption &&
            typeof variantOption.priceData?.value !== 'undefined'
        ) {
            return variantOption.priceData?.value;
        }
        return 0;
    };

    const adaptedModifierData: Option = {
        accurateCalorie: variantOption.accurateCalorie,
        calories: variantOption.calories,
        code: variantOption.code,
        includedWithStyle,
        opt,
        price: getOptionPrice()
    };

    if (isOnTheSide && 'onTheSide' in variantOption) {
        adaptedModifierData.onTheSide = variantOption.onTheSide;
    }

    return adaptedModifierData;
};

/**
 * Updates the opt property of the modifierItem based on the style type.
 * @param modifierItem - The current modifier item being processed.
 * @param styleTypesMap - A map containing the style PLU codes as keys and the corresponding opt values as values.
 */
const updateModifierOptForStyle = (modifierItem: CSCItemModifier) => {
    if (styleTypesMap[modifierItem.plu]) {
        modifierItem.opt = styleTypesMap[modifierItem.plu];
    }
};

/**
 * Updates modifiers with style products by setting 'includedWithStyle' to true and updating the 'opt' property.∂
 * @param modifiers - the modifiers received from the cart
 * @param styleOptions - the style options from the customization options
 */
const updateModifiersWithStyleProducts = (
    modifiers: CSCItemModifier[],
    styleOptions: StyleOption[]
) => {
    modifiers?.forEach(modifier => {
        if (modifier?.groupType === 'style') {
            const option = styleOptions.find(
                styleOption => styleOption.code === modifier.plu
            );

            if (option?.addProducts && option.addProducts.length > 0) {
                option.addProducts.forEach(product => {
                    const modifierIndex = modifiers.findIndex(
                        modifier => modifier.plu === product.code
                    );
                    if (modifiers?.[modifierIndex]) {
                        modifiers[modifierIndex] = {
                            ...modifiers[modifierIndex],
                            includedWithStyle: true,
                            opt: product.opt
                        };
                    }
                });
            }
        }
    });
};

/**
 * This function helps adapt the modifiers received from the cart into a data structure of type 'Option'
 * which will be used by the 'selectedOptions' property from the 'useCustomize' hook
 *
 * @param customizationOptions - the customizationOptions from the product JSON
 * @param modifiers - the modifiers received from the cart
 * @return adaptedModifiers - an array of objects of type 'Option' that contain the modifiers along
 *                            with any additional information needed by the 'useCustomize' hook
 */
export const cartModifiersAdapter = (
    customizationOptions: CustomizationOptions,
    modifiers: CSCItemModifier[]
) => {
    const adaptedModifiers: Option[] = [];
    const adaptedModifiersCodes: string[] = [];
    const customizationOption = 'Option';
    const styleOption = 'Product';
    const styleOptions = StylesAdapter(customizationOptions);

    updateModifiersWithStyleProducts(modifiers, styleOptions);

    modifiers?.forEach(modifierItem => {
        if (
            [
                CSCItemModifierOptions.PROTEIN,
                CSCItemModifierOptions.INCLUDE
            ].includes(modifierItem.opt)
        ) {
            const selectedCustomizationOptions =
                modifierItem.opt === CSCItemModifierOptions.PROTEIN
                    ? customizationOptions?.proteinOptions
                    : customizationOptions?.includeOptions;

            // !TODO: Remove once https://tacobeta.atlassian.net/browse/SHOP-1305 is complete
            // Sometimes a social shared product from apps includes
            // an ice modifier, but menu adapter does not return
            // customizationOptions for BYOB/Combo drink swap products.
            if (!selectedCustomizationOptions) {
                return;
            }

            const options = IngredientsAdapter(
                ProteinOptionsAdapter(selectedCustomizationOptions)
            );
            options.forEach(option => {
                if (
                    option.code === modifierItem.plu &&
                    !adaptedModifiersCodes.includes(option.code)
                ) {
                    let { calories, accurateCalorie } = option;
                    let matchedCustomizationOption;

                    // If modifier is not the main variant in the Included options,
                    // calculate the calorie difference for the modifier.
                    // Ex:
                    // Cheese = 30 calories
                    // MINUS Cheese = 0 calories
                    // MINUS modifier calories = 0 - 30 = -30
                    if (option.modifier !== '') {
                        matchedCustomizationOption = selectedCustomizationOptions.find(
                            o =>
                                o.variantOptions.find(
                                    o2 => o2.code === option.code
                                )
                        );
                    } else if (!option.defaultProtein) {
                        // If modifier is not the defaultProtein in the Protein options,
                        // calculate the calorie difference for the modifier.
                        matchedCustomizationOption = selectedCustomizationOptions.find(
                            o => o.defaultProtein
                        );
                    }
                    if (matchedCustomizationOption) {
                        const {
                            accurateCalorieDiff,
                            caloriesDiff
                        } = calculateIncludedCalorieDifference(
                            accurateCalorie,
                            calories,
                            matchedCustomizationOption
                        );
                        calories = caloriesDiff;
                        accurateCalorie = accurateCalorieDiff;
                    }

                    adaptedModifiersCodes.push(option.code);
                    adaptedModifiers.push(
                        createModifierData(
                            false,
                            modifierItem.includedWithStyle,
                            modifierItem.opt,
                            {
                                ...option,
                                accurateCalorie,
                                calories
                            }
                        )
                    );
                }
            });
        }

        // grab the opt category then pull the variantOptions from it
        if (modifierItem.opt !== CSCItemModifierOptions.NOT_SELECTED) {
            let optionCategory = customizationOptions[modifierItem.opt];
            let isOnTheSide = false;

            if (Array.isArray(optionCategory) && optionCategory.length === 0) {
                optionCategory = [
                    ...customizationOptions[CSCItemModifierOptions.ADDON],
                    ...customizationOptions[CSCItemModifierOptions.SAUCE]
                ];
            }

            // TODO: Sync with with app teams and find a common solution.
            // Grilled style opt is passed in as 'addonOptions', but grilled style is
            // under 'grilled' from customizationOptions. We want to pull the grilled
            // customization options so we can match the selected option. This is a quick
            // fix because we do not want to update anything from menu adapter because it
            // could cause apps to break.
            switch (modifierItem.plu) {
                case StylePLU.FRESCO_STYLE:
                    optionCategory = updateStyleOptionCategory(
                        customizationOptions,
                        CSCItemModifierOptions.FRESCO_PRODUCT
                    );
                    break;
                case StylePLU.GRILLED_STYLE:
                    optionCategory = customizationOptions.grilled;
                    break;
                case StylePLU.SUPREME_STYLE:
                    optionCategory = updateStyleOptionCategory(
                        customizationOptions,
                        CSCItemModifierOptions.SUPREME_PRODUCT
                    );
                    break;
            }

            // check wether the modifier is a style card or not
            if (
                optionCategory &&
                modifierItem.opt.includes(customizationOption)
            ) {
                // We only want to change the opt at this point for styles only
                // because we do not want the code to hit the else if below,
                // which would cause the code to break.
                updateModifierOptForStyle(modifierItem);

                (optionCategory as CustomizationOption[]).forEach(
                    (optionItem: CustomizationOption) => {
                        // modifier is on the side
                        if (optionItem.code && modifierItem.ots) {
                            // can assume modifier type is ADD since it is on the side
                            const variantOption = optionItem.variantOptions.find(
                                variant =>
                                    variant.onTheSide === modifierItem.plu &&
                                    variant.modifierType ===
                                        CSCItemModifierType.ADD
                            );

                            if (
                                variantOption &&
                                !adaptedModifiersCodes.includes(
                                    variantOption.code
                                )
                            ) {
                                isOnTheSide = true;

                                adaptedModifiersCodes.push(variantOption.code);
                                adaptedModifiers.push(
                                    createModifierData(
                                        isOnTheSide,
                                        modifierItem.includedWithStyle,
                                        modifierItem.opt,
                                        variantOption
                                    )
                                );
                            }
                        } else if (
                            optionItem.code &&
                            optionItem.code.includes(modifierItem.plu)
                        ) {
                            const variantOption = optionItem.variantOptions.find(
                                variant => variant.code === modifierItem.plu
                            );

                            if (
                                variantOption &&
                                !adaptedModifiersCodes.includes(
                                    variantOption.code
                                )
                            ) {
                                adaptedModifiersCodes.push(variantOption.code);
                                adaptedModifiers.push(
                                    createModifierData(
                                        isOnTheSide,
                                        modifierItem.includedWithStyle,
                                        modifierItem.opt,
                                        variantOption
                                    )
                                );
                            }
                        }
                    }
                );
            } else if (
                optionCategory &&
                modifierItem.opt.includes(styleOption)
            ) {
                let variantOption: VariantOption | undefined;

                if (isStyleOption(optionCategory)) {
                    variantOption = optionCategory.variantOptions?.[0];
                } else if (isArrayOfCustomizationOptions(optionCategory)) {
                    variantOption = optionCategory[0].variantOptions?.[0];
                }

                if (
                    variantOption &&
                    !adaptedModifiersCodes.includes(variantOption.code)
                ) {
                    // Adjust styles to use baseProduct code, rather than variant.
                    variantOption.code = modifierItem.plu;
                    adaptedModifiersCodes.push(variantOption.code);
                    adaptedModifiers.push(
                        createModifierData(
                            isOnTheSide,
                            modifierItem.includedWithStyle,
                            modifierItem.opt,
                            variantOption
                        )
                    );
                }
            }
        }
    });

    return adaptedModifiers;
};

export const getTotalCartQuantity = (cart: CSCItem[]) => {
    const totalCartQuantity = cart.reduce(
        (totalQuantity, cartItemQuantity) =>
            totalQuantity +
            (cartItemQuantity.plu === KitchenMessages.NOUTENSILS
                ? 0
                : cartItemQuantity.qty || 0),
        0
    );
    return totalCartQuantity;
};

// get base price and combine with any modifiers, items, and item modifiers
export const getProductPrice = (
    baseProduct: Product,
    hhPrice: Price | undefined,
    isHH: boolean,
    items?: CSCItemDetail[],
    modifiers?: CSCModifierDetail[]
) => {
    const basePrice =
        isHH && hhPrice ? hhPrice.value : baseProduct.price?.value || 0;

    let itemModifiersPrices = 0;
    let itemPrice = 0;
    let modifierPrice = 0;

    if (items) {
        items.forEach((item: CSCItem) => {
            const modifierQty = item.qty || 1;

            return item.modifiers?.forEach(
                ({ includedWithStyle, price = 0 }: CSCModifierDetail) =>
                    (itemModifiersPrices +=
                        (includedWithStyle ? 0 : price) * modifierQty)
            );
        });

        items.forEach(
            ({ price, qty }: CSCItemDetail) => (itemPrice += price * (qty || 1))
        );
    }

    if (modifiers) {
        modifiers.forEach(
            ({ includedWithStyle, price = 0 }: CSCModifierDetail) =>
                (modifierPrice += includedWithStyle ? 0 : price)
        );
    }

    return basePrice + itemPrice + itemModifiersPrices + modifierPrice;
};

export const getProductSubtotal = (
    products: CSCItemTemplate[] = [],
    includeUnavailable: boolean = false
) => {
    let subtotal = 0;
    products.forEach(product => {
        // Do not include Unavailable items in total unless specified.
        // Cart icon subtotal should include all product prices on add.
        if (
            includeUnavailable ||
            (product.isAvailable && !product.isOutsideBreakfastTimeItem)
        ) {
            subtotal += ((product.price || 0) * 100 * product.qty) / 100;
        }
    });
    return subtotal;
};

/**
 * This function compares the products to pdpProductsJson and if there is an item in products
 * that is not in pdpProductsJson, then we delete from indexDB
 *
 * @param products - products from local cart
 * @param pdpProductsJson - products from nextProductUrl
 * @param local the current local cart in storage
 * @return boolean
 */
export const deleteProductFromCart = (
    products: CSCItem[],
    pdpProductsJson: Product[],
    local: LocalCart
) => {
    products.forEach(product => {
        let itemsWereDeleted = false;
        const productIsAvailable = pdpProductsJson.some(
            pdpProduct => pdpProduct.code === product.plu
        );

        if (product?.items) {
            const comboChildItemsAreAvailable = product.items.every(item =>
                pdpProductsJson.some(pdpProduct => pdpProduct.code === item.plu)
            );

            if (
                (!productIsAvailable || !comboChildItemsAreAvailable) &&
                local.deleteCartItem
            ) {
                local.deleteCartItem({
                    id: product.id,
                    plu: product.plu
                });

                itemsWereDeleted = true;
            }
        } else {
            if (!productIsAvailable && local.deleteCartItem) {
                local.deleteCartItem({
                    id: product.id,
                    plu: product.plu
                });

                itemsWereDeleted = true;
            }
        }

        return itemsWereDeleted;
    });
};
