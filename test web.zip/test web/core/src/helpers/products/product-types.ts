import { ProductTypes } from '@tb-core/constants/products';

export const isCombo = (productType: string) =>
    [ProductTypes.BYOB, ProductTypes.COMBO, ProductTypes.PARTYPACK].includes(
        productType.toLowerCase() as ProductTypes
    );

export const isDrink = (productType: string) =>
    productType.toLowerCase() === ProductTypes.DRINK;

export const isPartyPack = (productType: string) =>
    productType.toLowerCase() === ProductTypes.PARTYPACK;
