import { CSCItemModifierOptions } from '@tb-core/constants/client-side-cart';
import { ActionTypes, OnCustomize } from '@tb-core/hooks/product/use-customize';
import { Product } from '@tb-core/types/products';

// initializes the customize state for wherever product customization is neeeded
export const initCustomizeState = (
    product: Product,
    setCustomize: OnCustomize,
    productListPrice?: number
) => {
    if (product.code && setCustomize) {
        setCustomize({
            option: {
                accurateCalorie: product.accurateCalorie,
                calories: product.calories,
                code: product.code,
                opt: CSCItemModifierOptions.NOT_SELECTED,
                price: productListPrice
                    ? productListPrice
                    : product.price?.value || 0
            },
            type: ActionTypes.InitCustomize
        });
    }
};
