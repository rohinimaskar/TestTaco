import {
    CSCItemModifierOptions,
    CSCItemModifierType
} from '@tb-core/constants/client-side-cart';
import {
    findOptKeyByCode,
    findVariantOptionWithProperty
} from '@tb-core/helpers/products/variant';
import { FavoriteModifiers, FavoriteProduct } from '@tb-core/types/favorites';
import { CustomizationOptions, Product } from '@tb-core/types/products';

/**
 * Updates the modifier options for a given FavoriteModifier based on the provided customization options.
 *
 * @param {CustomizationOptions} options - The customization options for the product.
 * @param {FavoriteModifiers} modifier - The modifier to update.
 */
export const updateFavoritesModifierWithCustomizationOptions = (
    options: CustomizationOptions,
    modifier: FavoriteModifiers
): void => {
    const variant = findVariantOptionWithProperty(
        options,
        'code',
        modifier.plu
    );
    const variantOption = variant?.variantOptions?.find(
        option => option.code === modifier.plu
    );
    let opt = options ? findOptKeyByCode(options, modifier.plu) : modifier.opt;

    if (modifier.plu === '9999') {
        opt = CSCItemModifierOptions.GRILLABLE_PRODUCT;
    }

    modifier.opt = opt as CSCItemModifierOptions;
    modifier.modifierType =
        modifier.opt === CSCItemModifierOptions.GRILLABLE_PRODUCT
            ? CSCItemModifierType.ADD
            : variantOption?.modifierType || CSCItemModifierType.ADD;
};

/**
 * Updates the modifiers for a given FavoriteProduct based on the provided favorite products.
 *
 * @param {FavoriteProduct} product - The favorite product to update.
 * @param {Product[]} favoriteProducts - The list of favorite products to use for updates.
 * @returns {FavoriteProduct} - The updated favorite product.
 */
export const updateFavoriteProductModifiers = (
    product: FavoriteProduct,
    favoriteProducts: Product[]
): FavoriteProduct => {
    if (product?.modifiers && product.modifiers?.length > 0) {
        const favoriteProduct = favoriteProducts.find(
            item => item.code === product.plu
        );
        product.modifiers.forEach(modifier => {
            if (favoriteProduct?.customizationOptions) {
                updateFavoritesModifierWithCustomizationOptions(
                    favoriteProduct.customizationOptions,
                    modifier
                );
            }
        });
    }

    if (product?.items && product.items.length > 0) {
        product.items.forEach(item => {
            if (item?.modifiers && item.modifiers?.length > 0) {
                const favoriteProduct = favoriteProducts.find(
                    item => item.code === product.plu
                );

                item.modifiers.forEach(modifier => {
                    const productGroup =
                        favoriteProduct?.productGroups &&
                        favoriteProduct.productGroups.find(
                            productGroup =>
                                productGroup.groupID === item.groupID
                        );
                    const swapProduct =
                        productGroup?.swapList &&
                        (productGroup.swapList.find(
                            swapItem => swapItem.code === item.plu
                        ) as Product);

                    if (swapProduct?.customizationOptions) {
                        updateFavoritesModifierWithCustomizationOptions(
                            swapProduct.customizationOptions,
                            modifier
                        );
                    }
                });
            }
        });
    }

    return product;
};
