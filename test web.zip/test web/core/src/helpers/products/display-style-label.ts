import { CSCItemModifierOptions } from '@tb-core/constants/client-side-cart';
import usePageContext from '@tb-core/hooks/use-page-context';

const displayIncludedWithStyleLabel = (styleOption: CSCItemModifierOptions) => {
    const { content } = usePageContext();
    const { productCustomization } = content.pageData.topicMeta;

    if (productCustomization) {
        switch (styleOption) {
            case CSCItemModifierOptions.FRESCO_PRODUCT:
                return productCustomization.addFresco;
            case CSCItemModifierOptions.SUPREME_PRODUCT:
                return productCustomization.addSupreme;
            case CSCItemModifierOptions.VEGETARIAN_PRODUCT:
                return productCustomization.addVegetarian;
        }
    }
};

const displayRemovedWithStyleLabel = (styleOption: CSCItemModifierOptions) => {
    const { content } = usePageContext();
    const { productCustomization } = content.pageData.topicMeta;

    if (productCustomization) {
        switch (styleOption) {
            case CSCItemModifierOptions.FRESCO_PRODUCT:
                return productCustomization.removeFresco;
            case CSCItemModifierOptions.SUPREME_PRODUCT:
                return productCustomization.removeSupreme;
            case CSCItemModifierOptions.VEGETARIAN_PRODUCT:
                return productCustomization.removeVegetarian;
        }
    }
};

export { displayIncludedWithStyleLabel, displayRemovedWithStyleLabel };
