import getFavoritesCustomizedProduct from '@tb-core/providers/get-favorites-customized-product';

const customizedProductPropsUtil = async (
    customizedProductId = '',
    host = ''
) => {
    const customizedProduct = await getFavoritesCustomizedProduct(
        customizedProductId,
        host
    );

    return {
        customizedProduct
    };
};

export default customizedProductPropsUtil;
