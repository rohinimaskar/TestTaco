import { createModifierString } from '@tb-core/helpers/products/cart';
import { createHash } from '@tb-core/helpers/sha-generator';
import {
    CSCComboItem,
    CSCModifierDetail
} from '@tb-core/types/client-side-cart';

export const createComboProductModifierHash = (items: CSCComboItem[]) => {
    let modifierString = '';
    items?.forEach((item: CSCComboItem) => {
        modifierString += item.modifiers?.length
            ? `${item.plu}-${createModifierString(item.modifiers)}`
            : item.plu;
    });

    return modifierString;
};

/**
 * Creates a hash value based on the plus and modifiers
 * The point of hex encryption here is to proide a fixed-length, encoded value from data that has irregular-length
 *
 * This function is async because underlying encryption of the string-to-hash is async
 * @returns Promise<string> hex digest of string
 */
export const getModifierHash = async (
    plu: string,
    modifiers?: CSCModifierDetail[],
    items?: CSCComboItem[]
) =>
    items?.length
        ? createHash(createComboProductModifierHash(items)).then(
              hash => `${plu}-${hash}`
          )
        : modifiers?.length
        ? createHash(createModifierString(modifiers)).then(
              hash => `${plu}-${hash}`
          )
        : Promise.resolve(plu);
