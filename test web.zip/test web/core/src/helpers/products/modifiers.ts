import { CSCItemModifierOptions } from '@tb-core/constants/client-side-cart';
import {
    CSCComboItem,
    CSCItemModifier,
    CSCModifierDetail
} from '@tb-core/types/client-side-cart';
import { CustomizationOption, StyleOption } from '@tb-core/types/products';

interface ModifierProps {
    items?: CSCComboItem[];
    modifiers?: CSCModifierDetail[];
}

export type ModifierOptionType =
    | CustomizationOption
    | CustomizationOption[]
    | StyleOption
    | StyleOption[]
    | string[]
    | undefined;

const getComboModifiers = (items: CSCComboItem[]) => {
    const allComboMods: CSCItemModifier[] = [];
    for (const { modifiers } of items) {
        if (modifiers?.length) {
            allComboMods.push(...modifiers);
        }
    }
    return allComboMods;
};

export const getAllModifiers = (
    cscitem: ModifierProps
): CSCItemModifier[] | CSCModifierDetail[] => {
    if (cscitem.items?.length) {
        return getComboModifiers(cscitem.items);
    }
    return cscitem.modifiers || [];
};

export const mapGroupTypeToModifierOption = (type: string | undefined) => {
    switch (type) {
        case 'proteins':
            return CSCItemModifierOptions.PROTEIN;
        case 'addons':
            return CSCItemModifierOptions.ADDON;
        case 'included':
            return CSCItemModifierOptions.INCLUDE;
        case 'upgrades':
            return CSCItemModifierOptions.UPGRADE;
        default:
            return CSCItemModifierOptions.ADDON;
    }
};

export const isStyleOption = (item: ModifierOptionType): item is StyleOption =>
    typeof item === 'object' && 'addProducts' in item;

export const isArrayOfCustomizationOptions = (
    items: ModifierOptionType
): items is CustomizationOption[] =>
    Array.isArray(items) && items.some(item => typeof item !== 'string');
