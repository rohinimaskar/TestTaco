import { ProductIgnoreList } from '@tb-core/constants/products';
import { storeNationalId } from '@tb-core/helpers/next-env';
import getProduct from '@tb-core/providers/get-product';

const productPropsUtil = async (
    productId = '',
    host = '',
    storeId = storeNationalId
) => {
    const ignoreList: string[] = Object.values(ProductIgnoreList);
    const product = ignoreList.includes(productId as string)
        ? {}
        : await getProduct(productId, storeId, host);

    return {
        product
    };
};

export default productPropsUtil;
