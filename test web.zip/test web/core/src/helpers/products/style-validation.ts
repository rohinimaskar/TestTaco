import { CSCItemModifierOptions } from '@tb-core/constants/client-side-cart';
import { StyleModifiers } from '@tb-core/types/products';

// check if modifier code is included in the addProducts prop
// of a StyleModifier
export const isAddProductValid = (
    modifierCode: string,
    styleModifiers: StyleModifiers[]
) => {
    for (const styleModifier of styleModifiers) {
        if (styleModifier.addProducts) {
            for (const addProduct of styleModifier.addProducts) {
                if (addProduct.variantCodes.includes(modifierCode)) {
                    return true;
                }
            }
        }
    }
    return false;
};

// helps to validate if a selected style card should be deselected
export const isStyleOptionValid = (
    styleOpt: CSCItemModifierOptions,
    styleModifiers: StyleModifiers[]
) => {
    for (const styleModifier of styleModifiers) {
        if (styleModifier.opt === styleOpt) {
            return true;
        }
    }
    return false;
};
