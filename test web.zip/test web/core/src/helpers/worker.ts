export class WorkerHelper {
    private worker: Worker;
    private listener: (message: MessageEvent) => void;

    /**
     * Initialize the web workers and set the message event listeners with callback
     * functions passed to the constructor.
     * @param {Worker} worker
     * @param {function} listener
     */
    constructor(worker: Worker, listener: (message: MessageEvent) => void) {
        this.worker = worker;
        // Set for the removal of the listener in closeWorker function
        this.listener = listener;
        // Pass listener function to allow for custom handling of results
        this.worker.addEventListener('message', this.listener);
    }

    /**
     * Send the data object to the worker
     * @param {object} data
     */
    send(data: object) {
        this.worker.postMessage(data);
    }

    /**
     * Remove the event listeners and terminate the workers.
     * Terminate does not clean up after web worker.
     */
    closeWorker() {
        this.worker.removeEventListener('message', this.listener);
        this.worker.terminate();
    }
}
