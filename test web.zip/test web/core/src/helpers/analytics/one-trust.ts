/**
 * Checks if the user has granted consent for the group 'C0002' or 'C0001'.
 * C0001 is code for strictly necessary
 * @returns {boolean | null} - Returns true if consent is granted,
 * false if not, and null if the status is unknown.
 */
const oneTrustConsent = () => {
    if (typeof window !== 'undefined' && window.OnetrustActiveGroups) {
        return (
            window.OnetrustActiveGroups.includes('C0002') ||
            window.OnetrustActiveGroups.includes('C0001')
        );
    }

    return null;
};

export default oneTrustConsent;
