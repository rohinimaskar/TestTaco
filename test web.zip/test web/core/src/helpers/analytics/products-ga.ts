import {
    GaDataLayerConfig,
    gtmLinkClick,
    updateDataLayer
} from '@tb-core/helpers/analytics/google';
import { RealObject } from '@tb-core/types';
import { CartSummary } from '@tb-core/types/checkout/checkout-cart';
import { CSCItem, CSCItemModifier } from '@tb-core/types/client-side-cart';
import { Order } from '@tb-core/types/order';

export interface DataLayerProduct {
    category?: string;
    itemName?: string;
    plu?: string;
    price?: number;
    qty?: number;
    variant?: string;
}

export interface ActionField {
    affiliation?: string;
    coupon: string | string[];
    id: string;
    revenue: string;
    tax: string;
}

export const gaEntriesLocalCartMerge = ({
    cart,
    localCartItems
}: {
    cart?: CartSummary;
    localCartItems: CSCItem[];
}) => {
    const entries: DataLayerProduct[] | undefined = cart?.entries?.map(
        ({ product }, i) => {
            const itemMatch = product?.code === localCartItems[i]?.plu;

            return {
                category: product?.primaryCategory,
                itemName: product?.name,
                plu: product?.code,
                price: product?.price?.value,
                qty: itemMatch ? localCartItems[i].qty : 0,
                variant: product?.productType
            };
        }
    );

    return entries || [];
};

export const gaProductsAdjusted = (
    products: DataLayerProduct[],
    modifiers: CSCItemModifier[]
) => {
    const isProductArrValid =
        products && products.every(product => product.itemName);
    const productIsCustomized = (modifiers || []).length > 0;

    const updatedProducts =
        (products &&
            products.map(product => {
                return {
                    category: product.category,
                    dimension21: productIsCustomized
                        ? 'Customized'
                        : 'Standard',
                    dimension22: productIsCustomized
                        ? modifiers?.reduce(
                              (prev: {}, curr: {}) =>
                                  prev + JSON.stringify(curr),
                              ''
                          )
                        : 'No Customization',
                    id: product.plu || '',
                    name: product.itemName || '',
                    price: product.price || null,
                    quantity: product.qty || 1,
                    variant: product.variant || ''
                };
            })) ||
        [];

    return {
        isProductArrValid,
        updatedProducts
    };
};

export const updateDataLayerCheckoutStep = (
    products: DataLayerProduct[],
    step: number
) => {
    const { isProductArrValid, updatedProducts } = gaProductsAdjusted(
        products,
        []
    );
    // Check to make sure product array has valid items before pushing to data layer.
    if (!isProductArrValid) {
        return;
    }

    updateDataLayer({
        ecommerce: {
            checkout: {
                actionField: { step },
                products: updatedProducts
            }
        },
        event: 'checkout'
    });
};

// TODO: Remove after implementation of new Order Tracker page in Prod
// https://tacobeta.atlassian.net/browse/ECCUST-1422
export const updateDataLayerCheckoutCompletion = (
    actionField: ActionField,
    products: DataLayerProduct[]
) => {
    const { isProductArrValid, updatedProducts } = gaProductsAdjusted(
        products,
        []
    );
    // Check to make sure product array has valid items before pushing to data layer.
    if (!isProductArrValid) {
        return;
    }

    updateDataLayer({
        ecommerce: {
            purchase: {
                actionField,
                products: updatedProducts
            }
        },
        event: 'transaction'
    });
};

export const updateDataLayerOrderConfirmation = (order: Order) => {
    const actionField = {
        affiliation: order.pointOfService.storeNumber,
        coupon: order.appliedOrderPromotions,
        currency: order.totalPriceWithTax.currencyIso,
        id: order.guid,
        revenue: order.totalPriceWithTax.formattedValue,
        shipping: 0.0,
        tax: order.totalTax.formattedValue
    };

    updateDataLayer({
        ecommerce: {
            purchase: {
                actionField,
                products: order.entries.map(entry => ({
                    category: entry.product.primaryCategory,
                    coupon: [],
                    id: entry.product.code,
                    name: entry.product.name,
                    price: entry.basePrice.value,
                    quantity: entry.quantity,
                    variant: entry.product.productType
                }))
            }
        },
        event: 'transaction'
    });
};

export const updateDataLayerProductRemove = (
    product: DataLayerProduct,
    modifiers: CSCItemModifier[]
) => {
    const { isProductArrValid, updatedProducts } = gaProductsAdjusted(
        [product],
        modifiers
    );
    // Check to make sure product array has valid items before pushing to data layer.
    if (!isProductArrValid) {
        return;
    }

    updateDataLayer({
        ecommerce: {
            currencyCode: 'USD',
            remove: {
                products: updatedProducts
            }
        },
        event: 'removeFromCart'
    });
};

export const updateDataLayerProductAdd = (
    product: DataLayerProduct,
    modifiers: CSCItemModifier[]
) => {
    const { isProductArrValid, updatedProducts } = gaProductsAdjusted(
        [product],
        modifiers
    );
    // Check to make sure product array has valid items before pushing to data layer.
    if (!isProductArrValid) {
        return;
    }

    updateDataLayer({
        ecommerce: {
            add: {
                products: updatedProducts
            },
            currencyCode: 'USD'
        },
        event: 'addToCart'
    });
};

export const updateDataLayerProductIngredient = ({
    gaDataLayerConfig,
    ingredientLocation,
    product
}: {
    gaDataLayerConfig?: GaDataLayerConfig;
    ingredientLocation: string;
    product: RealObject;
}) => {
    const { productGroup = '', name = '', code = '' } = product;

    updateDataLayer({
        ...gaDataLayerConfig,
        'Analytics-Value': `Customizer Layer>${ingredientLocation}>:${productGroup}:${name}`,
        'analytics-ingredientPLU': code
    });
};

export const updateQuantityDataLayer = (
    productName: string,
    quantity: number | undefined
) => {
    gtmLinkClick({
        'Analytics-Action': 'Update Quantity',
        'Analytics-Value': `Update Quantity>${productName}>${quantity}`
    });
};
