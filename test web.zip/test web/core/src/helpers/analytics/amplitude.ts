import * as amplitude from '@amplitude/analytics-browser';
import { BrowserClient } from '@amplitude/analytics-types';
import { Experiment, ExperimentClient } from '@amplitude/experiment-js-client';
import { webAttributionPlugin } from '@amplitude/plugin-web-attribution-browser';
import { datadogLogs } from '@datadog/browser-logs';
import { NextRouter } from 'next/router';

import { ContentfulMetaDataUserTags } from '@tb-core/constants/contentful';
import { toError } from '@tb-core/helpers/fetch';
import { amplitudeKey, webFixedVersion } from '@tb-core/helpers/next-env';

interface AmplitudeWithExperiment extends BrowserClient {
    experiment?: ExperimentClient;
}

export const setAmplitudeUserStatus = (isLoggedIn?: boolean) =>
    typeof isLoggedIn !== 'undefined'
        ? {
              user_status: isLoggedIn
                  ? ContentfulMetaDataUserTags.USER_LOGGED_IN
                  : ContentfulMetaDataUserTags.USER_GUEST
          }
        : {};

const getUTMValue = (param: string | string[] | undefined) =>
    param && param.toString().toLowerCase() !== 'none' ? param : 'Direct';

export const amplitudeInitialize = async (
    query?: NextRouter['query'],
    userId?: string
) => {
    const utmParameters = {
        utm_campaign: getUTMValue(query?.utm_campaign),
        utm_medium: getUTMValue(query?.utm_medium),
        utm_source: getUTMValue(query?.utm_source)
    };

    amplitude.add(webAttributionPlugin());

    const identify = new amplitude.Identify();
    for (const [key, value] of Object.entries(utmParameters)) {
        identify.set(key, value);
    }
    amplitude.identify(identify);

    amplitude.init(amplitudeKey, userId, {
        appVersion: webFixedVersion,
        autocapture: false,
        defaultTracking: {
            sessions: true
        },
        identityStorage: 'none',
        logLevel: 2
    });
    const deviceId = amplitude.getDeviceId();
    const amplitudeWithExperiment: AmplitudeWithExperiment = amplitude;
    const experiment = Experiment.initializeWithAmplitudeAnalytics(
        amplitudeKey
    );

    try {
        // Start experiment with either userId or deviceId
        await experiment.start({
            ...(userId ? { user_id: userId } : { device_id: deviceId })
        });
        // Attach experiment client to Amplitude instance
        amplitudeWithExperiment.experiment = experiment;
    } catch (e) {
        const error = toError(e);
        datadogLogs.logger.log('Experiment initialization error', error);
    }

    return amplitudeWithExperiment.experiment;
};

export const isExperimentActive = (
    experiment: ExperimentClient,
    variantName: string
) => (experiment ? experiment?.variant(variantName)?.value === 'on' : false);
