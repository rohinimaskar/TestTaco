import { NextApiRequest, NextApiResponse } from 'next';
import { ApiError } from 'next/dist/server/api-utils';

import Fetch, { FetchOptions } from '@tb-core/helpers/fetch';
import { host as apiHost } from '@tb-core/helpers/next-env';
import { RealObject } from '@tb-core/types';

export interface NextApiConfig extends FetchOptions {
    mock?: string;
    nextReq: NextApiRequest;
    nextRes: NextApiResponse;
}

type ErrorResponse = Pick<Response, 'status' | 'statusText'>;

// `true` for ApiError() as well as generic Error()
const isError = (exception: unknown): exception is Error =>
    exception instanceof Error;

/**
 * Convert caught error of type unknown to ErrorResponse
 * Possible overlap with `toError` in core/src/helpers/fetch.ts
 *
 * Future Option: add optional `stack` to return object:
 *   statusText: doStuff,
 *   ...(isError(exception) && { stack: exception.stack })
 */
const toErrorResponse = (exception: unknown): ErrorResponse => {
    const internalServerError = 500;
    const errorText = 'Internal Server Error';

    return {
        status:
            exception instanceof ApiError
                ? exception.statusCode
                : internalServerError,
        statusText: isError(exception)
            ? exception.message
            : typeof exception === 'string'
            ? exception
            : errorText
    };
};

/**
 * Check content-type before calling res.json(),
 * else wraps res.text() as message property of result
 */
const responseToJson = async (res: Response): Promise<RealObject> => {
    const contentType = res.headers.get('content-type');
    if (contentType?.includes('application/json')) {
        return await res.json();
    } else {
        const text = await res.text();

        try {
            const data = JSON.parse(text);
            return data;
        } catch (e) {
            console.error('Unable to parse response as JSON, send as text', e);
            return { message: text };
        }
    }
};

export default async function NextApi({
    host = apiHost,
    nextRes,
    ...config
}: NextApiConfig) {
    try {
        const res: Response = await Fetch({ ...config, host });
        const data = await responseToJson(res);
        return nextRes.status(res.status).json(data);
    } catch (e) {
        // convert unknown 'e' to an object of type ErrorResponse
        const err = toErrorResponse(e);
        console.warn(
            `\nNext API caught exception requesting ${config.url}
            \n\t${e}`,
            err
        );
        return nextRes.status(err.status).json({ message: err.statusText });
    }
}
