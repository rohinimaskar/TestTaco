import { CSCItemModifierType } from '@tb-core/constants/client-side-cart';
import { sortModifiers } from '@tb-core/helpers/products/cart';
import { getModifierHash } from '@tb-core/helpers/products/create-combo-product-modifier-hash';
import { LocalCart } from '@tb-core/hooks/client-side-cart/use-cart';
import {
    CSCComboItem,
    CSCItem,
    CSCItemModifier
} from '@tb-core/types/client-side-cart';
import {
    EntryCustomization,
    OptionalModifiers,
    OrderEntry,
    OrderProduct
} from '@tb-core/types/order';

interface AddPreviouslyOrderedItemsToCartProps {
    entries: OrderEntry[];
    local: LocalCart;
}

interface AddItemProps {
    optionalModifiers: OptionalModifiers[];
    product: OrderProduct;
    quantity: number;
}

interface AdaptModifiersProps {
    index: number;
    optionalModifiers: OptionalModifiers[];
}

type ComboItems = ({
    optionalModifiers
}: {
    optionalModifiers: OptionalModifiers[];
}) => CSCComboItem[];

type AddItemType = (props: AddItemProps) => CSCItem;

// Creates the CSC Item that will be added to local cart
const createCartItem: AddItemType = ({
    optionalModifiers,
    product,
    quantity
}) => {
    const modifiers =
        optionalModifiers?.length === 1
            ? adaptModifiers({ index: 0, optionalModifiers })
            : [];

    const cartItem: CSCItem = {
        id: '',
        itemName: product.name,
        plu: product.code,
        qty: quantity,
        variant: product.productType
    };

    if (modifiers?.length) {
        cartItem.modifiers = sortModifiers(modifiers);
    }

    if (optionalModifiers?.length > 1 && modifiers?.length !== 1) {
        cartItem.items = setComboItems({ optionalModifiers });
    }

    return cartItem;
};

const setComboItems: ComboItems = ({ optionalModifiers = [] }) =>
    optionalModifiers?.map((mod, index) => ({
        groupCode: mod?.productGroupCode,
        modifiers: adaptModifiers({ optionalModifiers, index }),
        plu: mod?.product?.code,
        qty: mod?.quantity
    }));

const adaptModifiers = ({
    index,
    optionalModifiers = []
}: AdaptModifiersProps) => {
    const itemModifiers: CSCItemModifier[] = [];
    const { includedItems, tastyUpgrades } = optionalModifiers?.[index];

    const getItemModifier = ({ modifier, group }: EntryCustomization) => {
        itemModifiers.push({
            includedWithStyle: modifier.includedWithStyle,
            opt: group,
            ots: modifier.modifierType === CSCItemModifierType.SIDE,
            plu: modifier.code || ''
        });
    };

    includedItems?.forEach(getItemModifier);
    tastyUpgrades?.forEach(getItemModifier);

    return itemModifiers;
};

export const addPreviouslyOrderedItemsToCart = async ({
    entries,
    local
}: AddPreviouslyOrderedItemsToCartProps) => {
    for (const entry of entries) {
        if (!entry.availableForReorder) {
            return;
        }

        const { optionalModifiers, product, quantity } = entry;

        const cartItem = createCartItem({
            optionalModifiers,
            product,
            quantity
        });

        cartItem.id = await getModifierHash(
            product.code,
            cartItem.modifiers,
            cartItem.items
        );

        if (local && local.addCartItem) {
            local.addCartItem(cartItem);
        }
    }
};
