import { Document } from '@contentful/rich-text-types';

import { ServerSideProps } from '@tb-core/next/types';
import { RealObject } from '@types/index.d';

interface ContentfulAuth {
    accessToken: string;
    space: string;
}

export interface ContentfulDeliveryClientRequest extends ContentfulAuth {
    environment?: 'master' | string;
    host: ContentfulDeliveryHost;
    /* @example `{ 'fields.<field_name>[in]': 'accessories,flowers' }` */
    search?: RealObject<string>;
    type: string;
}

export interface ContentfulDeliveryClientConfig {
    accessToken: string;
    environment?: 'master' | string;
    host: ContentfulDeliveryHost;
    space: string;
}

export type ContentfulDeliveryHost =
    | 'cdn.contentful.com'
    | 'preview.contentful.com';

export interface ContentfulEntry<T = RealObject> {
    fields: T;
    sys?: Partial<Sys & ContentfulSysContentType>;
}

export type ContentfulEntryFields = {
    [P in ContentfulEntryMeta.raw]: ContentfulEntryMeta.raw[P];
} &
    ContentfulEntryMeta;

export interface ContentfulEntryMeta {
    contentType: string;
    raw: ContentfulEntry.fields;
}

export interface ContentfulEntryResponse<T = RealObject> {
    limit: number;
    items: Array<ContentfulEntry<T>>;
    skip: number;
    sys: Sys;
    total: number;
}

export interface ContentfulGetContentArgs {
    clientConfig: ContentfulDeliveryClientConfig;
    contentType: string;
    searchParams?: RealObject<string>;
}

interface ContentfulGraphQlRequest {
    isPreview?: boolean;
    query: string;
}

export type ContentfulPageProps = ServerSideProps<ContentfulEntry['fields']>;

export interface ContentfulSysContentType {
    contentType: Partial<ContentTypeLink>;
}

/* GraphQL Types */
export interface ContentfulDynamicEntry {
    __typename: string;
}

export interface ContentfulRichTextFields {
    text: string | null;
}

export interface ContentfulRichTextDocument {
    json: Document;
    links?: ContentfulRichTextDocumentLink;
}

interface ContentfulRichTextDocumentLink {
    entries: ContentfulRichTextDocumentLinkEntry;
}

interface ContentfulRichTextDocumentLinkEntry {
    inline: ContentfulRichTextDocumentLinkEntryInline[];
}

interface ContentfulRichTextDocumentLinkEntryInline {
    alt: string;
    src: string;
    srcset: string | null;
    sys: Sys;
}

export interface ContentfulFlashMessage {
    entryTitle: string;
    message: ContentfulRichTextDocument;
    type: ContentfulFlashMessageType;
}

export type ContentfulFlashMessageType =
    | 'Emergency'
    | 'Maintenance'
    | 'Green'
    | 'Purple'
    | 'Magenta'
    | 'Teal'
    | 'Sunset'
    | 'Violet'
    | 'Dark Purple';

/* Media Types - Start */
export interface ContentfulGraphic {
    alt: string;
    graphic: ContentfulImage | ContentfulSvg;
    name: string;
    title?: string;
}

export interface ContentfulImage {
    alt: string;
    name: string;
    src: string;
    srcSet?: string;
    title?: string;
}

export interface ContentfulSvg {
    id: string;
    name: string;
}
/* Media Types - End */

/* Metadata Types - Start */
export interface ContentfulMetaDataTags {
    id: string;
}
export interface ContentfulMetaData {
    tags?: ContentfulMetaDataTags[];
}
/* Metadata Types - End */
