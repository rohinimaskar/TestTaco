import {
    CurrencyValue,
    Entry,
    GuestUserInfo
} from '@tb-core/types/checkout/checkout-cart';
import {
    CreditCardInfo,
    GiftCardInfo
} from '@tb-core/types/checkout/credit-and-gift-cards.d';
import { DefaultResponseProps } from '@tb-core/types/index.d';
import { PickupMethod } from '@tb-core/types/location';

export interface SubmitOrderLoggedInUserProps {
    cartCode: string;
    firstName?: string;
    paymentTokens: string[];
    qrCodeEnabled: boolean;
}

export interface SubmitOrderGuestUserProps {
    cartGuid: string;
    guestUserId: string;
    guestUserInfo: GuestUserInfo;
    paymentTokens: string[];
    qrCodeEnabled: boolean;
}

export interface SubmitOrderPayload {
    payAtStore: boolean;
    paymentTokens: string[];
    pickupMethod?: string;
    pickupPerson: string;
    qrCodeEnabled: boolean;
    registration: boolean;
}

export interface SubmitOrderGuestUserPayload extends SubmitOrderPayload {
    guestRegisterForm: {
        email: string;
    };
    newsEmailOption: boolean;
}

/**
 * @interface SubmitOrderResponse
 *
 *  When user pays there is basically 3 possibilities:
 *  1. Credit Card is used: `paymentInfo` will be present
 *  2. Gift Card(s) is used: `gcPaymentInfoList` will be present
 *  3. Gift Card(s) AND Credit Card is used: `gcPaymentInfoList` is present AND `paymentInfo` is present!
 */
export interface SubmitOrderResponse extends DefaultResponseProps {
    appliedOrderPromotions: string | string[];
    appliedProductPromotions: [];
    appliedVouchers: [];
    calculated: boolean;
    code: string;
    cupChargePrice: CurrencyValue;
    entries: Entry[];
    gcPaymentInfoList?: GiftCardInfo[];
    guid: string;
    paymentInfo?: CreditCardInfo;
    pickupMethod: PickupMethod;
    posOrderId: string;
    roundUpFlag?: boolean;
    status: string;
    statusDisplay: string;
    store: string;
    tacoBellOrderStatus: string;
    totalPriceWithTax?: CurrencyValue;
    totalTax?: CurrencyValue;
    type: string;
    xenialOrderId: string;
}
