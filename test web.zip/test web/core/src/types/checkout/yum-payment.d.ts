export enum YumPageType {
    GUEST_CHECKOUT = 'GUEST_CHECKOUT',
    USER_CHECKOUT = 'USER_CHECKOUT',
    USER_SAVE_NEW_CARD = 'USER_SAVE_NEW_CARD'
}

export enum YumPaymentMethodType {
    BANK_CARD = 'BANK_CARD', // "BANK_CARD" used for GIFT_CARD as well currently
    GIFT_CARD = 'GIFT_CARD',
    APPLE_PAY = 'APPLE_PAY',
    GOOGLE_PAY = 'GOOGLE_PAY'
}

export enum YumPaymentLocaleCode {
    EN = 'en' // Only "en" currently supported
}

export interface YumPaymentSessionConfigResponse extends DefaultResponseProps {
    statusCode?: number;
    message?: {
        createCustomerPaymentSession?: {
            sessionConfig?: string;
            session?: {
                sessionId?: string;
            };
        };
    };
}
