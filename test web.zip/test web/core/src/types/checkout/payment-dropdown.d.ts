import { PaymentTypes } from 'tb-purchase/src/types';
export interface DropdownClickProps {
    cardId: string;
    paymentType: PaymentTypes;
}

export type OnDropdownClick = React.Dispatch<
    React.SetStateAction<DropdownClickProps>
>;

export interface PaymentDropdownOptionProps {
    cardId: string;
    cardNumber?: string;
    cardType?: string;
    creditCardIconId: string;
    defaultPayment?: boolean;
    groupDefaultItem?: boolean;
    payLabel?: string;
    payLabelSub?: string;
    paymentType: PaymentTypes;
}

export interface PaymentDropdownProps {
    disabled?: boolean;
    initialIndex?: number;
    onDropdownClick: OnDropdownClick;
    options: PaymentDropdownOptionProps[];
    showContactInfoError?: () => void;
    tabIndex?: number;
}
