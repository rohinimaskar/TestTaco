import { DefaultResponseProps } from '@tb-core/types/index.d';
import { PaymentTypes } from 'tb-purchase/src/types';
import { CartResponse, CartSummary } from './checkout-cart';

export interface AddGiftCardPayload {
    token: string; // response from Yum Payment tokenizeGiftCard
}

export interface AddGiftCardPayloadLoggedInUser extends AddGiftCardPayload {
    save: string;
}

export interface AddGiftCardPropsBase {
    giftCardNumber: string; // a 16 digit-string
    pin: string;
}

export interface AddGiftCardGuestUserProps extends AddGiftCardPropsBase {
    cartId: string; // a long hyphen-separated string, represented as `guid` in cart response
    guestAccessToken: string;
    guestUserId: string;
}

export interface AddGiftCardLoggedInUserProps extends AddGiftCardPropsBase {
    cartCode: string; // an 8-digit string, represented as `code` in cart response
}

export interface AddGiftCardToUserAccountProps extends AddGiftCardPropsBase {
    customerId: string;
}

export interface AddGiftCardGuestUserToken {
    cartId: string; // a long hyphen-separated string, represented as `guid` in cart response
    guestAccessToken: string;
    guestUserId: string;
    yumGiftCardToken: string; // response from Yum Payment tokenizeGiftCard
}

export interface AddGiftCardLoggedInUserToken {
    cartCode: string; // an 8-digit string, represented as `code` in cart response
    yumGiftCardToken: string; // response from Yum Payment tokenizeGiftCard
}

export interface AddGiftCardToUserAccountToken {
    customerId: string;
    yumGiftCardToken: string; // response from Yum Payment tokenizeGiftCard
}

export interface CreditCardInfo {
    accountHolderName?: string;
    authorizationFailed?: boolean;
    cardNumber?: string;
    cardType: { code?: string };
    defaultPayment?: boolean;
    expiryMonth?: number;
    expiryYear?: number;
    id: string;
    isCardSelected?: boolean;
    paymentToken?: string;
    saved?: boolean;
}

export interface GiftCardInfo {
    balance: number;
    cardNumber: string;
    cardThumbnail?: string;
    defaultPaymentInfo: boolean;
    expiryMonth?: string;
    expiryYear?: string;
    id: string;
    isCardSelected: boolean;
    paymentToken?: string;
    saved: boolean;
}

export interface GiftCardInfoResponse
    extends GiftCardInfo,
        DefaultResponseProps {}

export interface GiftCardListProps {
    cart: CartSummary;
    eBonusCardTitle?: string;
    giftCards: GiftCardInfo[];
    giftCardTitle?: string;
    guestUserId?: string;
    togglePaymentMethod: TogglePaymentMethod;
}

export interface GiftCardProps {
    cart: CartSummary;
    giftCard: GiftCardInfo;
    guestUserId?: string;
    title: string;
    togglePaymentMethod: TogglePaymentMethod;
}

export interface OauthTokenResponse extends DefaultResponseProps {
    access_token: string;
}

export interface PaymentDetailsResponse {
    gcPaymentInfos: GiftCardInfo[];
    ccPaymentInfos: CreditCardInfo[];
    success: boolean;
}

export interface PaymentMethodProps {
    accessToken?: string;
    cardId: string;
    cartCode: string;
    isCardSelected?: boolean;
    guestUserId?: string;
}

export interface PaymentOption {
    fileName: string;
    payLabel: string;
    paymentType: PaymentTypes;
}

export type AddCreditCardToList = (result: CreditCardInfo) => void;
export type AddGiftCardToList = (
    result: CartResponse | GiftCardInfoResponse
) => void;
export type SelectSavedCreditCardMethod = (
    props: PaymentMethodProps
) => Promise<CartResponse>;
export type TogglePaymentMethod = (
    paymentInfo: PaymentMethodProps
) => Promise<CartResponse | GiftCardInfoResponse>;
