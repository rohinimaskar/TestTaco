import { PickupTypes } from '@tb-core/constants/ordering';
import { LocalCart } from '@tb-core/hooks/client-side-cart/use-cart';
import {
    CreditCardInfo,
    GiftCardInfo
} from '@tb-core/types/checkout/credit-and-gift-cards';
import { CSCItem } from '@tb-core/types/client-side-cart';
import { DefaultResponseProps } from '@tb-core/types/index.d';
import {
    CustomizationOption,
    MenuProductCategory
} from '@tb-core/types/products';
import { StoreAddress } from '@tb-core/types/stores';

export interface CartResponse extends DefaultResponseProps, CartSummary {
    actualTotalCount: number;
    addedGCPaymentInfo: GiftCardInfo;
    addedCCPaymentInfo: CreditCardInfo;
    fastFavoriteOrder: boolean;
    gcPaymentInfoList: GiftCardInfo[];
    phoneNumber: string;
    totalItems: number;
    totalPrice: CurrencyValue;
    userCardInfo: {
        gcPaymentInfos: GiftCardInfo[];
    };
}

export interface CartSummary {
    code: string;
    cupChargePrice: CurrencyValue;
    entries: Entry[];
    guid: string;
    orderType?: PickupTypes;
    roundUpAmount: CurrencyValue;
    roundUpFlag?: boolean;
    subTotal: CurrencyValue;
    totalDiscounts?: CurrencyValue;
    totalItems?: number;
    totalPriceWithTax: CurrencyValue;
    totalTax: CurrencyValue;
}

export interface CheckoutCartBase {
    guestUserId?: string;
}

export interface CheckoutCartSummary extends CheckoutCartBase {
    isCartLoading: boolean;
    isErrorGetOrderSummaryCartObject: boolean;
    isRoundUpFlag: boolean;
    orderSummaryError?: OrderSummaryError;
    qrCodeEnabled: boolean;
    setIsDoneCheckout: (doneStatus: boolean) => void;
    unavailableProducts: string[];
}

export interface CurrencyValue {
    currencyIso: string;
    formattedValue?: string;
    priceType?: string;
    value: number;
}

export type OrderSummaryResponse =
    | OrderSummarySuccessResponse
    | OrderSummaryErrorResponse;
export interface OrderSummarySuccessResponse extends CheckoutCartBase {
    cart: CartResponse;
    selectedStore: SelectedStoreResponse;
    success: true;
}

export interface OrderSummaryErrorResponse {
    errors?: OrderSummaryError[];
    success: false;
    message?: string;
}
export interface OrderSummaryError {
    message: string;
    reason: string;
    subject?: string;
    type: string;
}

export interface SelectedStoreResponse {
    address: StoreAddress;
    capabilities: StoreCapabilities;
    currentOnlineAvailable: boolean;
    isCurbSideAvailable: boolean;
    name: string;
    qrCodeEnabled: boolean;
    roundUpFlag?: boolean;
}

export interface StoreCapabilities {
    breakfast: boolean;
    cateringEnabled: boolean;
    deliveryEnabled: boolean;
    driveThru: boolean;
    ghSiteId: string;
    isPickRestaurant: boolean;
    manualDeliveryDisable: boolean;
    mobileEnabled: boolean;
    online: boolean;
    openLate: boolean;
    supportKFC: boolean;
    supportPizza: boolean;
}

export interface Entry {
    product: EntryProduct;
    quantity?: number;
}

export interface EntryProduct extends CustomizationOption {
    categories?: MenuProductCategory[];
    isAvailableInStore: boolean;
    name: string;
}

export interface GuestUserInfo {
    email: string;
    name: string;
    signUpOption: boolean;
}

export type SetGuestUserInfo = (userInfo: GuestUserInfo) => void;
