// Contentful type definitions specific to Products
import { ContentfulRichTextFields, ContentfulSvg } from 'contentful';

import { ContentfulMetaData } from '@tb-core/types/contentful';

export interface ContentfulProductCategory {
    contentfulMetadata?: ContentfulMetaData;
    color?: string;
    hideFromMenu?: boolean;
    graphic?: ContentfulSvg;
    index?: number;
    label: string;
    seoCanonicalUrl?: string;
    seoDescription?: string;
    seoFooterDescription?: ContentfulRichTextDocument;
    seoLocalizedCanonicalUrl?: string;
    seoLocalizedDescription?: string;
    seoLocalizedFooterDescription?: ContentfulRichTextDocument;
    seoLocalizedTitle?: string;
    seoTitle?: string;
    slug: string;
    storeId?: string;
    subtitle?: string;
    webImageUrl?: string;
}
