import { NextRouter } from 'next/router';

export interface AmplitudeData {
    page_path?: string;
    page_title?: string;
}

export interface AmplitudeExperimentProps {
    isLoggedIn: boolean | undefined;
    query?: NextRouter['query'];
    userUid?: string;
}
