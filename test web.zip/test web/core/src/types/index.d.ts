import { ContentfulCollection } from 'contentful';
import { CSSProperties } from 'react';

import { ResponsiveVideoProps } from '@tb-core/components/behavior/responsive-video';
import { SafeAnchorWithGaEventProps } from '@tb-core/components/behavior/safe-anchor/with-ga-event';
import { CountdownTimerLabelPosition } from '@tb-core/components/container/countdown-timer';
import { GraphicProps } from '@tb-core/components/simple/graphic';
import { ResponsiveMediaProps } from '@tb-core/components/simple/responsive-media';
import { SvgProps } from '@tb-core/components/simple/svg';
import { ImageProps } from '@tb-core/components/styled/image';
import { LoyaltyLoggedOutProps } from '@tb-core/components/styled/loyalty-dashboard/logged-out';
import { RichContent } from '@tb-core/components/styled/rich-text/index.d';
import { GaDataLayerConfig } from '@tb-core/helpers/analytics/google';
import {
    ContentfulDynamicEntry,
    ContentfulRichTextDocument
} from '@tb-core/types/contentful.d';
import { LoyaltyDashboardResponse } from '@tb-core/types/loyalty.d.ts';

interface NoticeApi {
    LoadNotices: (notices: any[]) => void;
}

interface OneTrust {
    NoticeApi: NoticeApi;
}
declare global {
    interface Window {
        OneTrust: OneTrust;
        OnetrustActiveGroups: string;
    }
}
export interface AppConfig {
    MOCKS: string | null;
}

export interface GenericResponseError {
    message: string;
    reason: string;
}

export interface DefaultResponseProps {
    errors?: GenericResponseError[];
    status?: number;
    success: boolean;
}

export interface ClientCache {
    cookies: RealObject | null;
    local: RealObject | null;
    session: RealObject | null;
}

export interface ContentProps<T = RealObject> {
    backgroundImage?: GraphicProps;
    description?: RichContent;
    entries?: T[];
    title?: string;
}

export type Errors = string[];

export type GaConfigResolve<T = Props<string>> = (
    props: T
) => GaDataLayerConfig;

export interface ColorThemeProps {
    containerBackground?: string;
    containerText?: string;
    font?: ThemeFonts;
    legalText?: string;
    legalBackground?: string;
    moduleUiActive?: string;
    moduleUiInactive?: string;
    primaryButtonBackground?: string;
    primaryButtonBorder?: string;
    primaryButtonText?: string;
    secondaryButtonBackground?: string;
    secondaryButtonBorder?: string;
    secondaryButtonText?: string;
    titleText?: string;
    webLink?: string;
}

export interface CarouselConfigProps {
    carouselClassName?: string;
    slidesToShowDesktop?: number;
    slidesToShowMobile?: number;
}

export interface GenericChildContentProps
    extends Omit<GenericContentProps, 'title'> {
    className?: string;
    colorTheme: ColorThemeProps;
    contentLink: LinkProps;
    gaDataLayerConfig?: RealObject;
    entriesCollection: ContentfulCollection<SafeAnchorWithGaEventProps>;
    itemTitle: string;
}

interface BynderAssetProps {
    src: string;
    width?: number;
    height?: number;
    thumbnails?: Record<string, any>;
}

// @todo update GenericContentProps type per Contentful json
export interface GenericContentProps {
    answer?: ContentfulRichTextDocument;
    backgroundImage: ResponsiveMediaProps;
    carouselConfig?: CarouselConfigProps;
    colorTheme: ColorThemeProps | null;
    contentLink: LinkProps | null;
    daypart: 'Breakfast' | 'Happier Hour' | null;
    description: ContentfulRichTextDocument;
    entryTitle?: string;
    entriesCollection: ContentfulCollection<RealObject>;
    footnoteExcerpt?: ContentfulRichTextDocument;
    footnote?: ContentfulRichTextDocument;
    fragmentIdentifier?: string;
    imageAlt?: string;
    imageSrc?: BynderAssetProps[string];
    imageSrcset?: BynderAssetProps[string];
    horizontalPosition?: 'Center' | 'Left' | 'Right' | null;
    menuTiles: MenuSvgTileProps[];
    isBanner?: boolean;
    isCollapsible?: boolean;
    setToPtZone?: boolean;
    promoEndDateTime?: string | null;
    promoStartDateTime?: string | null;
    subtitle: null | string;
    title?: string;
    type?: GenericContentType;
    heroSize?: 'default' | 'medium' | 'slim' | null;
    question?: string;
    contentfulMetadata: { tags: Array<Record<string, any>> };
    wordmark: (ImageProps | SvgProps) & ContentfulDynamicEntry;
}

export enum GenericContentType {
    Banner = 'banner',
    Bucket = 'bucket',
    Carousel = 'carousel',
    Fallback = 'fallback',
    Faq = 'faq',
    Hero = 'hero',
    Menu = 'menu',
    Text = 'text',
    Tile = 'tile'
}

export enum ThemeFonts {
    GTAMERICA = 'GTAmerica'
}

export interface GenericModuleProps extends GenericContentProps {
    className?: string;
    entriesCollection: ModuleEntriesCollection;
    style?: CSSProperties;
}

export interface HeaderData {
    cartLabel: string;
    loggedIn: boolean;
    logo: string;
    storeId: string;
    storeLabel1: string;
    storeLabel2: string;
}

export type InteractionEvent =
    | React.MouseEvent
    | React.KeyboardEvent<HTMLButtonElement>;

type JsxChildren = JSX.Element | JSX.Element[];

export interface LayoutNavigationProps {
    links?: LinkProps[];
    utilityLinks?: LinkProps[];
}

export type ChildLinkProps = Pick<LinkProps, 'url' | 'label'>;

export interface LinkProps {
    gaDataLayerConfig?: RealObject;
    graphic?: GraphicProps;
    label?: string;
    // ECCONT-525: Update Contentful Link ID field to Action
    // linkId is named Action in Contentful but Field ID will still refer to linkId
    linkId?: string;
    onClick?: () => void;
    url: string;
    childLinksCollection?: { items: ChildLinkProps[] };
}

export type LooseObject = { [key: string]: string } | any;

export interface MiniCart {
    miniCartCount: number;
    miniCartPrice: string;
}

export type ModuleEntriesCollection = ContentfulCollection<
    GenericContentProps | SafeAnchorWithGaEventProps | RealObject
>;

export interface PageData {
    footer: RealObject;
    header: RealObject;
    leftAside: RealObject;
    main: RealObject;
    title: string;
}

export type PageControl =
    | 'Cart'
    | 'Loyalty'
    | 'Product Search'
    | 'User'
    | 'Selected Store';

export type Props<T = any> = RealObject<T>;

export interface PromoContentProps extends GenericContentProps {
    promoCurrentTime?: string | null;
    promoIsStart?: boolean | null;
    promoRemainingLabel?: string;
    promoStartLabel?: string;
    promoEndCallback?: () => void;
}

export interface PromoModuleProps extends PromoContentProps {
    className?: string;
    entriesCollection: ModuleEntriesCollection;
    style?: CSSProperties;
}

export interface RealObject<T = any> {
    [key: string]: T;
}

export interface Store {
    storeAddress?: string;
    storeCity?: string;
    storeId: string;
    storePinCode?: string;
    storeState?: string;
    storeZip?: string;
    timeZone?: string;
}

export interface HybrisStore extends Store {
    dayparts?: RealObject | null;
    openingScheduleData?: RealObject | null;
    showDeliveryOption?: boolean;
    storeName?: string | null;
}

export interface TextContent {
    text: string;
}

export interface TitleProps {
    title?: RealObject | string;
    titleGraphic?: GraphicProps;
}

export type Topic =
    | 'Cart'
    | 'Dayparts'
    | 'Generic'
    | 'Layout'
    | 'Loyalty'
    | 'Products'
    | 'Product Detail'
    | 'Site'
    | 'Stores'
    | 'User';

export interface InitializingUser {
    customerID: undefined;
    firstName: undefined;
    isLoggedIn: undefined; // isLoggedIn: undefined <--
    userUid: undefined;
}
export interface GuestUser {
    customerID: string;
    firstName: string;
    isLoggedIn: false; // isLoggedIn: false <--
    userUid: string;
}
export interface UserHeaderInfoResponse {
    membershipLevelName: string; // 'Fire' || 'Hot' || 'Diablo'
    emailOptIn: boolean;
}
export interface RegisteredUser extends Partial<UserHeaderInfoResponse> {
    activationCode: string[]; // (Unused) always empty array?
    birthday: string; // (Unused)
    customerID: string;
    displayUid: string; // (Unused)
    email: string; // (Unused)
    firstName: string;
    hasPassword: boolean; // (Unused)
    isLoggedIn: true; // isLoggedIn: true <--
    lastName: string; // (Unused)
    name: string; // (Unused)
    offersCount: number; // hybris has, adapter not ( defaults to 0 )
    ordersCount: number; // hybris has, adapter not ( defaults to 0 )
    phoneNumber: string;
    totalUnitCount?: string; // optional: because hybris has, adapter not.
    type: string; // (Unused)
    userUid: string; // mapped from 'uid' field
}
export type AnyUser = RegisteredUser | GuestUser | InitializingUser;
export type User = RegisteredUser | GuestUser;

export interface SubscriptionStatus {
    initialDate: string;
    expirationDate: string;
    lastRedemptionDate: string;
    type?: 'TACO_LOVERS_PASS' | '';
}

export interface WebpageContentProps
    extends Omit<GenericContentProps, 'backgroundImage'> {
    className?: string;
    entriesCollection: ModuleEntriesCollection;
    type?: GenericContentType; // This is the WebpageContent type in Contentful for Bucket, Hero, Text, Tile
}

export interface PromoPageContentProps
    extends Omit<PromoContentProps, 'backgroundImage'> {
    entriesCollection: ModuleEntriesCollection;
    type?: GenericContentType; // This is the WebpageContent type in Contentful for Bucket, Hero, Text, Tile
}

export interface LoyaltyDashboardResponseBody {
    challenges: any[];
    error?: boolean;
    inbox: any[];
    membership_conversion_limit: number;
    membership_level_name: string;
    membership_level_progress: number;
    points_accumulated: number;
    points_this_year: number;
    points_conversion_threshold: number;
    points_expiring: any[];
    points_to_next_reward: number;
    progress_to_next_reward: number;
    rewards: any[];
    total_lifetime_points: number;
}

export interface LoyaltyDashboardTemplateProps {
    assetPath?: string;
    bgDoodleUnderlineImage?: string;
    challengesProps?: RealObject;
    currentCustomerTierLevel?: string;
    customerGreeting?: string;
    customerGreetingDoodleImg?: string;
    downloadAppCopy?: string;
    errorModal?: RealObject;
    firstTimeUserLegalModal?: RealObject;
    firstTimeUserModal?: RealObject;
    firstTimeUserRewardModal?: RealObject;
    levelIconColors?: RealObject;
    loggedOut?: LoyaltyLoggedOutProps;
    loggedInDashBoardBg?: string;
    loggedInPaperTexture?: string;
    lifetimePointsLabel?: string;
    nextLevelTooltips?: RealObject;
    pointsEarnedTowardFreeFood?: string;
    pointsUntilNextFreeItem?: string;
    progressPointsExceededLabel?: string;
    progressPointsLabel?: string;
    rewardsFaq?: string;
    rewardsLearnMore?: RealObject;
    rewardsProps?: RealObject;
    svgCircleDescription?: string;
    svgCircleTitle?: string;
    theme?: RealObject;
    tierLevels?: string[];
    unlockedLabel?: string;
    unlockLabel?: string;
    wisdomSignifiers?: RealObject;
}

export interface AsideRegionLoyaltyProps {
    activate: (update: boolean) => void;
    active: boolean;
    components?: Props[];
    loyaltyTemplate: LoyaltyDashboardTemplateProps;
}

/**
 * To be Used As the Return Type for async/await HttpRequest Functions
 * @author Michael Weitzman
 */
export type FetchResponse<T = any> = Promise<
    | (T & {
          success: true;
      })
    | { success: false; error?: string; errors?: GenericResponseError[] }
>;
