import { RealObject } from '@tb-core/types';
import { PickupMethod, TimeMethod } from '@tb-core/types/location.d';

export interface StoreAddress {
    country: { isocode: string };
    id: string;
    formattedAddress?: string;
    line1: string;
    postalCode: string;
    region: { isocode: string };
    town: string;
}

export interface FormattedAddress {
    address: string | null;
    storeCity: string | null;
    storeState: string | null;
    storeZip: string | null;
}

// This is a limited dataset from the actual store response.
// Add additional type properties as needed
export interface StoreResponse {
    address: StoreAddress;
    storeNumber: string;
    timeZone: string;
}

// StoreObj: Raw Store Object that is extracted/returned from hybris call
// A StoreObj[] is returned from:
// ** tb-location ** useSubmitLocation() which gets it from useFindStores()
// not to be confused with:
// A StoreResponse[] returned from:
//    ** core **     useSubmitLocation() which gets it from useFindStores()
//
// TODO investigate if these 2 interface definitions can be combined into one:
// 1. StoreObj and
// 2. SelectedStoreResponse from types/checkout/checkout-cart.d.ts
export interface StoreObj extends StoreResponse {
    // address: StoreAddress - StoreResponse
    autoCheckIn: boolean;
    capabilities: StoreCapabilities;
    currentOnlineAvailable: boolean;
    formattedDistance: string;
    geoPoint: { latitude: number; longitude: number };
    // storeNumber: string - StoreResponse
    // timeZone: string - StoreResponse
    todayBusinessHours: TodayBusinessHours;
}

// StoreInfo: Store Object that is passed between 'locations' page components.
// anything Store related needed outside of 'locations' page lives we want to put in selectedStore in sessionStorage
export interface StoreInfo {
    autoCheckIn: boolean;
    capabilities: StoreCapabilities;
    currentOnlineAvailable?: boolean;
    formattedAddress: FormattedAddress;
    formattedDistance: string;
    geoPoint: GeoPoint;
    storeId: string;
    timeZone: string;
    todayBusinessHours: TodayBusinessHours;
}

// Store Object that is stored to sessionStorage Key: selectedStore
// We'd rather store/retrieve Store info from selectedStore than from 'userHeaderInfo' call
export type SelectedStore = SelectedStoreNow | SelectedStoreLater;

export interface SelectedStoreBase {
    autoCheckIn: boolean;
    breakfast: TodaysBreakfastCapabilities;
    closingTime: string;
    storeAddress: FormattedAddress;
    storeId: string;
    storePickupMethod: PickupMethod;
    storeTimeZone: string;
}

export interface SelectedStoreNow extends SelectedStoreBase {
    pickupTimeLabel: undefined;
    pickupTimeStamp: undefined;
    storePickupTimeMethod: TimeMethod.Now;
}

export interface SelectedStoreLater extends SelectedStoreBase {
    pickupTimeLabel: string;
    pickupTimeStamp: number;
    storePickupTimeMethod: TimeMethod.Later;
}

// As user answers questions we populate this object, that is why these are all possibly undefined
export interface PartialSelectedStore {
    autoCheckIn: boolean;
    breakfast?: TodaysBreakfastCapabilities;
    closingTime?: string;
    pickupTimeLabel?: string;
    pickupTimeStamp?: number;
    storeAddress?: FormattedAddress;
    storeId?: string;
    storePickupMethod?: PickupMethod;
    storePickupTimeMethod?: TimeMethod;
    storeTimeZone?: string;
}

export interface StoreSelectionProps {
    autoCheckIn: boolean;
    capabilities: StoreCapabilities;
    formattedHour: string | undefined;
    gaDataLayer?: RealObject;
    storeAddress: FormattedAddress;
    storeId: string;
    timeZone: string;
    todayBusinessHours: TodayBusinessHours;
}

export type TodaysBreakfastCapabilities =
    | BreakfastCapabilities
    | NoBreakfastCapabilities;

interface BreakfastCapabilities {
    endTime: StoreTime;
    isAllDay: boolean;
    isThereBreakfastToday: true;
    startTime: StoreTime;
}
interface NoBreakfastCapabilities {
    isThereBreakfastToday: false;
}

export interface StoreCapabilities {
    breakfast: boolean; // not currently used, checking todaysBreakfastCapabilities instead
    driveThru: boolean;
    driveThruPriorityPickupLane: boolean;
    inStore: boolean;
    pickupShelves: boolean;
}

export interface TodayBusinessHours {
    closingTime?: StoreTime;
    dayparts: StoreHours[];
    openingTime?: StoreTime;
}

export interface StoreTime {
    formattedHour: string;
    hour: number;
    minute: number;
}
export interface StoreHours {
    allDay: boolean;
    closed: boolean;
    daypart: DayPart;
    endTime: StoreTime;
    startTime: StoreTime;
}

export interface DayPart {
    afterMessageDetail: string;
    afterMessageTitle: string;
    beforeEndTimeMinutes: number;
    endMessageDetail: string;
    endMessageTitle: string;
    name: string;
    presetMinutes: number;
    startMessageDetail: string;
    startMessageTitle: string;
}
