export interface GenericResultStatus {
    message: string;
    status: string;
    success: boolean;
    summary: {
        lineItems: [];
        total: {
            amount: number;
        };
    };
}
