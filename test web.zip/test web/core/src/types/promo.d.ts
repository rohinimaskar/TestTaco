export interface PromoResponse {
    datetime: string;
}
