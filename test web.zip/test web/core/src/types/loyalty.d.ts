export interface LoyaltyActivateUserResponseProps {
    errors?: LoyaltyResponseError[];
    success: boolean;
}

export interface LoyaltyDashboardResponse {
    membershipLevelName: 'DIABLO' | 'FIRE' | 'HOT';
    membershipLevelProgress: number;
    pointsAccumulated: number;
}

export interface LoyaltyResponseError {
    message: string;
    reason: string;
}
