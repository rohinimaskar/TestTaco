declare module '*.scss';
declare module 'smoothscroll-polyfill';
