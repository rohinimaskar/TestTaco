import { Dispatch, SetStateAction } from 'react';

import { SelectedVariantType } from '@tb-core/components/products/hooks/use-select-variant';
import { ComboItem } from '@tb-core/components/products/styled/combo-item-card/combo-item-card';
import {
    CSCItem,
    CSCItemModifierOptions,
    CSCItemModifierType
} from '@tb-core/constants/client-side-cart';
import { HappierHours } from '@tb-core/helpers/products/is-happier-hour';
import { Option } from '@tb-core/hooks/product/use-customize';
import { RealObject } from '@tb-core/types/index.d';

// this is the product that is actually rendered on the cart page
export interface CartSummaryProduct {
    groupCode?: string;
    happierHourPrice: Price | undefined;
    id: string;
    isAvailable?: boolean;
    items?: [CSCItem];
    itemName: string;
    modifiers?: CSCItemModifier[];
    plu: string;
    productCategory?: string;
    productGroup?: string;
    qty: number;
    url: string;
    variant?: string;
}

// @todo rename to CustomizeOption
export interface CustomizationOption {
    accurateCalorie?: string;
    calories?: string;
    code?: string;
    defaultProtein?: boolean;
    description?: string;
    foodType?: string;
    isAvailableInStore?: boolean;
    isFountain?: boolean;
    isHasDefaultItem?: boolean;
    itemType?: string;
    maxOrderQuantity?: number;
    maxProductCount?: number;
    modifiable?: boolean;
    name?: string;
    pdpMasthead?: RealObject;
    plu?: string;
    pluralName?: string;
    price?: RealObject;
    primaryCategory?: string;
    primaryCategoryCode?: string;
    productCount?: number;
    productImageUrl?: string;
    productType?: string;
    purchasable?: boolean;
    showAddedIngredientCalories?: boolean;
    sodiumIndication?: boolean;
    thumbnailImageUrl?: string;
    url?: string;
    variantOptions: VariantOption[];
    variantType?: string;
}

// @todo rename to CustomizeOptions
export interface CustomizationOptions {
    addonOptions: CustomizationOption[];
    frescoAdd?: string[];
    frescoProduct?: StyleOption;
    frescoRemove?: string[];
    grilled?: StyleOption[];
    grillableProduct?: StyleOption;
    includeOptions: CustomizationOption[];
    proteinOptions: CustomizationOption[];
    sauceOptions: CustomizationOption[];
    shellOptions?: CustomizationOption[];
    supremeAdd?: string[];
    supremeProduct?: StyleOption;
    supremeRemove?: string[];
    upgradeOptions: CustomizationOption[];
    vegetarianAdd?: string[];
    vegetarianProduct: StyleOption;
    vegetarianRemove?: string[];
}

export interface DrinkVariantOptionMinimal extends SelectedVariantType {
    drinkSize: string;
}

export interface DrinkVariantOption
    extends Pick<VariantOption, 'calories' | 'code' | 'happierHourPrice'> {
    drinkSize: string;
    groupDefaultItem: boolean;
    happierHourPrice?: Price;
    nutritionInfo?: NutrionInfo;
    priceData: Price;
}

export interface StoreSchedule {
    weekDayOpeningList: any[];
}

/**
 * Menu json object that is returned from getMenu call using `storeId`
 */
export interface Menu {
    happierHours?: HappierHours;
    menuProductCategories: MenuProductCategory[];
    storeSchedule?: StoreSchedule;
}

export interface MenuProductCategory {
    code: string;
    name?: string;
    products?: Product[];
}

// currently used variant modifier type and we can add more later
export type ModifierType =
    | CSCItemModifierType.ADD
    | CSCItemModifierType.EASY
    | CSCItemModifierType.EXTRA
    | CSCItemModifierType.MINUS
    | CSCItemModifierType.MODIFIED
    | CSCItemModifierType.SIDE
    | CSCItemModifierType.STYLE;

export interface Price {
    currencyIso?: string;
    formattedValue?: string;
    priceType?: string;
    value: number;
}

// I believe these dayParts are always related to breakfast, hence the name:
// These define when is outside breakfast hours for the whole week i beleive?
// Defines when 'startSoon', 'endingSoon', 'after', 'before' - but no call out for 'during' breakfast
// For Products that are only served during breakfast: Product.dayPartMessages will have an array of these.
// For Products that are served all day: Product.dayPartMessages will be empty []
// Currently just making use of the 'dayPartCode' but the full object looks like this:
//
// dayPartCode: string; // 'Breakfast'
// dayPartMessageDetail: string; // 'Visit our drive-thru for participating restaurants serving breakfast'
// dayPartMessageTitle: string; // 'Breakfast is currently unavailable online';
// dayPartStatus: string; // 'startSoon' 'endingSoon' 'after' 'before'
// endTime: string; // 'Tuesday, 07 June 2022 13:00:00 -0700';
// endTimeUTC: string; // '1654632000000';
// showDayPart: boolean; // true;
// startTime: string; // 'Tuesday, 07 June 2022 12:30:00 -0700';
// startTimeUTC: string; // '1654630200000';
// warningPriority: number; // 10;
//
//
export interface BreakfastDayPart {
    dayPartCode: string; // 'Breakfast'
}

// @TODO Will evolve as this gets flushed out.
export interface Product {
    accurateCalorie: string;
    availableForPickup?: boolean;
    baseOptions?: RealObject[];
    calories: string;
    caloriesDisplayText: string;
    categories: Array<{ code: string }>;
    code: string;
    customizationOptions: CustomizationOptions; // TODO make Optional: Not Present on Combo / BYOB / Party Pack
    dayPartMessages: BreakfastDayPart[];
    defaultProtein: boolean;
    description: string;
    descriptionSubtitle?: string;
    descriptionTitle: string;
    drinkSize?: string;
    foodType: string;
    hasAVA: boolean;
    hasMeatless: boolean;
    isBYOB?: boolean; // is Build Your Own Box product
    isComboALC?: boolean;
    images: ProductImage[];
    isAvailableInStore: boolean;
    isDigitalProduct?: boolean;
    isFountain?: boolean;
    isGatedProduct: boolean;
    isHasDefaultItem: boolean;
    isPassRedemptionItem?: boolean;
    itemType: string;
    maxOrderQuantity: number;
    maxProductCount: number;
    metaDescription?: string;
    metaTitle?: string;
    modifiable: boolean;
    name: string;
    numberOfReviews?: number;
    nutritionIXID?: string;
    nutritionInfo?: RealObject;
    pdpMasthead?: RealObject;
    pluralName?: string;
    price?: Price;
    priceRange: object;
    primaryCategory: string;
    primaryCategoryCode: string;
    productCount: number;
    productGroups?: ComboItem[];
    productImageUrl?: string; // @TODO to be removed when PDP has the right product hero format support
    productReferences?: ProductReference[];
    productType: string;
    purchasable: boolean;
    searchable: boolean;
    sellableEndDate?: string;
    sellableStartDate?: string;
    showAddedIngredientCalories: boolean;
    sodiumIndication: boolean;
    summary?: string;
    thumbnailImageUrl?: string;
    url: string;
    variantOptions?: VariantOption[];
}

export type ProductItem = Pick<
    Product,
    | 'calories'
    | 'code'
    | 'hasAVA'
    | 'images'
    | 'isComboALC'
    | 'isFountain'
    | 'maxOrderQuantity'
    | 'modifiable'
    | 'name'
    | 'nutritionIXID'
    | 'price'
    | 'primaryCategory'
    | 'productImageUrl' // @TODO to be removed when PDP has the right product hero format support
    | 'productGroups'
    | 'productType'
    | 'sodiumIndication'
    | 'url'
>;

export interface ProductImage {
    format?: string;
    imageType?: string;
    url: string;
}

export interface ProductReference {
    target: Product;
}

export interface NutritionInfo {
    url: string;
}

// TODO: Research adding "onTheSide" to this
export interface CustomizationOptionType {
    onSelected?: (option: Option, value: boolean) => void;
    opt: CSCItemModifierOptions;
    product?: Pick<ProductItem, 'code' | 'name'>;
    productDetail?: RealObject;
}

export interface StyleOptionModifier extends Option {
    variantCodes: string[];
}

export interface StyleOption extends CustomizationOption {
    addProducts: StyleOptionModifier[];
    opt: CSCItemModifierOptions;
    removeProducts: StyleOptionModifier[];
}

export type StyleModifiers = Pick<
    StyleOption,
    'addProducts' | 'opt' | 'removeProducts'
>;

export type SetStyleModifiers = Dispatch<SetStateAction<StyleModifiers[]>>;

export interface SwapList extends VariantOption {
    addProducts?: string[];
    removeProducts?: string[];
}

export interface VariantOption {
    accurateCalorie: string;
    availableInStore?: boolean;
    calories: string;
    code: string;
    drinkSize?: string;
    groupDefaultItem: boolean;
    happierHourPrice?: Price;
    modifierType: ModifierType;
    name: string;
    onTheSide?: string;
    picture?: RealObject;
    pluralName?: string;
    priceData?: Price;
    purchasable?: boolean;
    priority?: number;
    productImageUrl: string;
    stock?: RealObject;
    url?: string;
    variantOptionQualifiers?: RealObject[];
}
