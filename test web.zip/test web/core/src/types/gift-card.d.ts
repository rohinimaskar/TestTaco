import { GenericResponseError } from '@tb-core/types';

export interface GiftCardBalanceResponseBody {
    balance: number;
    cardNumber: string;
    defaultPaymentInfo: boolean;
    errors?: GenericResponseError[];
    isCardSelected: boolean;
    saved: boolean;
    success: boolean;
}
