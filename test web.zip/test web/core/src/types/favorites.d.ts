import { CSCItemModifierOptions } from '@tb-core/constants/client-side-cart';
import { Option } from '@tb-core/hooks/product/use-customize';
import { ModifierType, Product } from '@tb-core/types/products';

export interface FavoriteProduct {
    calories: string;
    drinkParentPLU?: string;
    favProductId: string;
    favoriteName: string;
    modifiers?: FavoriteModifiers[];
    items?: FavoriteItem[];
    plu: string;
    thumbnailURL: string;
}

export interface FavoriteDrinkProduct
    extends Pick<FavoriteProduct, 'drinkParentPLU'> {
    calories: string;
    code: string;
    name: string;
}

export interface FavoriteFoodProduct {
    calories: string;
    groupID: string;
    modifiers?: FavoriteModifiers[];
    name: string;
    plu: string;
    qty?: number;
}

export type FavoriteItem = FavoriteDrinkProduct & FavoriteFoodProduct;

export type AdaptedProduct = Pick<
    Product,
    'calories' | 'code' | 'images' | 'itemType' | 'name' | 'productImageUrl'
>;
interface FavoriteModifiers {
    calories: string | undefined;
    groupType?: string;
    includedWithStyle: boolean;
    isSwapped?: boolean | null;
    name?: string;
    modifierName: string;
    modifierType?: ModifierType;
    opt: CSCItemModifierOptions;
    ots: boolean;
    plu: string;
    price?: number;
    styleKey?: string;
}

export interface MappedComboItem {
    calories: string;
    code: string;
    customizationOptions?: CustomizationOptions;
    drinkParentPLU?: string;
    groupID?: string;
    modifiers?: CSCItemModifier[];
    name: string;
    plu?: string;
    qty?: number;
}

interface SelectedOptionModifier {
    calories: string;
    code: string;
}

export interface SharedFavoriteProduct {
    calories: string;
    favoriteName: string;
    favProductId: string;
    items?: SharedFavoritesItem[];
    modifiers?: Option[];
    plu: string;
    yumProductKey: string;
}

export interface SharedFavoriteModifier {
    calories: string;
    groupType: string;
    isSwapped: boolean;
    includedWithStyle: boolean;
    modifierName: string;
    opt: CSCItemModifierOptions;
    ots: boolean;
    plu: string;
    styleKey: string;
    yumProductKey?: string;
}

export interface SharedFavoritesItem {
    calories: string;
    isDrink: boolean;
    modifiers?: SharedFavoriteModifier[];
    plu: string;
    qty: number;
    yumProductKey: string;
}
