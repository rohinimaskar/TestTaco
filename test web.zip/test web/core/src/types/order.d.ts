import { Product } from '@tb-core/types/products';

export interface Address {
    line1: string;
    postalCode: string;
    region: {
        isocodeShort: string;
    };
    town: string;
}

export enum DeliveryStatuses {
    DASHER_CONFIRMED = 'DASHER_CONFIRMED',
    DASHER_CONFIRMED_CONSUMER_ARRIVAL = 'DASHER_CONFIRMED_CONSUMER_ARRIVAL',
    DASHER_CONFIRMED_STORE_ARRIVAL = 'DASHER_CONFIRMED_STORE_ARRIVAL',
    DASHER_DROPPED_OFF = 'DASHER_DROPPED_OFF',
    DASHER_ENROUTE_TO_DROPOFF = 'DASHER_ENROUTE_TO_DROPOFF',
    DASHER_ENROUTE_TO_PICKUP = 'DASHER_ENROUTE_TO_PICKUP',
    DASHER_PICKED_UP = 'DASHER_PICKED_UP',
    DELIVERY_ATTEMPTED = 'DELIVERY_ATTEMPTED',
    DELIVERY_CANCELLED = 'DELIVERY_CANCELLED',
    DELIVERY_CREATED = 'DELIVERY_CREATED',
    DRIVER_BATCHED = 'DRIVER_BATCHED'
}

export interface DeliveryStatusText {
    CANCELLED: string;
    DELIVERED: string;
    IN_TRANSIT: string;
    PREPARING: string;
    RECEIVED: string;
}

export interface EntryCustomization {
    group: CSCItemModifierOptions;
    modifier: CSCModifierDetail;
}

export interface GeoPoint {
    latitude: number;
    longitude: number;
}

interface Modifier {
    modifierType: string;
    name: string;
}
export interface ModifierLabels {
    easy: string;
    extra: string;
    onTheSide: string;
}

export interface ModifierTypeLabels {
    added: string;
    modified: string;
    removed: string;
}

export interface OptionalModifiers {
    grill?: Partial<Product>;
    includedItems: EntryCustomization[];
    product: OrderProduct;
    productGroupCode?: string;
    quantity: number;
    tastyUpgrades?: EntryCustomization[];
}

export interface GiftCardInfo {
    cardNumber: string;
}

export interface Order {
    appliedOrderPromotions: string[];
    code: string;
    entries: OrderEntry[];
    CAPropFee?: PricingWithFormat;
    created: string;
    cupChargePrice: Pricing;
    deliveryFee?: PricingWithFormat;
    deliveryStatus?: string;
    deliveryTip: Pricing;
    gcPaymentInfoList?: GiftCardInfo[];
    guid: string;
    paymentInfo: {
        cardNumber: string;
    };
    pendingCancellation: boolean;
    pickupMethod: string;
    placed?: string;
    pointOfService: {
        address: Address;
        geoPoint: GeoPoint;
        storeNumber: string;
        timeZone: string;
    };
    posOrderId: string;
    qrCode: string;
    roundUpAmount: Pricing;
    status: string;
    subTotal: PricingWithFormat;
    totalDiscounts: PricingWithFormat;
    totalItems: number;
    totalPriceWithTax: PricingWithFormat;
    totalTax: PricingWithFormat;
    user: {
        name: string;
        uid: string;
    };
}

export interface OrderEntry {
    availableForReorder?: boolean;
    basePrice: PricingWithFormat;
    optionalModifiers: OptionalModifiers[];
    product: OrderProduct;
    quantity: number;
    totalOriginalProductPrice: PricingWithFormat;
    totalPrice: PricingWithFormat;
}

export interface OrderProduct
    extends Pick<
        Product,
        | 'code'
        | 'name'
        | 'primaryCategory'
        | 'productCategory'
        | 'productType'
        | 'isDigitalProduct'
        | 'isPassRedemptionItem'
    > {
    images: ProductImage[];
    price: PricingWithFormat;
}

export interface OrdersResponse {
    orders?: Order[];
    pagination: {
        currentPage: number;
        pageSize: number;
        totalPages: number;
        totalResults: number;
    };
}

export interface OrderSummaryDataModifiers {
    modifierLabels: ModifierLabels;
    modifierTypes: ModifierTypeLabels;
}

export enum PickUpMethods {
    Drive_Thru = 'DRIVETHRU',
    In_Store = 'INSIDE',
    Pickup_Shelves = 'PICKUPSHELVES',
    Priority_Pickup_Lane = 'PRIORITYPICKUPLANE'
}

export enum PickUpText {
    DRIVE_THRU = 'Drive-Thru',
    INSIDE = 'In Store',
    PICK_UP_SHELVES = 'Pick-up Shelves',
    PRIORITY_PICK_UP_LANE = 'Priority Pick-Up Lane'
}

export interface Pricing {
    currencyIso: string;
    formattedValue?: string;
    value?: number;
}

export interface PricingWithFormat extends Pricing {
    priceType?: string;
}

export interface ProductImage {
    format: string;
    imageType: string;
    url: string;
}

export enum Statuses {
    CANCELLED = 'CANCELLED',
    CANCELLING = 'CANCELLING',
    ORDER_CHECKED_IN = 'ORDER_CHECKED_IN',
    ORDER_COMPLETE = 'ORDER_COMPLETE',
    ORDER_CONFIRMED = 'ORDER_CONFIRMED',
    ORDER_PLACED = 'ORDER_PLACED'
}

interface StatusText {
    CANCELLED?: string;
    CANCELLING?: string;
    ORDER_CHECKED_IN: string;
    ORDER_COMPLETE: string;
    ORDER_CONFIRMED: string;
    ORDER_PLACED: string;
}

export interface SubStatusTextProps {
    cancelling: string;
    defaultText: StatusText;
    defyDriveThru: StatusText;
    defyInside: StatusText;
    driveThru: StatusText;
    inside: StatusText;
    pickUpShelves: StatusText;
    priorityPickupLane: StatusText;
}
