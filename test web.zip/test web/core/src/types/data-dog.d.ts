export interface Metadata {
    authToken?: string; // authToken to be discussed w/ Hybris team
    cartCode?: string;
    clientDeviceType?: string;
    clientIp?: string;
    responseCode?: number;
    status?: string;
    timestamp?: string;
    url?: string;
    userEmail?: string;
    userId?: string;
    version?: string;
}

export interface DatadogAttribute {
    logName: string;
    metadataName: string;
    reason?: string;
    shouldUseInLog: boolean;
    shouldSend?: boolean;
    shouldUseInSession: boolean;
    value?: string | number;
}

export interface DatadogDataWrapper {
    errorMessageTemplate: string;
    id: string;
    preEventAttributes: DatadogAttribute[];
    strategy: DatadogDataStrategy;
}

export type DatadogDictionaryValue = string | number | undefined;
