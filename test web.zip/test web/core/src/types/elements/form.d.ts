import {
    DetailedHTMLProps,
    InputHTMLAttributes,
    LabelHTMLAttributes,
    TextareaHTMLAttributes
} from 'react';

export interface ValidationProps {
    error?: boolean;
    message?: string;
    name?: string;
}

export interface FormControlProps {
    error?: boolean;
    errorMessage?: string;
    label?: string;
    validation?: validationProps;
}

export type InputProps = DetailedHTMLProps<
    InputHTMLAttributes<HTMLInputElement>,
    HTMLInputElement
>;

export type InputValue = number | string | readonly string[] | undefined;

export type LabelProps = DetailedHTMLProps<
    LabelHTMLAttributes<HTMLLabelElement>,
    HTMLLabelElement
>;

export type SelectProps = DetailedHTMLProps<
    SelectHTMLAttributes<HTMLSelectElement>,
    HTMLSelectElement
>;

export type StandardInputProps = InputProps & FormControlProps;

export type StandardSelectProps = SelectProps & FormControlProps;

export type StandardTextAreaProps = TextAreaProps & FormControlProps;

export type TextAreaProps = DetailedHTMLProps<
    TextareaHTMLAttributes<HTMLTextAreaElement>,
    HTMLTextAreaElement
>;
