export type Style = React.CSSProperties & {
    [key: string]: string;
};
