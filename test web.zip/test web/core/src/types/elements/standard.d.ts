import {
    ComponentPropsWithoutRef,
    DetailedHTMLProps,
    ElementType,
    HTMLAttributes,
    PropsWithChildren
} from 'react';

export type DivProps = DetailedHTMLProps<
    HTMLAttributes<HTMLDivElement>,
    HTMLDivElement
>;

export type ParagraphProps = DetailedHTMLProps<
    HTMLAttributes<HTMLParagraphElement>,
    HTMLParagraphElement
>;
