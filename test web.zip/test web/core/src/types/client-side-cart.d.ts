import { MouseEventHandler, ReactNode } from 'react';

import { NumberInputOnChange } from '@tb-core/components/styled/form-controls/standard-number-input';
import { CSCItemModifierOptions } from '@tb-core/constants/client-side-cart';
import { RealObject } from '@tb-core/types/index.d';
import { ModifierType, Product } from '@tb-core/types/products.d';

// CSCItemTemplate[]: returned from cscItemAdapter() inside <OrderSummary>
export interface CSCItemTemplate {
    category?: string;
    id: string;
    image: string;
    isAnItemInComboUnavailable: boolean;
    isAvailable: boolean;
    isBreakfastItem?: boolean;
    isOutsideBreakfastTimeItem: boolean;
    itemName: string;
    items: CSCComboChildItem[];
    modifiable: boolean;
    modifiers: CSCModifierDetail[];
    plu: string;
    price: number;
    qty: number;
    url?: string; // not used url, instead another url grabbed inside <CartItem>
    variant?: string;
}

// CartItemListProps: Props passed to <CartItemList>
export interface CartItemListProps
    extends Omit<CartItemBoundProps, 'currentCartLength'> {
    cartLineItems: CSCItemTemplate[];
    className: string;
}

// CartItemListItem: Props passed to 'cartItem' from <CartItemList>
// Note 2 sets of Props are passed CartItemBoundProps AND CSCItemTemplate
export interface CartItemBoundProps {
    cartItemLabels?: { [key: string]: string | undefined };
    currentCartLength: number;
    onDeleteItem?: (cartItem: DeleteCartItem) => void;
    onQuantityChange?: (cartItem: CSCItemDetail) => void;
    productDetail?: { [key: string]: string };
    removeItemPrompt?: string;
}

interface CSCItemById {
    id: string;
    plu?: string;
}
interface CSCItemByPlu {
    id?: string;
    plu: string;
}

export type DeleteCartItem = CSCItemById | CSCItemByPlu;

// CartLineItem: Props passed to <CartItem> from 'cartItem'
export interface CartLineItem
    extends Omit<
            CartItemBoundProps,
            'currentCartLength' | 'onDeleteItem' | 'onQuantityChange'
        >,
        Omit<CSCItemTemplate, 'category' | 'variant'> {
    onChangeQuantity?: NumberInputOnChange;
    onDelete?: MouseEventHandler<HTMLButtonElement>;
}

// CartItemDetailedProps: Props passed to <CartItemDetailed> from <CartItem>
export interface CartItemDetailProps
    extends Omit<
        CartLineItem,
        'removeItemPrompt' | 'onDelete' | 'productDetail'
    > {
    confirmRemoveHandler: () => void;
    editItemHandler: () => void;
    maxOrderQuantity: number;
    url: string;
}

export interface CSCItem {
    groupCode?: string;
    id?: string;
    itemName: string;
    items?: CSCComboItem[]; // only populated if combo product
    modifiers?: CSCModifierDetail[]; // combo products will never have modifiers here
    plu: string;
    qty?: number;
    variant?: string;
    price?: number;
}

export interface CSCComboItem
    extends Pick<CSCItem, 'groupCode' | 'items' | 'plu' | 'qty'> {
    modifiers?: CSCItemModifier[];
}

export interface CSCItemDetail extends CSCItem {
    price: number;
}

export interface CSCComboChildItem extends Omit<CSCItemDetail, 'modifiers'> {
    isAvailable: boolean;
    modifiers?: CSCModifierDetail[];
}

export interface CSCItemModifier {
    includedWithStyle: boolean;
    groupType?: string;
    modifierType?: ModifierType;
    name?: string;
    // Customization Options
    opt: CSCItemModifierOptions;
    // On The Side
    ots: boolean;
    plu: string;
}

export interface CSCModifierAction {
    modifiers: CSCModifierDetail[];
    name: string;
    value: RegExp;
}

export interface CSCModifierDetail extends CSCItemModifier {
    code?: string;
    includedWithStyle: boolean;
    modifierType: ModifierType;
    name: string;
    price: number;
}

export interface CSCRequestBody {
    items: CSCItem[];
    rewards?: string[];
}

export type CSCResponseBody = Partial<CSCRequestBody>;
