import React, { ReactNode } from 'react';

import { ContentfulProductCategory } from '@tb-core/types/contentful/products';

export interface ProductCategoriesProviderProps {
    productCategories: ContentfulProductCategory[];
}

const ProductCategoriesContext = React.createContext<
    ContentfulProductCategory[] | undefined
>(undefined);
const { Provider } = ProductCategoriesContext;

const ProductCategoriesProvider = ({
    children,
    productCategories
}: ProductCategoriesProviderProps & {
    children: ReactNode;
}) => <Provider value={productCategories}>{children}</Provider>;

export default ProductCategoriesProvider;
export { ProductCategoriesContext };
