import { createContext, Dispatch, ReactNode, SetStateAction } from 'react';

import useCartProduct, {
    CalculateProductTotals,
    CartProductDetails,
    ProductTotals,
    UpdateProductList
} from '@tb-core/hooks/use-cart-product';

interface CartProductProviderProps {
    children: ReactNode;
}

export interface CartProductContextProps {
    calculateProductTotals: CalculateProductTotals;
    clearProductList: () => void;
    productList: CartProductDetails[];
    productTotals: ProductTotals;
    setProductList: UpdateProductList;
    setProductTotals: Dispatch<SetStateAction<ProductTotals>>;
}

const CartProductContext = createContext<CartProductContextProps | undefined>(
    undefined
);

const { Provider } = CartProductContext;

const CartProductProvider = ({ children }: CartProductProviderProps) => {
    const {
        calculateProductTotals,
        clearProductList,
        productList,
        productTotals,
        setProductList,
        setProductTotals
    } = useCartProduct();

    return (
        <Provider
            value={{
                calculateProductTotals,
                clearProductList,
                productList,
                productTotals,
                setProductList,
                setProductTotals
            }}
        >
            {children}
        </Provider>
    );
};

export default CartProductProvider;
export { CartProductContext };
