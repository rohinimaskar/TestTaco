import React, { useEffect, useState } from 'react';

import sessionStorage from '@tb-core/helpers/storage';
import getLoyaltyDashboard from '@tb-core/providers/get-loyalty-dashboard';
import { JsxChildren, LoyaltyDashboardResponseBody } from '@tb-core/types';

interface LoyaltyDashboardProviderProps {
    children: JsxChildren;
    enabled?: boolean;
}

const LoyaltyDashboardContext = React.createContext<
    Partial<LoyaltyDashboardResponseBody>
>({});
const { Consumer, Provider } = LoyaltyDashboardContext;

/* @TODO: update when final designs become available
 */
const LoyaltyDashboardProvider = ({
    children,
    enabled = false
}: LoyaltyDashboardProviderProps) => {
    const [loyaltyDashboard, setLoyaltyDashboard] = useState<
        Partial<LoyaltyDashboardResponseBody>
    >({});
    const fetchLoyaltyDashboard = async () => {
        const updateLoyaltyDashboard = (
            dashboard: LoyaltyDashboardResponseBody
        ) => {
            sessionStorage.setItems({ loyaltyDashboard });
            setLoyaltyDashboard(dashboard);
        };

        updateLoyaltyDashboard(await getLoyaltyDashboard());
    };

    useEffect(() => {
        if (enabled) {
            fetchLoyaltyDashboard();
        }
    }, []);

    return <Provider value={loyaltyDashboard}>{children}</Provider>;
};

const LoyaltyDashboardConsumer = Consumer;

export default LoyaltyDashboardProvider;
export { LoyaltyDashboardConsumer, LoyaltyDashboardContext };
