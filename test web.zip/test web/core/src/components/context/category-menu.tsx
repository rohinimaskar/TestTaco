import React, { ReactNode } from 'react';

import { Product } from '@tb-core/types/products';

export interface CategoryMenuProviderProps {
    products: Product[];
}

const CategoryMenuContext = React.createContext<Product[] | undefined>(
    undefined
);
const { Provider } = CategoryMenuContext;

const CategoryMenuProvider = ({
    children,
    products
}: CategoryMenuProviderProps & {
    children: ReactNode;
}) => <Provider value={products}>{children}</Provider>;

export default CategoryMenuProvider;
export { CategoryMenuContext };
