import React from 'react';

import PageDataAdapter from '@tb-core/helpers/adapters/contentful/page-data-adapter';

/* First we will make a new context */
const { Consumer, Provider } = React.createContext<any>(null);

const PageProvider = ({ children, pageData, ...props }: any) => (
    <Provider value={PageDataAdapter({ ...pageData, ...props })}>
        {children}
    </Provider>
);

const PageConsumer = Consumer;

export default PageProvider;
export { PageConsumer };
