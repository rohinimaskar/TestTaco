// import React, { ReactNode, useEffect, useState } from 'react';

// import sessionStorage from '@tb-core/helpers/storage';
// import useUserContext from '@tb-core/hooks/use-user-context';
// import getMiniCart from '@tb-core/providers/get-mini-cart';
// import { MiniCart } from '@tb-core/types';

// interface MiniCartProviderProps {
//     children: ReactNode;
//     // @deprecated
//     miniCartCount?: number;
//     // @deprecated
//     miniCartPrice?: number;
// }

// const MiniCartContext = React.createContext<MiniCart | any>({});
// const { Consumer, Provider } = MiniCartContext;

// const MiniCartProvider = ({ children }: MiniCartProviderProps) => {
//     const { totalItems, subTotal } = useUserContext();
//     const [miniCart, setMiniCart] = useState<MiniCart>({
//         miniCartCount: totalItems || 0,
//         miniCartPrice: subTotal || ''
//     });
//     const fetchMiniCart = async () => {
//         const updateMiniCart = (miniCart: MiniCart) => {
//             // Update mini-cart data in Session Storage.
//             sessionStorage.setItems({ miniCart });
//             setMiniCart(miniCart);
//         };

//         if (totalItems) {
//             updateMiniCart(await getMiniCart());
//         }
//     };

//     useEffect(() => {
//         fetchMiniCart();
//     }, [totalItems, subTotal]);

//     return <Provider value={miniCart}>{children}</Provider>;
// };

// const MiniCartConsumer = Consumer;

// export default MiniCartProvider;
// export { MiniCartContext, MiniCartConsumer };

import React from 'react';
export const MiniCartContext = React.createContext({});
