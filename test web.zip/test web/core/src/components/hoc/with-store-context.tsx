import { NextComponentType, NextPageContext } from 'next';

import { Props, Store } from '@tb-core/types';
import { StoreConsumer } from '../context/store';

export default function withStoreContext<T = Props>(
    Component: NextComponentType<NextPageContext, any, T>
) {
    return (props: T) => (
        <StoreConsumer>
            {(store?: Store) => <Component {...props} {...store} />}
        </StoreConsumer>
    );
}
