import React from 'react';

import { Props } from '@tb-core/types';

export default function withNextConfig<T = Props>(Component: any) {
    return (props: T) => <Component {...props} />;
}
