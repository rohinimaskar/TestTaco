import { NextComponentType, NextPageContext } from 'next';
import React from 'react';

import RegistryDecoratorFactory from '@tb-core/helpers/registry';

export default function withRegistry<T>(
    Component?: NextComponentType<
        NextPageContext,
        any,
        T & { registryKey: string }
    >
) {
    const Registry = RegistryDecoratorFactory();
    const ComponentWithRegistry = (props: T & { registryKey: string }) => {
        const Container = Registry.registry[props.registryKey.toLowerCase()];

        return (() =>
            Container ? (
                <Container {...props}>
                    {Component && <Component {...props} />}
                </Container>
            ) : null)();
    };

    ComponentWithRegistry.Registry = Registry;

    return ComponentWithRegistry;
}
