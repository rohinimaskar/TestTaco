export enum BrazeCustomEvent {
    ADD_TO_ORDER = 'add_to_order',
    CART_CHECKOUT = 'cart_checkout',
    CART_PURCHASE = 'cart_purchase',
    CLEAR_CART = 'clear_cart',
    VIEW_CART = 'view_cart'
}
