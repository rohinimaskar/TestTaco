const OneTrust = {
    'about our ads': {
        data:
            'https://appds8093.blob.core.windows.net/94ba57b5-e5fc-4459-a91d-28bc381b6185/privacy-notices/e62e709a-134c-498b-bd56-c5a6455da2b9.json',
        noticeID: 'otnotice-e62e709a-134c-498b-bd56-c5a6455da2b9',
        scriptSrc:
            'https://appds8093.blob.core.windows.net/privacy-notice-scripts/otnotice-1.0.min.js'
    },
    'california privacy policy': {
        data:
            'https://privacyportal-cdn.onetrust.com/94ba57b5-e5fc-4459-a91d-28bc381b6185/privacy-notices/116a05ec-ea23-40a0-882e-ccad33fafe2c.json',
        noticeID: 'otnotice-116a05ec-ea23-40a0-882e-ccad33fafe2c',
        scriptSrc:
            'https://privacyportal-cdn.onetrust.com/privacy-notice-scripts/otnotice-1.0.min.js'
    },
    'privacy policy': {
        data:
            'https://privacyportal-cdn.onetrust.com/94ba57b5-e5fc-4459-a91d-28bc381b6185/privacy-notices/e9da4bb3-d590-4597-b85c-39d0bed7d574.json',
        noticeID: 'otnotice-e9da4bb3-d590-4597-b85c-39d0bed7d574',
        scriptSrc:
            'https://privacyportal-cdn.onetrust.com/privacy-notice-scripts/otnotice-1.0.min.js'
    }
};

export default OneTrust;
