import OneTrust from './onetrust';

const Embeds = { OneTrust };

export default Embeds;
