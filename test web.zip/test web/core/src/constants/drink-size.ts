export enum DrinkSizeLabel {
    LARGE = 'L',
    MEDIUM = 'M',
    REGULAR = 'Reg',
    SMALL = 'S'
}
