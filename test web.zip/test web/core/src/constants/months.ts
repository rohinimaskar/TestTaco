export enum MONTHS {
    JANUARY = 'Jan',
    FEBRUARY = 'Feb',
    MARCH = 'Mar',
    APRIL = 'Apr',
    MAY = 'May',
    JUNE = 'Jun',
    JULY = 'Jul',
    AUGUST = 'Aug',
    SEPTEMBER = 'Sep',
    OCTOBER = 'Oct',
    NOVEMBER = 'Nov',
    DECEMBER = 'Dec'
}

export const monthsFull = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
];

export const monthsAndDays = [
    {
        days: 31,
        month: MONTHS.JANUARY
    },
    {
        days: 29,
        month: MONTHS.FEBRUARY
    },
    {
        days: 31,
        month: MONTHS.MARCH
    },
    {
        days: 30,
        month: MONTHS.APRIL
    },
    {
        days: 31,
        month: MONTHS.MAY
    },
    {
        days: 30,
        month: MONTHS.JUNE
    },
    {
        days: 31,
        month: MONTHS.JULY
    },
    {
        days: 31,
        month: MONTHS.AUGUST
    },
    {
        days: 30,
        month: MONTHS.SEPTEMBER
    },
    {
        days: 31,
        month: MONTHS.OCTOBER
    },
    {
        days: 30,
        month: MONTHS.NOVEMBER
    },
    {
        days: 31,
        month: MONTHS.DECEMBER
    }
];
