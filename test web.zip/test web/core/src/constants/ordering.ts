export enum OrderTypes {
    'DRIVE_THRU' = 'drive_thru',
    'IN_STORE' = 'in_store'
}

export enum PickupTypes {
    'DELIVERY' = 'delivery',
    'PICKUP' = 'pickup'
}
