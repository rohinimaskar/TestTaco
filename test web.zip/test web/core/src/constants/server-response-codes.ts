const serverResponseCodes = {
    HTTP_STATUS_NOT_FOUND: 404
};

export default serverResponseCodes;
