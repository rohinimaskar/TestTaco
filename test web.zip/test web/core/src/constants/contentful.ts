export enum ContentfulMetaDataUserTags {
    USER_LOGGED_IN = 'userLoggedIn',
    USER_ALL = 'userAll',
    USER_GUEST = 'userGuest'
}
