export enum KeyboardEvents {
    ENTER = 'Enter'
}
