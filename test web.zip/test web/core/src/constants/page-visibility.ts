export enum VISIBILITY_EVENT {
    VISIBILITY_CHANGE = 'visibilitychange',
    FOCUS = 'focus'
}
export enum VISIBILITY_STATE {
    VISIBLE = 'visible',
    HIDDEN = 'hidden'
}
