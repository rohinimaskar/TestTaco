export enum TokenGrantType {
    GUEST = 'guest'
}
