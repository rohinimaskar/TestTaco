export const PHONE_NUMBER_REGEX = /^\([0-9]{3}\) [0-9]{3}-[0-9]{4}$/;
export const PHONE_NUMBER_REGEX_NO_PAREN = /^(?!800|888|877|866|855|844|833)[2-9][0-9]{2}(((?!5550)[0-9]{7})|[5]{3}[0][0,2-9][0-9]{2})$/;
export const NAME_REGEX = /^[a-zA-Z]{2,}$/;
export const SPLIT_BY_FOUR_REGEX = /.{1,4}/g;
export const MODIFIED_MODIFIER_REGEX = /^(EASY|EXTRA)$/;
export const ADD_MODIFIER_REGEX = /^(ADD)$/;
export const PROTEIN_OPTION_REGEX = /^(proteinOptions)$/;
export const STYLE_MODIFIER_REGEX = /^(STYLE)$/;
