// what is returned from hybris call is `Breakfast` so make sure to .toLowerCase() before comparing.
export const DAYPART_BREAKFAST = 'breakfast';

export enum DAYPARTS {
    BOD = 'Balance Of Day',
    BREAKFAST = 'Breakfast',
    DINE_IN = 'Dine In',
    DRIVE_THRU = 'Drive Thru',
    HAPPY_HOUR = 'Happy Hour'
}
