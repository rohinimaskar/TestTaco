import Error404Main from '@tb-core/components/container/error404';
import GlobalHeader from '@tb-core/components/container/headers/global-header';
import PageProvider, {
    PageContextProps
} from '@tb-core/components/context/webpage';
import WebpageLayout from '@tb-core/components/layout/webpage';
import DocumentHeadRegion from '@tb-core/components/regions/document-head';
import FooterRegion from '@tb-core/components/regions/footer';
import LeftAsideRegion from '@tb-core/components/regions/left-aside';
import LoyaltyAsideRegion from '@tb-core/components/regions/loyalty-aside';
import TopBody from '@tb-core/components/regions/top-body';
import { getStaticPropsInit } from '@tb-core/next/static-props-helpers/get-static-props-init';

const Error404 = (props: PageContextProps) => (
    <>
        {props.content && (
            <PageProvider {...props}>
                <WebpageLayout
                    regions={{
                        footer: <FooterRegion />,
                        head: <DocumentHeadRegion />,
                        header: <GlobalHeader />,
                        leftAside: <LeftAsideRegion />,
                        main: <Error404Main />,
                        rightAside: <LoyaltyAsideRegion />,
                        topBody: <TopBody />
                    }}
                />
            </PageProvider>
        )}
    </>
);

export const getStaticProps = getStaticPropsInit({ slug: '/404' });

export default Error404;
