import { actionTypes } from '@tb-core/hooks/use-accordion';

export function accordionReducer(
    openIndices: number[],
    action: { type: string; index: number }
) {
    switch (action.type) {
        case actionTypes.toggleIndex: {
            const closing = openIndices.includes(action.index);
            return closing
                ? openIndices.filter((i: number) => i !== action.index)
                : [...openIndices, action.index];
        }
        default: {
            throw new Error(
                'Unhandled type in accordionReducer: ' + action.type
            );
        }
    }
}
