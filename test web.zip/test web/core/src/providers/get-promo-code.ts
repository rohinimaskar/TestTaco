import { datadogLogs } from '@datadog/browser-logs';
import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import Fetch, { toError } from '@tb-core/helpers/fetch';
import { tbApiHost } from '@tb-core/helpers/next-env';
import { promoCodeUrl } from '@tb-core/next/api/urls';
import { FetchResponse } from '@tb-core/types';

export default async function getPromoCode(
    code: string
): FetchResponse<{
    code_type: string;
    description: string;
    expiration: string;
    title: string;
}> {
    let res: Response;

    try {
        res = await Fetch({
            host: tbApiHost,
            method: 'GET',
            url: devProxyResolve(promoCodeUrl, { code })
        });
    } catch (e) {
        const error = toError(e);
        console.error('Promo Code get request failed!', error);
        datadogLogs.logger.log('getPromoCode', error, 'error');
        return { success: false };
    }

    if (!res.ok) {
        const error = await res.json();
        datadogLogs.logger.log('getPromoCode', error, 'error');
        return { ...error, success: false };
    }

    return { ...(await res.json()), success: true };
}
