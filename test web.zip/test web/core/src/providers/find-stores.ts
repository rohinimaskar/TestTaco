import { datadogLogs } from '@datadog/browser-logs';

import { dataDogJSON } from '@tb-core/helpers/analytics/data-dog/json';
import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import Fetch from '@tb-core/helpers/fetch';
import { setProviderUrl } from '@tb-core/helpers/utils/set-provider-url';
import { storesLookupUrl } from '@tb-core/next/api/urls';
import { LatLong, PostPlacesResponseProps } from '@tb-core/types/location';

/**
 * Returns a list of stores near the coordinates provided
 */
export default async function findStores({ lat, long }: LatLong) {
    let res: Response;

    const url = devProxyResolve(setProviderUrl(storesLookupUrl), {
        lat,
        long,
        timestamp: Date.now()
    });

    try {
        res = await Fetch({
            credentials: 'omit',
            host: '',
            url
        });
    } catch (e) {
        console.error('Find stores request failed!', e);
        // Exception to alpha per Datadog specifications
        const error = dataDogJSON(
            'order',
            'Google Maps API Calls',
            `Find stores request failed!: ${e}`,
            {}
        );

        datadogLogs.logger.log('Find stores request failed!', error, 'error');

        return {} as PostPlacesResponseProps;
    }

    if (!res.ok) {
        // Exception to alpha per Datadog specifications
        const resData = {
            requestHttpMethod: 'GET',
            responseCode: res.status,
            status: res.statusText,
            url: res.url
        };
        const error = dataDogJSON(
            'order',
            'Google Maps API Calls',
            `Find stores request failed!: ${res.statusText}`,
            resData
        );

        datadogLogs.logger.log('Find stores request failed!', error, 'error');

        return {} as PostPlacesResponseProps;
    }

    return res.json() as Promise<PostPlacesResponseProps>;
}
