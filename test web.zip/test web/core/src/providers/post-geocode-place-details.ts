import { datadogLogs } from '@datadog/browser-logs';

import { dataDogJSON } from '@tb-core/helpers/analytics/data-dog/json';
import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import Fetch from '@tb-core/helpers/fetch';
import { geoCodeUrl } from '@tb-core/next/api/urls';
import {
    PlaceDetailsRequestProps,
    PlaceDetailsResponseProps
} from '@tb-core/types/location';

/**
 * Used to communicate with geocode lambda, sending coordinates as a payload
 */
export default async function postGeocodePlaceDetails(
    props: PlaceDetailsRequestProps
) {
    let res: Response;

    try {
        res = await Fetch({
            body: JSON.stringify(props),
            credentials: 'omit',
            headers: {
                'Content-Type': 'application/json'
            },
            host: '',
            method: 'POST',
            url: devProxyResolve(geoCodeUrl)
        });
    } catch (e) {
        console.error('Geocode request failed!', e);
        // Exception to alpha per Datadog specifications
        const error = dataDogJSON(
            'order',
            'Google Maps API Calls',
            `Geocode Places details request failed: ${e}`,
            {}
        );

        datadogLogs.logger.log('Geocode Places details request failed', error);

        return [] as PlaceDetailsResponseProps[];
    }

    if (!res.ok) {
        // Exception to alpha per Datadog specifications
        const resData = {
            requestHttpMethod: 'GET',
            responseCode: res.status,
            status: res.statusText,
            url: res.url
        };
        const error = dataDogJSON(
            'order',
            'Google Maps API Calls',
            `Geocode request Place details failed!: ${res.statusText}`,
            resData
        );
        datadogLogs.logger.log(
            'Geocode request Place details failed!',
            error,
            'error'
        );

        return [] as PlaceDetailsResponseProps[];
    }

    return res.json() as Promise<PlaceDetailsResponseProps[]>;
}
