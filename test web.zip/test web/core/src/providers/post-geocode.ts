import { datadogLogs } from '@datadog/browser-logs';

import { dataDogJSON } from '@tb-core/helpers/analytics/data-dog/json';
import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import Fetch from '@tb-core/helpers/fetch';
import { geoCodeUrl } from '@tb-core/next/api/urls';
import {
    GeocodeRequestProps,
    GeocodeResponseProps
} from '@tb-core/types/location';

/**
 * Communicates with geocode lambda sending a query as the payload
 */
export default async function postGeocode(props: GeocodeRequestProps) {
    let res: Response;

    try {
        res = await Fetch({
            body: JSON.stringify(props),
            credentials: 'omit',
            headers: {
                'Content-Type': 'application/json'
            },
            host: '',
            method: 'POST',
            url: devProxyResolve(geoCodeUrl)
        });
    } catch (e) {
        console.error('Geocode request failed!', e);
        // Exception to alpha per Datadog specifications
        const error = dataDogJSON(
            'order',
            'Google Maps API Calls',
            `Google Maps API Call Failed: ${e}`,
            {}
        );

        datadogLogs.logger.log('Geocode request failed!', error, 'error');

        return [] as GeocodeResponseProps[];
    }

    if (!res.ok) {
        // Exception to alpha per Datadog specifications
        const resData = {
            requestHttpMethod: 'GET',
            responseCode: res.status,
            status: res.statusText,
            url: res.url
        };
        const error = dataDogJSON(
            'order',
            'Google Maps API Calls',
            `Geocode request failed!: ${res.statusText}`,
            resData
        );

        datadogLogs.logger.log('Geocode request failed!', error, 'error');

        return [] as GeocodeResponseProps[];
    }

    return res.json() as Promise<GeocodeResponseProps[]>;
}
