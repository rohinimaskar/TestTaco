import { datadogLogs } from '@datadog/browser-logs';

import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import Fetch from '@tb-core/helpers/fetch';
import { interpolate } from '@tb-core/helpers/interpolate';
import { tbApiHost } from '@tb-core/helpers/next-env';
import { unsubscribeUrl } from '@tb-core/next/api/urls';
import { DefaultResponseProps } from '@tb-core/types';

export default async function postUnsubscribeEmail(email: string) {
    const errorFetch = [
        {
            message: 'Unable to unsubscribe user.',
            reason: 'The server could not be reached.'
        }
    ];
    const errorResponse = [
        {
            message: 'Unable to unsubscribe user.',
            reason: 'The server responded with an error.'
        }
    ];
    let res: Response;

    try {
        res = await Fetch({
            host: tbApiHost,
            url: devProxyResolve(interpolate(unsubscribeUrl, { email }))
        });
    } catch (e) {
        datadogLogs.logger.log(
            'Unsubscribe email request failed!',
            { errorFetch, e },
            'error'
        );

        return {
            errors: errorFetch,
            success: false
        } as DefaultResponseProps;
    }

    if (!res.ok) {
        datadogLogs.logger.log(
            'Places request failed!',
            { errorResponse },
            'error'
        );

        return {
            errors: errorResponse,
            success: false
        } as DefaultResponseProps;
    }

    return {
        status: res.status,
        success: res.ok
    } as DefaultResponseProps;
}
