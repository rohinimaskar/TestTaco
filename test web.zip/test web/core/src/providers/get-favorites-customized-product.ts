import { datadogLogs } from '@datadog/browser-logs';

import { devProxy } from '@tb-core/helpers/browser/dev-proxy';
import { devSSRProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import Fetch from '@tb-core/helpers/fetch';
import { interpolate } from '@tb-core/helpers/interpolate';
import { serverlessApiUrl } from '@tb-core/helpers/next-env';
import { favoritesApiSharedCustomizedProduct } from '@tb-core/next/api/urls';
import { FetchResponse } from '@tb-core/types';
import { SharedFavoriteProduct } from '@tb-core/types/favorites';

export default async function getFavoritesCustomizedProduct(
    customizedProduct: string,
    serverSideHost?: string
): FetchResponse<SharedFavoriteProduct> {
    let res: Response;

    try {
        if (serverSideHost) {
            const url = devSSRProxyResolve(
                serverSideHost,
                interpolate(
                    serverlessApiUrl + favoritesApiSharedCustomizedProduct,
                    {
                        customizedProduct
                    }
                ),
                {
                    customizedProduct
                }
            );
            res = await Fetch({
                host: '',
                url
            });
        } else {
            res = await Fetch({
                headers: {
                    'Content-Type': 'application/json'
                },
                method: 'GET',
                ...devProxy({
                    host: serverlessApiUrl,
                    url: interpolate(favoritesApiSharedCustomizedProduct, {
                        customizedProduct
                    })
                })
            });
        }
    } catch (e) {
        console.error('Favorites Customized Product request failed!', e);
        datadogLogs.logger.log('getFavoritesCustomizedProduct', { e }, 'error');
        return { success: false };
    }

    if (!res.ok) {
        const errors = await res.json();
        return { ...errors, success: false };
    }

    const parsedResponse = await res.json();

    return {
        ...parsedResponse,
        success: true
    };
}
