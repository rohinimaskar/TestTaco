import { datadogLogs } from '@datadog/browser-logs';

import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import Fetch from '@tb-core/helpers/fetch';
import { getGiftCardBalance as giftCardBalance } from '@tb-core/next/api/urls';
import { GiftCardBalanceResponseBody } from '@tb-core/types/gift-card';

const getGiftCardBalance = async (cardNumber: string, pin: string) => {
    let res: Response;

    try {
        res = await Fetch({
            host: '',
            url: devProxyResolve(giftCardBalance, {
                giftCardNumber: cardNumber,
                giftCardPin: pin
            })
        });
    } catch (error) {
        console.error('Gift Card Balance API GET request failed!', error);
        datadogLogs.logger.log(
            'Getting Gift Card Balance Failed',
            { error },
            'error'
        );
        return { success: false } as GiftCardBalanceResponseBody;
    }

    if (!res.ok) {
        const errors = await res.json();
        datadogLogs.logger.log(
            'Getting Gift Card Balance Failed',
            { errors },
            'error'
        );
        return { ...errors, success: false } as GiftCardBalanceResponseBody;
    }

    const parsedResponse = (await res.json()) as Promise<
        GiftCardBalanceResponseBody
    >;

    return {
        ...parsedResponse,
        success: true
    };
};

export default getGiftCardBalance;
