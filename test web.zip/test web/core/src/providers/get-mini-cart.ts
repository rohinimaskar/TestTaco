import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import Fetch from '@tb-core/helpers/fetch';
import { nextMiniCartUrl } from '@tb-core/next/api/urls';

export default async function getMiniCart() {
    let res: Response;

    try {
        res = await Fetch({
            host: '',
            url: devProxyResolve(nextMiniCartUrl)
        });
    } catch (e) {
        console.error('Mini-cart request failed!', e);
        // @TODO Define return type.
        return {};
    }

    if (!res.ok) {
        // @TODO Define return type.
        return {};
    }

    // @TODO Define return type.
    return res.json();
}
