import { datadogLogs } from '@datadog/browser-logs';
import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import { setAccessTokenHeader } from '@tb-core/helpers/client/auth';
import Fetch, { toError } from '@tb-core/helpers/fetch';
import { setProviderUrl } from '@tb-core/helpers/utils/set-provider-url';
import {
    paymentMethodGuestUserUrl,
    paymentMethodLoggedInUserUrl
} from '@tb-core/next/api/urls';
import { CartResponse } from '@tb-core/types/checkout/checkout-cart';
import { PaymentMethodProps } from '@tb-core/types/checkout/credit-and-gift-cards';

/**
 * PUT a payment method for guest users
 * @param PaymentMethodProps
 * @return a CartResponse
 */
export async function putPaymentMethodGuestUser(
    props: PaymentMethodProps,
    guestAccessToken: string
) {
    let res: Response;
    const url = devProxyResolve(
        setProviderUrl(paymentMethodGuestUserUrl),
        props
    );

    try {
        res = await Fetch({
            headers: {
                Authorization: `Bearer ${guestAccessToken}`,
                'Content-Type': 'application/json'
            },
            host: '',
            method: 'PUT',
            url
        });
    } catch (e) {
        const error = toError(e);
        console.error('PUT Payment Method Guest User Failed', error);
        datadogLogs.logger.log('putPaymentMethodGuestUser', error, 'error');
        return { success: false } as CartResponse;
    }

    if (!res.ok) {
        const errors = await res.json();
        datadogLogs.logger.log('putPaymentMethodGuestUser', errors, 'error');
        return { ...errors, success: false } as CartResponse;
    }

    return res.json() as Promise<CartResponse>;
}

/**
 * PUT a payment method for logged in user
 * @param PaymentMethodProps
 * @return a CartResponse
 */
export async function putPaymentMethodLoggedInUser(props: PaymentMethodProps) {
    let res: Response;
    const url = devProxyResolve(
        setProviderUrl(paymentMethodLoggedInUserUrl),
        props
    );

    try {
        res = await Fetch({
            headers: await setAccessTokenHeader({
                'Content-Type': 'application/json'
            }),
            host: '',
            method: 'PUT',
            url
        });
    } catch (e) {
        const error = toError(e);
        console.error('PUT Payment Method For Logged In User Failed', error);
        datadogLogs.logger.log('putPaymentMethodLoggedInUser', error, 'error');
        return { success: false } as CartResponse;
    }

    if (!res.ok) {
        const errors = await res.json();
        datadogLogs.logger.log('putPaymentMethodLoggedInUser', errors, 'error');
        return { ...errors, success: false } as CartResponse;
    }

    return res.json() as Promise<CartResponse>;
}
