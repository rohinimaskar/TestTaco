import { datadogLogs } from '@datadog/browser-logs';
import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import {
    getAccessToken,
    setBearerTokenHeader
} from '@tb-core/helpers/client/auth';
import Fetch from '@tb-core/helpers/fetch';
import { setProviderUrl } from '@tb-core/helpers/utils/set-provider-url';
import { getCreditAndGiftCardsUrl } from '@tb-core/next/api/urls';
import { PaymentDetailsResponse } from '@tb-core/types/checkout/credit-and-gift-cards';

const errorResponse: PaymentDetailsResponse = {
    ccPaymentInfos: [],
    gcPaymentInfos: [],
    success: false
};

export default async function getCreditAndGiftCards(): Promise<
    PaymentDetailsResponse
> {
    const accessToken = await getAccessToken();
    let res: Response;
    const url = devProxyResolve(setProviderUrl(getCreditAndGiftCardsUrl), {
        allGiftCards: 'true'
    });

    try {
        res = await Fetch({
            headers: setBearerTokenHeader({}, accessToken),
            host: '',
            url
        });
    } catch (error) {
        console.error('Get credit cards gift cards failed!', error);
        datadogLogs.logger.log('getCreditAndGiftCards', { error }, 'error');
        return errorResponse;
    }

    if (!res.ok) {
        const error = await res.json();
        datadogLogs.logger.log('getCreditAndGiftCards', { error }, 'error');
        return errorResponse;
    }

    return {
        ...(await res.json()),
        success: true
    };
}
