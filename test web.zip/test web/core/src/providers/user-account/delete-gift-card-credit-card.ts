import { datadogLogs } from '@datadog/browser-logs';
import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import { setAccessTokenHeader } from '@tb-core/helpers/client/auth';
import Fetch, { toError } from '@tb-core/helpers/fetch';
import { setProviderUrl } from '@tb-core/helpers/utils/set-provider-url';
import {
    paymentMethodGuestUserUrl,
    paymentMethodLoggedInUserUrl
} from '@tb-core/next/api/urls';
import { CartResponse } from '@tb-core/types/checkout/checkout-cart';
import { PaymentMethodProps } from '@tb-core/types/checkout/credit-and-gift-cards';

/**
 * DELETE a payment method for guest user
 * @param PaymentMethodProps
 * @return a CartResponse
 */
export async function deletePaymentMethodGuestUser(
    props: PaymentMethodProps,
    guestAccessToken: string
) {
    let res: Response;
    const url = devProxyResolve(
        setProviderUrl(paymentMethodGuestUserUrl),
        props
    );

    try {
        res = await Fetch({
            headers: {
                Authorization: `Bearer ${guestAccessToken}`,
                'Content-Type': 'application/json'
            },
            host: '',
            method: 'DELETE',
            url
        });
    } catch (e) {
        const error = toError(e);
        console.error('DELETE Payment Method Guest User Failed', error);
        datadogLogs.logger.log('deletePaymentMethodGuestUser', error, 'error');
        return { success: false } as CartResponse;
    }

    if (!res.ok) {
        const errors = await res.json();
        datadogLogs.logger.log('deletePaymentMethodGuestUser', errors, 'error');
        return { ...errors, success: false } as CartResponse;
    }

    return res.json() as Promise<CartResponse>;
}

/**
 * DELETE a payment method for logged in user
 * @param PaymentMethodProps
 * @return a CartResponse
 */
export async function deletePaymentMethodLoggedInUser(
    props: PaymentMethodProps
) {
    let res: Response;
    const url = devProxyResolve(
        setProviderUrl(paymentMethodLoggedInUserUrl),
        props
    );

    try {
        res = await Fetch({
            headers: await setAccessTokenHeader({
                'Content-Type': 'application/json'
            }),
            host: '',
            method: 'DELETE',
            url
        });
    } catch (e) {
        const error = toError(e);
        console.error('DELETE Payment Method For Logged In User Failed', error);
        datadogLogs.logger.log(
            'deletePaymentMethodLoggedInUser',
            error,
            'error'
        );
        return { success: false } as CartResponse;
    }

    if (!res.ok) {
        const errors = await res.json();
        datadogLogs.logger.log(
            'deletePaymentMethodLoggedInUser',
            errors,
            'error'
        );
        return { ...errors, success: false } as CartResponse;
    }

    return res.json() as Promise<CartResponse>;
}
