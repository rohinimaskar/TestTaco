import { datadogLogs } from '@datadog/browser-logs';

import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import { getGuestToken } from '@tb-core/helpers/client/auth';
import Fetch from '@tb-core/helpers/fetch';
import { interpolate } from '@tb-core/helpers/interpolate';
import { setProviderUrl } from '@tb-core/helpers/utils/set-provider-url';
import { deleteGuestOrderByGuidUrl } from '@tb-core/next/api/urls';
import { RealObject } from '@tb-core/types';

export default async function deleteGuestOrderByGuid(guid: string) {
    let res: Response;
    const accessToken = await getGuestToken();
    const url = devProxyResolve(
        interpolate(setProviderUrl(deleteGuestOrderByGuidUrl), {
            guid
        })
    );

    try {
        res = await Fetch({
            headers: {
                Authorization: `Bearer ${accessToken}`
            },
            host: '',
            method: 'DELETE',
            url
        });
    } catch (error) {
        console.error('Order delete failed!', error);
        datadogLogs.logger.log('deleteGuestOrderByGuid', { error }, 'error');
        return { success: false };
    }

    if (!res.ok) {
        const error = await res.json();
        datadogLogs.logger.log('deleteGuestOrderByGuid', { error }, 'error');
        return { ...error, success: false };
    }

    return res.json() as Promise<RealObject>;
}
