import { datadogLogs } from '@datadog/browser-logs';

import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import { setBearerTokenHeader } from '@tb-core/helpers/client/auth';
import Fetch from '@tb-core/helpers/fetch';
import { interpolate } from '@tb-core/helpers/interpolate';
import { setProviderUrl } from '@tb-core/helpers/utils/set-provider-url';
import { getGuestOrderByGuidUrl } from '@tb-core/next/api/urls';

export default async function getGuestOrderByGuid(
    guid: string | string[],
    accessToken: string = ''
) {
    let res: Response;
    const url = devProxyResolve(
        interpolate(setProviderUrl(getGuestOrderByGuidUrl), { guid })
    );

    try {
        res = await Fetch({
            headers: setBearerTokenHeader({}, accessToken),
            host: '',
            method: 'GET',
            url
        });
    } catch (error) {
        console.error('Order request failed!', error);
        datadogLogs.logger.log('getGuestOrderByGuid', { error }, 'error');
        return { success: false };
    }

    if (!res.ok) {
        const error = await res.json();
        datadogLogs.logger.log('getGuestOrderByGuid', { error }, 'error');
        return { ...error, success: false };
    }
    const parsedResponse = await res.json();

    return {
        ...parsedResponse,
        success: true
    };
}
