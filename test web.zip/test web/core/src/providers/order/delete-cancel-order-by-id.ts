import { datadogLogs } from '@datadog/browser-logs';

import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import { getAccessToken } from '@tb-core/helpers/client/auth';
import Fetch from '@tb-core/helpers/fetch';
import { interpolate } from '@tb-core/helpers/interpolate';
import { setProviderUrl } from '@tb-core/helpers/utils/set-provider-url';
import { deleteOrderByIdUrl } from '@tb-core/next/api/urls';
import { RealObject } from '@tb-core/types';

export default async function deleteOrderById(orderCode: string) {
    let res: Response;
    const accessToken = await getAccessToken();
    const url = devProxyResolve(
        interpolate(setProviderUrl(deleteOrderByIdUrl), { orderCode })
    );

    try {
        res = await Fetch({
            headers: {
                Authorization: `Bearer ${accessToken}`
            },
            host: '',
            method: 'DELETE',
            url
        });
    } catch (error) {
        console.error('Order delete failed!', error);
        datadogLogs.logger.log('deleteOrderById', { error }, 'error');
        return { success: false };
    }

    if (!res.ok) {
        const error = await res.json();
        datadogLogs.logger.log('deleteOrderById', { error }, 'error');
        return { ...error, success: false };
    }

    return res.json() as Promise<RealObject>;
}
