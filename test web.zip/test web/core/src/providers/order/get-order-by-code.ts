import { datadogLogs } from '@datadog/browser-logs';

import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import { getAccessToken } from '@tb-core/helpers/client/auth';
import Fetch from '@tb-core/helpers/fetch';
import { interpolate } from '@tb-core/helpers/interpolate';
import { setProviderUrl } from '@tb-core/helpers/utils/set-provider-url';
import { getOrderByCodeUrl } from '@tb-core/next/api/urls';
import { RealObject } from '@tb-core/types';

export default async function getOrderByCode(orderCode: string | string[]) {
    let res: Response;
    const accessToken = await getAccessToken();
    const url = devProxyResolve(
        interpolate(setProviderUrl(getOrderByCodeUrl), { orderCode })
    );

    try {
        res = await Fetch({
            headers: {
                Authorization: `Bearer ${accessToken}`
            },
            host: '',
            method: 'GET',
            url
        });
    } catch (error) {
        console.error('Orders request failed!', error);
        datadogLogs.logger.log('getOrderByCode', { error }, 'error');
        return { error, success: false };
    }

    if (!res.ok) {
        const error = await res.json();
        datadogLogs.logger.log('getOrderByCode', { error }, 'error');
        return { ...error, success: false };
    }

    const data = await res.json();

    return { success: true, ...data } as RealObject;
}
