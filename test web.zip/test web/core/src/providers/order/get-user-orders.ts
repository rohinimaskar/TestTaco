import { datadogLogs } from '@datadog/browser-logs';

import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import { getAccessToken } from '@tb-core/helpers/client/auth';
import Fetch from '@tb-core/helpers/fetch';
import { createQueryString } from '@tb-core/helpers/url';
import { setProviderUrl } from '@tb-core/helpers/utils/set-provider-url';
import { getUserOrdersUrl } from '@tb-core/next/api/urls';
import { OrdersResponse } from '@tb-core/types/order';

interface GetUserOrdersProps {
    currentPage?: string;
    pageSize?: string;
}

export default async function getUserOrders({
    currentPage,
    pageSize
}: GetUserOrdersProps) {
    let res: Response;
    const accessToken = await getAccessToken();
    const urlValues = { currentPage, pageSize };
    const url = devProxyResolve(
        setProviderUrl(getUserOrdersUrl) + createQueryString(urlValues)
    );

    try {
        res = await Fetch({
            headers: {
                Authorization: `Bearer ${accessToken}`
            },
            host: '',
            method: 'GET',
            url
        });
    } catch (error) {
        console.error('Orders request failed!', error);
        datadogLogs.logger.log('getUserOrders', { error }, 'error');
        return { success: false };
    }

    if (!res.ok) {
        const error = await res.json();
        datadogLogs.logger.log('getUserOrders', { error }, 'error');
        return { ...error, success: false };
    }

    return res.json() as Promise<OrdersResponse>;
}
