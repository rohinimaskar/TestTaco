import { datadogLogs } from '@datadog/browser-logs';
import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import { setAccessTokenHeader } from '@tb-core/helpers/client/auth';
import Fetch, { toError } from '@tb-core/helpers/fetch';
import { setProviderUrl } from '@tb-core/helpers/utils/set-provider-url';
import {
    giftCardAddGuestUserUrl,
    giftCardAddLoggedInUserUrl,
    giftCardAddToUserAccountUrl
} from '@tb-core/next/api/urls';
import { FetchResponse } from '@tb-core/types';
import { CartResponse } from '@tb-core/types/checkout/checkout-cart';
import {
    AddGiftCardGuestUserToken,
    AddGiftCardLoggedInUserToken,
    AddGiftCardPayload,
    AddGiftCardPayloadLoggedInUser,
    AddGiftCardToUserAccountToken,
    GiftCardInfoResponse
} from '@tb-core/types/checkout/credit-and-gift-cards';

const defaultSaveGiftCardOption = 'true';

/**
 * Add a gift card for guest user
 * @param AddGiftCardGuestUserProps
 * @return a CartResponse
 */
export async function addGiftCardGuestUser({
    cartId,
    guestUserId,
    guestAccessToken,
    yumGiftCardToken
}: AddGiftCardGuestUserToken) {
    let res: Response;
    const payload: AddGiftCardPayload = {
        token: yumGiftCardToken
    };
    const url = devProxyResolve(setProviderUrl(giftCardAddGuestUserUrl), {
        cartId,
        guestUserId,
        token: yumGiftCardToken
    });

    try {
        res = await Fetch({
            body: JSON.stringify(payload),
            headers: {
                Authorization: `Bearer ${guestAccessToken}`,
                'Content-Type': 'application/json'
            },
            host: '',
            method: 'POST',
            url
        });
    } catch (e) {
        const error = toError(e);
        console.error('Add Gift Card For Guest User Failed', error);
        datadogLogs.logger.log('addGiftCardGuestUser', error, 'error');
        return { success: false } as CartResponse | GiftCardInfoResponse;
    }

    if (!res.ok) {
        const errors = await res.json();
        datadogLogs.logger.log('addGiftCardGuestUser', errors, 'error');
        return { ...errors, success: false } as
            | CartResponse
            | GiftCardInfoResponse;
    }

    const parsedResult = await res.json();

    // @TODO: Fix return type! should not be of multiple types!
    return {
        ...parsedResult,
        success: true
    } as Promise<CartResponse | GiftCardInfoResponse>;
}

/**
 * Add a gift card for logged in user
 * @param AddGiftCardLoggedInUserProps
 * @return a CartResponse
 */
export async function addGiftCardLoggedInUser({
    cartCode,
    yumGiftCardToken
}: AddGiftCardLoggedInUserToken) {
    const payload: AddGiftCardPayloadLoggedInUser = {
        save: defaultSaveGiftCardOption,
        token: yumGiftCardToken
    };
    let res: Response;
    const url = devProxyResolve(setProviderUrl(giftCardAddLoggedInUserUrl), {
        cartCode,
        token: yumGiftCardToken
    });

    try {
        res = await Fetch({
            body: JSON.stringify(payload),
            headers: await setAccessTokenHeader({
                'Content-Type': 'application/json'
            }),
            host: '',
            method: 'POST',
            url
        });
    } catch (e) {
        const error = toError(e);
        console.error('Add Gift Card For Logged In User Failed', error);
        datadogLogs.logger.log('addGiftCardLoggedInUser', error, 'error');
        return { success: false } as CartResponse | GiftCardInfoResponse;
    }

    if (!res.ok) {
        const errors = await res.json();
        datadogLogs.logger.log('addGiftCardLoggedInUser', errors, 'error');
        return {
            ...errors,
            success: false
        } as CartResponse | GiftCardInfoResponse;
    }

    const parsedResult = await res.json();

    // @TODO: Fix return type! should not be of multiple types!
    return {
        ...parsedResult,
        success: true
    } as Promise<CartResponse | GiftCardInfoResponse>;
}

/**
 * Add gift card to user account
 * @param AddGiftCardToUserAccountToken
 * @return a CartResponse
 */
export async function postAddGiftCardToUserAccount({
    customerId,
    yumGiftCardToken
}: AddGiftCardToUserAccountToken): FetchResponse<GiftCardInfoResponse> {
    const payload = {
        customerId,
        save: defaultSaveGiftCardOption,
        token: yumGiftCardToken
    };
    let res: Response;
    const url = devProxyResolve(setProviderUrl(giftCardAddToUserAccountUrl));

    try {
        res = await Fetch({
            body: JSON.stringify(payload),
            headers: await setAccessTokenHeader({
                'Content-Type': 'application/json'
            }),
            host: '',
            method: 'POST',
            url
        });
    } catch (e) {
        const error = toError(e);
        console.error('Add Gift Card To User Account Failed', error);
        datadogLogs.logger.log('postAddGiftCardToUserAccount', error, 'error');
        return { success: false };
    }

    if (!res.ok) {
        const errors = await res.json();
        datadogLogs.logger.log('postAddGiftCardToUserAccount', errors, 'error');
        return { ...errors, success: false };
    }

    const parsedResult = await res.json();

    return {
        ...parsedResult,
        success: true
    };
}
