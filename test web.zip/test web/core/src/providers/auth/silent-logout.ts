import { datadogLogs } from '@datadog/browser-logs';
import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import {
    getAccessToken,
    setBearerTokenHeader
} from '@tb-core/helpers/client/auth';
import Fetch from '@tb-core/helpers/fetch';

export const silentLogoutRequest = async () => {
    let res: Response;
    const accessToken = await getAccessToken();

    try {
        res = await Fetch({
            headers: await setBearerTokenHeader({}, accessToken),
            host: '',
            method: 'POST',
            url: devProxyResolve('/api/userAuth/v1/idp/oidc/session/end')
        });
    } catch (error) {
        console.error('Logout request failed!', error);
        datadogLogs.logger.log('logoutRequest', { error }, 'error');
        return { success: false };
    }

    if (!res.ok) {
        datadogLogs.logger.log('logoutRequest', res, 'error');
        return { success: false };
    }

    return { success: true };
};
