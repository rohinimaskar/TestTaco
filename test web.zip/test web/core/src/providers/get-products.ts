import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import Fetch from '@tb-core/helpers/fetch';
import { productsUrl } from '@tb-core/next/api/urls';
import { RealObject } from '@tb-core/types';
import { Product } from '@tb-core/types/products';

type Filter = (args: Product) => boolean;

export default async function getProducts(
    term: string,
    _limit = 0,
    filter?: Filter
) {
    let res: Response;

    try {
        res = await Fetch({
            host: '',
            url: devProxyResolve(productsUrl, { term })
        });
    } catch (e) {
        console.error('Product Search request failed!', e);
        // @TODO Define return type.
        return [];
    }

    if (!res.ok) {
        // @TODO Define return type.
        return [];
    }

    // @TODO Define return type.
    return parse(await res.json(), _limit, filter);
}

/**
 * Parses the response of products.
 * @param param0 The Response containing a product list based on the query (`term`).
 * @param limit The limit of products to return.
 * @todo Update Response type from `any`.
 */
const parse = ({ products }: any, limit = 0, filter?: Filter) => {
    const results =
        typeof filter === 'function'
            ? (products || []).filter(filter)
            : products || [];

    return results
        .slice(0, Math.max(limit, 10))
        .map(({ images, name, url }: RealObject) => ({
            images,
            name,
            url
        }));
};
