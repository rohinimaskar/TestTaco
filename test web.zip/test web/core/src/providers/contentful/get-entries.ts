import { getContent } from '@tb-core/helpers/contentful';
import {
    ContentfulDeliveryClientRequest,
    ContentfulEntry
} from '@tb-core/types/contentful';

export default async function getEntries({
    search,
    type,
    ...clientConfig
}: ContentfulDeliveryClientRequest): Promise<ContentfulEntry[]> {
    const { items = [] } = await getContent({
        clientConfig,
        contentType: type,
        searchParams: search
    });

    return items;
}
