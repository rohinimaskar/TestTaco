import { datadogLogs } from '@datadog/browser-logs';
import { storeAdapter } from '@tb-core/adapters/store/store-adapter';
import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import Fetch from '@tb-core/helpers/fetch';
import { setProviderUrl } from '@tb-core/helpers/utils/set-provider-url';
import { storePickupTimeUrl } from '@tb-core/next/api/urls';
import { FetchResponse, Store } from '@tb-core/types';
import { TimeSlot } from '@tb-core/types/location';

/**
 * getStorePickupTimes() -
 * we are already making call to get store data in find-stores.ts, so why this call too?
 * Because this call returns the most accurate store pickup time info
 * Apps ( Android and iOS ) do not make this call because
 * Apps allows user to pick store pickup time on checkout page, and this data is received in checkout call
 */
export async function getStorePickupTimes(
    storeId: string
): FetchResponse<{
    breakfastTime?: {
        startTime?: string;
        endTime?: string;
    };
    storeData: Store;
    storePickupTimeSlots: TimeSlot[];
}> {
    const errorLogMessage = 'getStorePickupTimes Failed';
    let res: Response;
    const url = devProxyResolve(setProviderUrl(storePickupTimeUrl), {
        storeId
    });

    try {
        res = await Fetch({
            host: '', // hybris endpoint so leave blank
            url
        });
    } catch (error) {
        console.error(errorLogMessage, error);
        datadogLogs.logger.log(errorLogMessage, { error }, 'error');
        return { success: false };
    }

    if (!res.ok) {
        const errors = await res.json();
        datadogLogs.logger.log(errorLogMessage, errors, 'error');
        return { success: false };
    }

    const parsedResponse = await res.json();
    const storeData = storeAdapter(parsedResponse);
    const {
        breakfastEndTime,
        breakfastStartTime
    } = parsedResponse?.pickUpTimes;
    const breakfastTime =
        breakfastStartTime && breakfastEndTime
            ? {
                  endTime: breakfastEndTime,
                  startTime: breakfastStartTime
              }
            : undefined;
    return {
        breakfastTime,
        storeData,
        storePickupTimeSlots: parsedResponse?.pickUpTimes?.todayTimeSlots,
        success: true
    };
}
