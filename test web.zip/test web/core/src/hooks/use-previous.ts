import { useEffect, useRef } from 'react';

/**
 * This function is used for keeping track of a previous state value
 *
 * @param value - the previous state to be keep tracked of
 * @return ref.current - value of the previous state
 *
 * @example
 * const [selectedIngredient, setSelectedIngredient] = useState(ingredients);
 * const prevSelectedIngredient = usePrevious(selectedIngredients);
 */
export const usePrevious = (value: any) => {
    const ref = useRef();

    useEffect(() => {
        ref.current = value;
    });

    return ref.current;
};
