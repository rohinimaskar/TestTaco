import { ExperimentClient } from '@amplitude/experiment-js-client';
import { datadogLogs } from '@datadog/browser-logs';
import { useEffect, useState } from 'react';

import { amplitudeInitialize } from '@tb-core/helpers/analytics/amplitude';
import oneTrustConsent from '@tb-core/helpers/analytics/one-trust';
import { toError } from '@tb-core/helpers/fetch';
import { AmplitudeExperimentProps } from '@tb-core/types/amplitude';

const useAmplitudeExperiment = ({
    isLoggedIn,
    query,
    userUid
}: AmplitudeExperimentProps) => {
    const [experiment, setExperiment] = useState<ExperimentClient>();

    useEffect(() => {
        const getAmplitudeExperiment = async () => {
            if (isLoggedIn === undefined || !oneTrustConsent()) {
                return;
            }

            try {
                let shaUser = '';

                if (userUid) {
                    try {
                        const { createHash } = await import(
                            '@tb-core/helpers/sha-generator'
                        );
                        shaUser = await createHash(userUid, true);
                    } catch (e) {
                        const error = toError(e);
                        datadogLogs.logger.log('SHA generation error', error);
                    }
                }

                const experiment = await amplitudeInitialize(query, shaUser);

                if (experiment) {
                    setExperiment(experiment);
                }
            } catch (e) {
                const error = toError(e);
                datadogLogs.logger.log('Amplitude initialization error', error);
            }
        };

        getAmplitudeExperiment();
    }, [isLoggedIn, userUid, query]);

    return { experiment };
};

export default useAmplitudeExperiment;
