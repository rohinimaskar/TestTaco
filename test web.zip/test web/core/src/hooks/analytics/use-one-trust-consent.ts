import { useEffect, useState } from 'react';

const useOneTrustConsent = () => {
    const [canTrack, setCanTrack] = useState<boolean>(false);

    const checkConsent = () => {
        if (typeof window !== 'undefined' && window.OnetrustActiveGroups) {
            setCanTrack(window.OnetrustActiveGroups.includes('C0002'));
        }
    };

    useEffect(() => {
        setTimeout(() => {
            checkConsent();
        }, 500);

        window.addEventListener('OneTrustGroupsUpdated', checkConsent);

        return () =>
            window.removeEventListener('OneTrustGroupsUpdated', checkConsent);
    }, []);

    return { canTrack };
};

export default useOneTrustConsent;
