import { useEffect, useState } from 'react';

import { getGuestToken } from '@tb-core/helpers/client/auth';
import useUserContext from '@tb-core/hooks/use-user-context';
import {
    deletePaymentMethodGuestUser,
    deletePaymentMethodLoggedInUser
} from '@tb-core/providers/user-account/delete-gift-card-credit-card';
import getCreditAndGiftCards from '@tb-core/providers/user-account/get-credit-gift-cards';
import {
    putPaymentMethodGuestUser,
    putPaymentMethodLoggedInUser
} from '@tb-core/providers/user-account/put-gift-card-credit-card';
import {
    CartResponse,
    CartSummary
} from '@tb-core/types/checkout/checkout-cart';
import {
    AddCreditCardToList,
    AddGiftCardToList,
    CreditCardInfo,
    GiftCardInfo,
    PaymentMethodProps
} from '@tb-core/types/checkout/credit-and-gift-cards.d';

// provider hook: on checkout page load, get credit and gift cards
export const useCreditAndGiftCards = () => {
    const { isLoggedIn } = useUserContext();
    const [isPaymentCardInfoLoading, setIsPaymentCardInfoLoading] = useState(
        true
    );
    const [creditCards, setCreditCards] = useState([] as CreditCardInfo[]);
    const [giftCards, setGiftCards] = useState([] as GiftCardInfo[]);
    const [isError, setIsError] = useState(false);
    const [guestAccessToken, setGuestAccessToken] = useState('');
    const [refetchCards, setRefetchCards] = useState(true);

    const updateGiftCards = (result: CartResponse) => {
        const { userCardInfo } = result;
        const { gcPaymentInfos } = userCardInfo;
        const gcs = [...giftCards];

        gcPaymentInfos.forEach(gcPayment => {
            const index = gcs?.findIndex(gc => gc.id === gcPayment.id);
            gcs[index].isCardSelected = gcPayment.isCardSelected;
        });

        setGiftCards(gcs);
    };

    const syncAllCards = async () => {
        const {
            ccPaymentInfos,
            gcPaymentInfos,
            success
        } = await getCreditAndGiftCards();

        setCreditCards(ccPaymentInfos);
        setGiftCards(gcPaymentInfos);
        setIsError(!success);
        setIsPaymentCardInfoLoading(false);
    };

    const addCreditCardToList: AddCreditCardToList = (
        result: CreditCardInfo
    ): void => {
        const newCcList = creditCards.concat(result);
        setCreditCards(newCcList);
    };

    const addGiftCardToList: AddGiftCardToList = result => {
        let newGcList;

        if ((result as CartResponse).addedGCPaymentInfo !== undefined) {
            newGcList = giftCards.concat(
                (result as CartResponse).addedGCPaymentInfo
            );
        } else if ((result as GiftCardInfo).cardNumber) {
            newGcList = giftCards.concat(result as GiftCardInfo);
        }

        if (newGcList) {
            setGiftCards(newGcList as GiftCardInfo[]);
        }
    };

    const selectPaymentMethod = async (props: PaymentMethodProps) => {
        let result;

        if (isLoggedIn) {
            result = await putPaymentMethodLoggedInUser(props);
        } else {
            result = await putPaymentMethodGuestUser(props, guestAccessToken);
        }

        if (result.success !== false) {
            updateGiftCards(result);
        }

        return result;
    };

    const deselectPaymentMethod = async (props: PaymentMethodProps) => {
        let result;

        if (isLoggedIn) {
            result = await deletePaymentMethodLoggedInUser(props);
        } else {
            result = await deletePaymentMethodGuestUser(
                props,
                guestAccessToken
            );
        }

        if (result.success !== false) {
            updateGiftCards(result);
        }

        return result;
    };

    const togglePaymentMethod = (props: PaymentMethodProps) => {
        if (props.isCardSelected) {
            return deselectPaymentMethod(props);
        }

        return selectPaymentMethod(props);
    };

    // on page load, call API for checkoutCart
    useEffect(() => {
        const fetchResources = async () => {
            if (isLoggedIn) {
                syncAllCards();
            } else {
                setIsPaymentCardInfoLoading(false);
                const accessToken = await getGuestToken();

                // @TODO: Add error handling when fail to fetch guest access token
                if (accessToken) {
                    setGuestAccessToken(accessToken);
                }
            }
        };

        if (typeof isLoggedIn === 'boolean' && refetchCards) {
            setRefetchCards(false);
            fetchResources();
        }
    }, [isLoggedIn, refetchCards]);

    const howMuchGiftCardsCover = (cart: CartSummary) => {
        const total = cart.totalPriceWithTax.value;
        const selectedGiftCardsBalance = giftCards.reduce((sum, giftCard) => {
            if (giftCard.isCardSelected) {
                return sum + giftCard.balance;
            }
            return sum;
        }, 0);
        return total - selectedGiftCardsBalance < 0
            ? total
            : selectedGiftCardsBalance;
    };

    return {
        addCreditCardToList,
        addGiftCardToList,
        creditCards,
        giftCards,
        guestAccessToken,
        howMuchGiftCardsCover,
        isErrorGetCreditAndGiftCards: isError,
        isPaymentCardInfoLoading,
        selectPaymentMethod,
        setRefetchCards,
        togglePaymentMethod
    };
};
