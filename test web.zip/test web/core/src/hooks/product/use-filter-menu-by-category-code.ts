import { isProductValid } from '@tb-core/helpers/product';
import useMenuContext from '@tb-core/hooks/use-menu-context';
import { MenuProductCategory, Product } from '@tb-core/types/products';

/**
 * Filters a stores entire menu based on 1 or more category names.
 *
 * category - meaning the array of categories each product has. \
 * Not to be confused with Menu Categories.
 *
 * Ex: to get all Sauce Packets pass `'saucePacket'` \
 * which there is no Menu Category `'saucePacket'`
 */
export const useFilterMenuByCategoryCode = (categoryNames: string[]) => {
    const entireMenu: MenuProductCategory[] = useMenuContext()
        .menuProductCategories;

    const validProducts: Product[] = [];

    const isAlreadyAdded = (product: Product) =>
        validProducts.some(
            existingProduct => existingProduct.code === product.code
        );

    for (const menuCategory of entireMenu || []) {
        for (const product of menuCategory.products || []) {
            if (isProductValid(product) && !isAlreadyAdded(product)) {
                validProducts.push(product);
            }
        }
    }

    const foundProducts = validProducts.filter(product =>
        product.categories.some(category =>
            categoryNames.some(name => name === category.code)
        )
    );

    return foundProducts;
};
