import { isBreakfastAvailable } from '@tb-core/helpers/date';
import { CSCItemTemplate } from '@tb-core/types/client-side-cart';
import { Product } from '@tb-core/types/products';
import {
    SaucePacketData,
    saucePacketDataAdapter
} from '@tb-purchase/components/cart/styled/sauce-packets';
import { useFilterMenuByCategoryCode } from './use-filter-menu-by-category-code';

/**
 * Takes 'cartLineItems' and seprates out the sauces from the rest of the cart items:
 *  `'saucePackets'` \
 *  `'cartLineItemsSaucesRemoved'` \
 * All Sauces in the Menu should also be added to `'saucePackets'` as well \
 * Special case: `Breakfast Salsa` is added to front of sauces if a breakfast item in cart.
 */
export const useSeparateSaucesFromLineItems = (
    cartLineItems: CSCItemTemplate[]
) => {
    const isBreakfast = isBreakfastAvailable();
    const saucePacketProducts = useFilterMenuByCategoryCode([
        'saucePacket',
        'sauces'
    ]);
    const isSaucePacket = (id: string) =>
        saucePacketProducts.some(sauce => sauce.code === id);

    const cartLineItemsSaucesRemoved: CSCItemTemplate[] = [];
    const cartLineItemsJustSauces: CSCItemTemplate[] = [];
    for (const lineItem of cartLineItems) {
        if (isSaucePacket(lineItem.id)) {
            cartLineItemsJustSauces.push(lineItem);
        } else {
            cartLineItemsSaucesRemoved.push(lineItem);
        }
    }
    const saucePackets: SaucePacketData[] = [];
    const isBreakfastSalsa = (p: Product) =>
        p.categories.some(category => category.code === 'breakfast');

    for (const saucePacket of saucePacketProducts) {
        const qty =
            cartLineItemsJustSauces.find(item => item.id === saucePacket.code)
                ?.qty || 0;
        const saucePacketData = saucePacketDataAdapter(saucePacket, qty);
        if (isBreakfastSalsa(saucePacket)) {
            if (isBreakfast) {
                saucePackets.unshift(saucePacketData);
            }
        } else {
            saucePackets.push(saucePacketData);
        }
    }
    return { cartLineItemsSaucesRemoved, isSaucePacket, saucePackets };
};
