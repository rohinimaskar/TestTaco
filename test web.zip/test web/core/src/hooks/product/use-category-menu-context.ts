import { useContext } from 'react';

import { CategoryMenuContext } from '@tb-core/components/context/category-menu';

const useCategoryMenuContext = () => {
    const ctx = useContext(CategoryMenuContext);

    if (ctx === undefined) {
        throw new Error(
            'useCategoryMenuContext must be used within a CategoryMenuContext'
        );
    }

    return ctx;
};

export default useCategoryMenuContext;
