import { Dispatch, useReducer } from 'react';

import { CSCItemModifierOptions } from '@tb-core/constants/client-side-cart';
import { GaDataLayerConfig } from '@tb-core/helpers/analytics/google';

export interface Option {
    accurateCalorie: string;
    calories: string;
    code: string;
    groupType?: string;
    // Determines if the customization is part of a style selection
    includedWithStyle?: boolean;
    // onTheSide Product Code
    onTheSide?: string;
    // customization option category (ex: sauceOptions, upgradeOptions, addonOptions)
    opt: CSCItemModifierOptions;
    plu?: string;
    price: number;
}

export type OnCustomize =
    | (Dispatch<{
          option?: Option;
          type: ActionTypes;
      }> & { gaDataLayerConfig?: GaDataLayerConfig })
    | undefined;

export interface Customization {
    accurateCalorie: number;
    calories: number;
    defaultCalories: number;
    defaultPrice: number;
    price: number;
    // all the selected customization options
    selectedOptions: Option[];
}

export enum ActionTypes {
    AddCustomize = 0,
    InitCustomize,
    AddOnTheSideCustomize,
    RemoveCustomize,
    RemoveOnTheSideCustomize,
    ResetCustomize,
    SetStyleCustomize
}

const isDuplicateOption = (option: Option, selectedOptions: Option[]) =>
    selectedOptions.some(selectedOption => selectedOption.code === option.code);

const calculateCalories = (
    defaultCalories: number,
    selectedOptions: Option[]
) =>
    selectedOptions.reduce(
        (calories, option) => calories + Number(option.calories),
        defaultCalories
    );

const calculatePrice = (defaultPrice: number, selectedOptions: Option[]) =>
    selectedOptions.reduce(
        (price, option) =>
            price + (option.includedWithStyle ? 0 : option.price),
        defaultPrice
    );

const customizeReducer = (
    customization: Customization, // the state
    action: { option?: Option; type: ActionTypes }
) => {
    const { option, type } = action;
    const { accurateCalorie, selectedOptions } = customization;

    switch (type) {
        case ActionTypes.AddCustomize: {
            if (
                option &&
                !isDuplicateOption(option, customization.selectedOptions)
            ) {
                customization.selectedOptions.push(option);
                customization.accurateCalorie =
                    accurateCalorie + Number(option.accurateCalorie) || 0;
                customization.calories = calculateCalories(
                    customization.defaultCalories,
                    customization.selectedOptions
                );
                customization.price = calculatePrice(
                    customization.defaultPrice,
                    customization.selectedOptions
                );
            }
            break;
        }
        case ActionTypes.InitCustomize: {
            customization.selectedOptions.length = 0;
            customization.defaultPrice = option?.price || 0;
            customization.price = Number(option?.price) || 0;
            customization.defaultCalories = Number(option?.calories) || 0;
            customization.accurateCalorie =
                Number(option?.accurateCalorie) || 0.0;
            customization.calories = Number(option?.calories) || 0;
            break;
        }
        case ActionTypes.AddOnTheSideCustomize: {
            if (option?.code) {
                const selectedOption = customization.selectedOptions.find(
                    selectedOption => selectedOption.code === option.code
                );

                if (selectedOption) {
                    selectedOption.onTheSide = option.onTheSide;
                }
            }
            break;
        }
        case ActionTypes.RemoveCustomize: {
            if (option?.code) {
                customization.selectedOptions = selectedOptions.filter(
                    ({ code }) => code !== option.code
                );
                customization.accurateCalorie =
                    accurateCalorie - Number(option.accurateCalorie);
                customization.calories = calculateCalories(
                    customization.defaultCalories,
                    customization.selectedOptions
                );
                customization.price = calculatePrice(
                    customization.defaultPrice,
                    customization.selectedOptions
                );
            }
            break;
        }
        case ActionTypes.RemoveOnTheSideCustomize: {
            if (option?.code) {
                const selectedOption = customization.selectedOptions.find(
                    selectedOption => selectedOption.code === option.code
                );

                if (selectedOption) {
                    selectedOption.onTheSide = undefined;
                }
            }
            break;
        }
        case ActionTypes.ResetCustomize: {
            customization.selectedOptions.length = 0; // empty array
            customization.accurateCalorie = 0.0;
            customization.calories = 0;
            customization.defaultCalories = 0;
            customization.defaultPrice = 0;
            customization.price = 0;
            break;
        }
        case ActionTypes.SetStyleCustomize: {
            if (option?.code) {
                const selectedOption = customization.selectedOptions.find(
                    selectedOption => selectedOption.code === option.code
                );

                if (selectedOption) {
                    selectedOption.includedWithStyle = option.includedWithStyle;
                    customization.price = calculatePrice(
                        customization.defaultPrice,
                        customization.selectedOptions
                    );
                }
            }
            break;
        }
        default: {
            console.error('Unhandled type in customizeReducer', action.type);
        }
    }

    return { ...customization };
};

/**
 * Keeps track of the current user's customization options for a product
 * @example
 *      const [{ accurateCalorie, calories, price, selectedOptions }, setCustomize] = useCustomize();
 */
export const useCustomize = () =>
    useReducer(customizeReducer, {
        accurateCalorie: 0.0,
        calories: 0,
        defaultCalories: 0,
        defaultPrice: 0,
        price: 0,
        selectedOptions: []
    });
