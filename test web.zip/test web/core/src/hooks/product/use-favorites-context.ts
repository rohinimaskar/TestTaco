import { useContext } from 'react';

import { FavoritesContext } from '@tb-core/components/context/products/favorites';

const useFavoritesContext = () => {
    const ctx = useContext(FavoritesContext);

    if (ctx === undefined) {
        throw new Error(
            'useFavoritesContext must be used within a FavoritesProvider'
        );
    }

    return ctx;
};

export default useFavoritesContext;
