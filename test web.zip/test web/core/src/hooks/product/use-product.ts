import { useEffect, useState } from 'react';

import useStoreContext from '@tb-core/hooks/use-store-context';
import getProduct from '@tb-core/providers/get-product';
import { Product } from '@tb-core/types/products';
/**
 * Fetches product data based on a given product id.
 * @param productId the product id
 * @example
 *      const product = useProduct();
 */
export const useProduct: (productId: string) => Product = productId => {
    const [product, setProduct] = useState<Product>({} as Product);
    const { storeId } = useStoreContext();

    const fetchProduct = async () => {
        // clear the cache while waiting on the api call
        setProduct({} as Product);
        setProduct(await getProduct(productId, storeId));
    };

    useEffect(() => {
        if (productId) {
            fetchProduct();
        }
    }, [productId, storeId]);

    return product;
};
