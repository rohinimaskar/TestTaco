import { useContext } from 'react';

import { CartProductContext } from '@tb-core/components/context/cart-product';

const useCartProductContext = () => {
    const ctx = useContext(CartProductContext);

    if (ctx === undefined) {
        throw new Error(
            'useCartProductContext must be used within a CartProductProvider'
        );
    }

    return ctx;
};

export default useCartProductContext;
