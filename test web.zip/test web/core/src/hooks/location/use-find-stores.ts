import { useRef, useState } from 'react';

import { locationAdapter } from '@tb-core/adapters/store/location-adapter';
import findStores from '@tb-core/providers/find-stores';
import { GeoPoint } from '@tb-core/types/location';
import { StoreInfo } from '@tb-core/types/stores';

export interface StoresAndCoordinates {
    stores: StoreInfo[];
    coordinates: GeoPoint;
}

type GeoPointToStoreInfoArray = (
    coordinates?: GeoPoint
) => Promise<StoresAndCoordinates | undefined>;

type FindStoreHook = () => [GeoPointToStoreInfoArray, boolean, () => void];

export const geoPointToIndex = (latLng: GeoPoint) => {
    return (
        // lat: value is -80 to +80
        // lng: value is -180 to +180
        // using 100 because subsequent calls are not exactly the same like:
        // 33.84097567993644 vs 33.84089433325663
        //
        // example input: { lat: 33.7454725, lng: -117.867653 }
        // example math:          3370000
        //                         - 1178
        // example output:        3368822
        Math.floor(latLng.lat * 10) * 10000 + Math.floor(latLng.lng * 10)
    );
};

const useFindStores: FindStoreHook = () => {
    const [storeInfoError, setStoreInfoError] = useState(false);
    // cachedResults saves responses to prevent un-needed duplicate api calls
    const cachedResults = useRef<Record<number, StoresAndCoordinates>>([]);

    // Using 'priorSearches' as a reference - it will not trigger any useEffects
    // could have used useRef instead but the syntacs ( .current ) kinda weird.
    // Normally we don't modify useState variables directly: 'priorSearches'.
    const savePriorSearch = (point: GeoPoint, storesArray: StoreInfo[]) => {
        const index = geoPointToIndex(point);
        cachedResults.current[index] = {
            coordinates: point,
            stores: storesArray
        };
    };

    const checkForPriorSearch = (point: GeoPoint) => {
        const index = geoPointToIndex(point);
        return cachedResults.current[index];
    };

    const callFindStores = async (
        coordinates: GeoPoint
    ): Promise<StoresAndCoordinates | undefined> => {
        if (!coordinates) {
            return;
        }

        try {
            const { nearByStores } = await findStores({
                lat: coordinates.lat,
                long: coordinates.lng
            });
            const storeInfoArray: StoreInfo[] = nearByStores.map(
                locationAdapter
            );
            savePriorSearch(coordinates, storeInfoArray);

            return {
                coordinates,
                stores: storeInfoArray
            };
        } catch (e) {
            console.error(`Error communicating with find stores API, ${e}`);
            setStoreInfoError(true);
        }
    };
    const geoPointToStoreInfoArray: GeoPointToStoreInfoArray = async coordinates => {
        if (!coordinates) {
            return;
        }
        const foundStores = checkForPriorSearch(coordinates);

        if (foundStores) {
            return {
                ...foundStores
            };
        } else {
            const stores = await callFindStores(coordinates);
            return stores;
        }
    };

    const clearError = () => {
        setStoreInfoError(false);
    };

    return [geoPointToStoreInfoArray, storeInfoError, clearError];
};

export default useFindStores;
