import { useEffect, useState } from 'react';

import getLambdaSessionToken from '@tb-core/helpers/get-lambda-session-token';
import postPlaces from '@tb-core/providers/post-places';
import { LatLong } from '@tb-core/types/location';

const usePostPlaces: () => [
    LatLong | undefined,
    boolean,
    (store: string) => void
] = () => {
    const [selectedStore, setStore] = useState('');
    const [coordinates, setCoordinates] = useState<LatLong | undefined>();
    const [error, setError] = useState(false);
    const callPostPlaces = async () => {
        postPlaces({
            place_id: selectedStore,
            sessiontoken: getLambdaSessionToken()
        })
            .then(({ geometry }) => {
                if (!geometry || !geometry.location) {
                    setError(true);
                } else {
                    setCoordinates({
                        lat: geometry.location.lat,
                        long: geometry.location.lng
                    });
                }
            })
            .catch(() => {
                setError(true);
            });
    };

    useEffect(() => {
        setError(false);
        setCoordinates(undefined);

        if (selectedStore) {
            callPostPlaces();
        }
    }, [selectedStore]);

    return [coordinates, error, setStore];
};

export default usePostPlaces;
