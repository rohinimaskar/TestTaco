import { useEffect, useState } from 'react';

import getLambdaSessionToken from '@tb-core/helpers/get-lambda-session-token';
import postGeocode from '@tb-core/providers/post-geocode';

/**
 * Returns the first store's placeId returned by postGeoCode API on a provided query,
 * as well as an API to interact with it.
 * @example
 *      const [store, error, setQuery, setStore] = useGeocode();
 */
const useGeocode: () => [
    string,
    boolean,
    (query: string) => void,
    (placeId: string) => void
] = () => {
    const [query, setQuery] = useState('');
    const [store, setStore] = useState('');
    const [error, setError] = useState(false);

    const callPostGeocode = async () =>
        postGeocode({ query, sessiontoken: getLambdaSessionToken() })
            .then(stores => {
                if (!stores || stores.length === 0) {
                    setError(true);
                }
                setStore(stores[0].place_id);
            })
            .catch(() => {
                setError(true);
            });

    useEffect(() => {
        setStore('');
        setError(false);

        if (query) {
            callPostGeocode();
        }
    }, [query]);

    return [store, error, setQuery, setStore];
};

export default useGeocode;
