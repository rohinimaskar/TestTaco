import { useEffect, useRef, useState } from 'react';

import { updateDataLayer } from '@tb-core/helpers/analytics/google';
import useLocationApi from '@tb-core/hooks/location/use-location-api';
import { useGeoLocation } from '@tb-core/hooks/use-geolocation';
import usePageContext from '@tb-core/hooks/use-page-context';
import { GeoPoint } from '@tb-core/types/location';
import { StoreInfo } from '@tb-core/types/stores';

import useFindStores, {
    StoresAndCoordinates
} from '@tb-core/hooks/location/use-find-stores';

type SubmitLocationHook = (
    setMapCenter: (LatLng: GeoPoint) => void
) => {
    isUnableToGeoLocate: boolean;
    storesByMapCenter: (coordinates: GeoPoint) => void;
    storesByDeviceLocation: () => void;
    storesBySearchString: (input: string) => void;
    storeResultState: StoreResult;
    stores: StoreInfo[];
};

export enum StoreResult {
    displayError = 'error',
    displayGeoError = 'geoError',
    displayLoading = 'loading',
    displayNothing = 'nothing',
    displayStores = 'stores',
    displayStoresEmpty = 'noStores'
}

const useSubmitLocation: SubmitLocationHook = setMapCenter => {
    const { seoTitle } = usePageContext().content.pageData || {};
    const [stores, setStores] = useState<StoreInfo[]>([]);
    const [storeResultState, setStoreResultState] = useState<StoreResult>(
        StoreResult.displayNothing
    );
    const [isUnableToGeoLocate, setIsUnableToGeoLocate] = useState(false);
    const priorError = useRef(false);
    const equals = (a: StoreInfo[], b: StoreInfo[]) =>
        a.length === b.length && a.every((s, i) => s.storeId === b[i].storeId);

    const showStores = (storeList: StoreInfo[]) => {
        const newState =
            storeList.length > 0
                ? StoreResult.displayStores
                : StoreResult.displayStoresEmpty;
        if (!priorError.current && equals(stores, storeList)) {
            // if no change in storeList:
            //  Give placebo 0.444 sec loading effect!
            //  ...otherwise looks like nothing happened!
            //  But don't do this if currently showing error message
            setTimeout(() => {
                setStoreResultState(newState);
            }, 444);
        } else {
            setStoreResultState(newState);
        }
        priorError.current = false;
    };

    // Flow: User Enters Search Input:
    // userInputToGeoPoint() --> geoPointToStoreInfoArray() --> saveStoreInfoArray()

    // Flow: When User Clicks 'Use My Current Location':
    // geolocationToGeoPoint() --> geoPointToStoreInfoArray() --> saveStoreInfoArray()

    // Flow: When User Clicks 'Redo search in Map'
    // geoPointToStoreInfoArray() -> saveStoreInfoArray()

    const saveStoreInfoArray = (storeInfo?: StoresAndCoordinates) => {
        if (!storeInfo) {
            return;
        }
        const { coordinates, stores } = storeInfo;

        setMapCenter(coordinates);
        setStores(stores);
        showStores(stores);
    };

    const [
        userInputToGeoPoint,
        locationApiError,
        clearLocationError
    ] = useLocationApi();

    const [
        geoPointToStoreInfoArray,
        storeInfoError,
        clearErrorStoreInfo
    ] = useFindStores();

    const [
        geolocationToGeoPoint,
        geoLocateError,
        clearErrorGeolocate
    ] = useGeoLocation();

    const clearErrorsAndShowLoading = () => {
        setStoreResultState(StoreResult.displayLoading);
        clearLocationError();
        clearErrorStoreInfo();
        clearErrorGeolocate();
    };

    // All Error Logic in this UseEffect
    // Need to clear out errors beforehand, otherwise useEffect won't fire if same error
    useEffect(() => {
        if (!geoLocateError && !locationApiError && !storeInfoError) {
            // No Error: do nothing
            return;
        }
        // Error: Display Error
        setStoreResultState(
            geoLocateError?.code === 1
                ? StoreResult.displayGeoError
                : storeInfoError
                ? StoreResult.displayStoresEmpty
                : StoreResult.displayError
        );
        priorError.current = true;
        // error code 1 represents geolocation services being turned off
        if (geoLocateError?.code === 1) {
            updateDataLayer({
                'Analytics-Action': 'Error',
                'Analytics-Value': seoTitle
            });
            setIsUnableToGeoLocate(true);
        } else if (locationApiError || storeInfoError) {
            updateDataLayer({
                'Analytics-Action': 'Store Locator>Error Message',
                'Analytics-Value': 'Store not found'
            });
        }
    }, [geoLocateError, locationApiError, storeInfoError]);

    return {
        isUnableToGeoLocate,
        storeResultState,
        stores,
        storesByDeviceLocation: () => {
            clearErrorsAndShowLoading();
            geolocationToGeoPoint()
                .then(geoPointToStoreInfoArray)
                .then(saveStoreInfoArray);
        },
        storesByMapCenter: coordinates => {
            clearErrorsAndShowLoading();
            geoPointToStoreInfoArray(coordinates).then(saveStoreInfoArray);
        },
        // When storesBySearchString() triggers the following 3 api calls:
        // 1. callPostGeocode(geoCodeUrl) -called inside useGeocode() -calls postGeocode()
        // 2. callPostPlaces(placeDetailsUrl) -called inside usePostPlaces() -calls postPlaces()
        // 3. callFindStores(storesLookupUrl) -called inside useFindStores() -calls findStores() which updates 'stores'
        // if all those are successful 'stores' will be updated to an array of stores
        storesBySearchString: input => {
            clearErrorsAndShowLoading();
            userInputToGeoPoint(input)
                .then(geoPointToStoreInfoArray)
                .then(saveStoreInfoArray);
        }
    };
};

export default useSubmitLocation;
