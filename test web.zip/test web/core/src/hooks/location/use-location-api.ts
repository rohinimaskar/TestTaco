import { datadogLogs } from '@datadog/browser-logs';
import { useRef, useState } from 'react';

import { devProxy } from '@tb-core/helpers/browser/dev-proxy';
import Fetch from '@tb-core/helpers/fetch';
import { interpolate } from '@tb-core/helpers/interpolate';
import { serverlessApiUrl } from '@tb-core/helpers/next-env';
import { locationGeopointApi } from '@tb-core/next/api/urls';
import { GeoPoint } from '@tb-core/types/location';

/**
 * Returns the first store's placeId returned by postGeoCode API on a provided query,
 * as well as an API to interact with it.
 * @example
 *      const [store, error, setQuery, setStore] = useGeocode();
 */

export enum LocationStateError {
    CLEAR = 0,
    CALL_FAILED = 1,
    STRING_INDECIPHERABLE = 2
}

interface LocationV1Response {
    geometry?: GeoPoint;
    success: boolean;
}

type UseLocationApi = () => [
    (query: string) => Promise<GeoPoint | undefined>,
    LocationStateError,
    () => void
];

/**
 * useLocationApi
 * handle  calls to the Microsvive endpoint `/location/v1/<query>`
 */
const useLocationApi: UseLocationApi = () => {
    const [error, setError] = useState(LocationStateError.CLEAR);
    // cachedResults saved response to prevent un-needed duplicate api calls
    const cachedResults = useRef<Record<string, GeoPoint>>({});

    const getLocation = async (query: string): Promise<LocationV1Response> => {
        let res: Response;

        try {
            res = await Fetch({
                headers: {
                    'Content-Type': 'application/json'
                },
                method: 'GET',
                ...devProxy({
                    host: serverlessApiUrl,
                    url: interpolate(locationGeopointApi, { query })
                })
            });
        } catch (e) {
            console.error('Locations request failed!', e);
            setError(LocationStateError.CALL_FAILED);
            datadogLogs.logger.log('getMenu', { e }, 'error');
            return { success: false };
        }

        if (!res.ok) {
            setError(LocationStateError.CALL_FAILED);
            return { success: false };
        }
        const data: LocationV1Response = await res.json();
        if (data.geometry) {
            cachedResults.current[query] = data.geometry;
        }
        return data;
    };

    /** query location Api with user input */
    const userInputToGeoPoint = async (inputString: string) => {
        const query = inputString.toLowerCase();
        const cachedGeometry = cachedResults.current[query];
        if (cachedGeometry) {
            return cachedGeometry;
        } else {
            const { geometry } = await getLocation(query);
            return geometry;
        }
    };

    const clearError = () => {
        setError(LocationStateError.CLEAR);
    };

    return [userInputToGeoPoint, error, clearError];
};

export default useLocationApi;
