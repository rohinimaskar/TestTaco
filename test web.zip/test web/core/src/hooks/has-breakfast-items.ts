import { useEffect, useState } from 'react';

import { addAllProductCodes } from '@tb-core/helpers/product';
import { useCartSummary } from '@tb-core/hooks/client-side-cart/use-cart-summary';
import { useClientSideCartContext } from '@tb-core/hooks/client-side-cart/use-client-side-cart-context';
import useMenuContext from '@tb-core/hooks/use-menu-context';
import { MenuProductCategory, Product } from '@tb-core/types/products';

export const hasBreakfastItems = () => {
    const { local } = useClientSideCartContext();
    const { products } = useCartSummary(local.cart, local.isCartInitialized);
    const { menuProductCategories } = useMenuContext();
    const [breakfastProducts, setBreakfastProducts] = useState<Product[]>();
    const [hasBreakfast, setHasBreakfast] = useState(false);

    useEffect(() => {
        if (menuProductCategories?.length) {
            setBreakfastProducts(getBreakfastProducts(menuProductCategories));
        }
    }, [menuProductCategories]);

    useEffect(() => {
        if (breakfastProducts?.length && products?.length) {
            const productCodes = addAllProductCodes(products);

            setHasBreakfast(
                checkProductsForBreakfastItems(productCodes, breakfastProducts)
            );
        }
    }, [breakfastProducts, products]);

    return {
        hasBreakfast
    };
};

const getBreakfastProducts = (menuProductCategories: MenuProductCategory[]) =>
    menuProductCategories.flatMap(
        ({ products }) =>
            products?.filter(({ dayPartMessages }) =>
                dayPartMessages?.some(
                    dayPartMessages =>
                        dayPartMessages.dayPartCode === 'Breakfast'
                )
            ) || []
    );

const checkProductsForBreakfastItems = (
    productCodes: string[],
    productList: Product[]
) => productList.some(product => productCodes.includes(product.code));
