import { useEffect, useState } from 'react';

import { getOrderCodeFromGuid } from '@tb-core/helpers/order/get-order-code-from-guid';
import { getProgress } from '@tb-core/helpers/order/get-progress';
import { useGetCurrentOrderStatus } from '@tb-core/hooks/order/use-get-current-order-status';
import useGetUserOrders from '@tb-core/hooks/order/use-get-user-orders';
import useUserContext from '@tb-core/hooks/use-user-context';
import getGuestOrderByGuid from '@tb-core/providers/order/get-guest-order-by-guid';
import getOrderByCode from '@tb-core/providers/order/get-order-by-code';
import { RealObject } from '@tb-core/types';
import {
    DeliveryStatuses,
    DeliveryStatusText,
    Order,
    PickUpMethods,
    Statuses,
    StatusText,
    SubStatusTextProps
} from '@tb-core/types/order';

type UseGetOrderTrackerDetailsType = (
    guid: string,
    deliveryStatusText: DeliveryStatusText,
    deliverySubStatusText: DeliveryStatusText,
    orderStatusText: StatusText,
    orderSubStatusText: SubStatusTextProps
) => {
    order?: Order;
    orderStatus?: string;
    orderSubStatus?: string;
    progress: string;
};

export const useGetOrderTrackerDetails: UseGetOrderTrackerDetailsType = (
    guid,
    deliveryStatusText,
    deliverySubStatusText,
    orderStatusText,
    orderSubStatusText
) => {
    const [order, setOrder] = useState<Order>();
    const [orderCode, setOrderCode] = useState('');
    const { loadOrders, orders } = useGetUserOrders();
    const { isLoggedIn } = useUserContext();
    // Get the order data from the get order details by id endpoint
    const getOrderDetail = async (code?: string) => {
        const setOrderIfSuccess = (result: RealObject) => {
            if (result && !result.errors && result.success !== false) {
                setOrder(result as Order);
            }
        };

        if (isLoggedIn && code) {
            setOrderIfSuccess(await getOrderByCode(code));
        } else if (isLoggedIn === false) {
            setOrderIfSuccess(await getGuestOrderByGuid(guid));
        }
    };

    useEffect(() => {
        if (isLoggedIn) {
            loadOrders();
        }
    }, [isLoggedIn]);

    const progress = getProgress(order?.status, order?.deliveryStatus);
    const {
        orderStatus,
        orderSubStatus,
        updateStatuses
    } = useGetCurrentOrderStatus({
        deliveryStatusText,
        deliverySubStatusText,
        orderStatusText,
        orderSubStatusText
    });

    useEffect(() => {
        // Pull the code for the order matching the guid and set the orderCode state
        if (orders?.length) {
            setOrderCode(getOrderCodeFromGuid(guid, orders));
        }
    }, [orders]);

    useEffect(() => {
        if (!order) {
            // Once orderCode is defined use it to pull the order data
            if (orderCode) {
                getOrderDetail(orderCode);
            } else if (isLoggedIn === false && !order) {
                getOrderDetail();
            }
        }
    }, [isLoggedIn, orderCode]);

    useEffect(() => {
        if (order) {
            updateStatuses({
                deliveryStatus: order.deliveryStatus as DeliveryStatuses,
                pendingCancellation: order.pendingCancellation,
                pickupMethod: order.pickupMethod as PickUpMethods,
                qrCodeEnabled: !!order.qrCode,
                status: order.status as Statuses
            });

            // Pull the order data every 60 seconds
            const id = setInterval(() => {
                if (orderCode) {
                    getOrderDetail(orderCode);
                } else {
                    getOrderDetail();
                }
            }, 60000);

            return () => {
                clearInterval(id);
            };
        }
    }, [order]);

    return {
        order,
        orderStatus,
        orderSubStatus,
        progress
    };
};
