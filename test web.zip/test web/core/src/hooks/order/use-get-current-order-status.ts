import { useState } from 'react';

import { getOrderStatusText } from '@tb-core/helpers/order/get-order-status-text';
import { getOrderSubStatus } from '@tb-core/helpers/order/get-order-sub-status-text';
import {
    DeliveryStatuses,
    DeliveryStatusText,
    PickUpMethods,
    Statuses,
    StatusText,
    SubStatusTextProps
} from '@tb-core/types/order.d';

export interface OrderDetails {
    deliveryStatus?: DeliveryStatuses;
    pendingCancellation: boolean;
    pickupMethod: PickUpMethods;
    qrCodeEnabled: boolean;
    status: Statuses;
}

export interface UseGetCurrentOrderStatusProps {
    deliveryStatusText: DeliveryStatusText;
    deliverySubStatusText: DeliveryStatusText;
    orderStatusText: StatusText;
    orderSubStatusText: SubStatusTextProps;
}

export const useGetCurrentOrderStatus = ({
    deliverySubStatusText,
    orderSubStatusText,
    ...props
}: UseGetCurrentOrderStatusProps) => {
    const [orderStatus, setOrderStatus] = useState<string>();
    const [orderSubStatus, setOrderSubStatus] = useState<string>();

    const updateStatuses = ({
        deliveryStatus,
        pickupMethod,
        qrCodeEnabled,
        ...updateStatusProps
    }: OrderDetails) => {
        setOrderStatus(
            getOrderStatusText({
                ...props,
                ...updateStatusProps,
                deliveryStatus
            })
        );
        setOrderSubStatus(
            getOrderSubStatus({
                ...props,
                ...updateStatusProps,
                deliverySubStatusText,
                orderSubStatusText,
                pickupMethod,
                qrCodeEnabled
            })
        );
    };

    return {
        orderStatus,
        orderSubStatus,
        updateStatuses
    };
};
