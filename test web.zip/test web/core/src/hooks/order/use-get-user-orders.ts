import { useEffect, useState } from 'react';

import { isCompleteOrCancelled } from '@tb-core/helpers/order/is-complete-or-cancelled';
import getUserOrders from '@tb-core/providers/order/get-user-orders';
import { Order } from '@tb-core/types/order.d';

/**
 * Uses the getUserOrders provider to get user orders.
 * @param pageSize number of items to be returned by each call to the orders endpoint. Optional as
 * endpoint will return 20 by default.
 * @return loadMoreOrders - function to pull the next page of orders and concatanate with current orders state.
 *         orders - array of order objects
 */
const useGetUserOrders = (pageSize?: string) => {
    const [orders, setOrders] = useState<Order[]>([] as Order[]);
    const [openOrders, setOpenOrders] = useState<Order[]>([]);
    const [closedOrders, setClosedOrders] = useState<Order[]>([]);

    const [currentPage, setCurrentPage] = useState(0);
    const [totalPages, setTotalPages] = useState(0);

    const isExistingOrder = (ordersToCheck: Order[], guid: string) =>
        ordersToCheck.some(order => order.guid === guid);

    useEffect(() => {
        if (orders) {
            const openOrderHolder = [...openOrders];
            const closedOrderHolder = [...closedOrders];

            orders.forEach(order => {
                // Use closedOrderHolder array if the order is complete or cancelled
                const ordersToCompare = isCompleteOrCancelled(order.status)
                    ? closedOrderHolder
                    : openOrderHolder;

                // Check that the order is not already in the array
                if (!isExistingOrder(ordersToCompare, order.guid)) {
                    ordersToCompare.push(order);
                }
            });
            // Upddate the order array states
            if (openOrderHolder.length > openOrders.length) {
                setOpenOrders(openOrderHolder);
            }

            if (closedOrderHolder.length > closedOrders.length) {
                setClosedOrders(closedOrderHolder);
            }
        }
    }, [orders]);

    const loadOrders = async () => {
        if (totalPages && currentPage >= totalPages) {
            return;
        }
        const { orders: orderList, pagination } = await getOrders(currentPage);

        if (!orderList || !pagination) {
            return;
        }

        setOrders(orderList);
        setTotalPages(pagination.totalPages);

        const nextPage = currentPage + 1;

        setCurrentPage(nextPage);
    };

    const getOrders = async (page: number) =>
        await getUserOrders({
            currentPage: String(page),
            pageSize
        });

    return {
        closedOrders,
        currentPage,
        loadOrders,
        openOrders,
        orders,
        totalPages
    };
};

export default useGetUserOrders;
