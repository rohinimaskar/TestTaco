import { useEffect, useState } from 'react';

import getOrderByCode from '@tb-core/providers/order/get-order-by-code';
import { Order } from '@tb-core/types/order';

export const useGetOrderSummary = (code: string) => {
    const [order, setOrder] = useState<Order>();

    const getOrder = async () => {
        setOrder(await getOrderByCode(code));
    };
    useEffect(() => {
        getOrder();
    }, [code]);

    return {
        order
    };
};
