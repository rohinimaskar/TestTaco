import {
    TokenizeApplePayOptions,
    YCCommercePaymentsAdmin
} from '@yc-commerce/payments-frontend-sdk';
import { useRef } from 'react';

import { applePayMerchantId } from '@tb-core/helpers/next-env';

export interface ApplePaySessionConfigParameters {
    platform: string;
    userAgent: string;
    vendor: string;
}

export const useYumApplePay = (
    getYumSDK: (
        applePayConfig?: ApplePaySessionConfigParameters
    ) => Promise<YCCommercePaymentsAdmin | undefined>
) => {
    const isLoadedApplePaySDK = useRef(false);
    const applePaySessionConfig = {
        platform: 'MAC',
        userAgent: 'SAFARI',
        vendor: 'APPLE'
    };

    // token has type any due to type of paymentData object in ApplePayPaymentToken interface
    const tokenizeApplePay = async (token: any) => {
        const sdk = await getYumSDK(applePaySessionConfig);
        if (sdk) {
            // Need to submit token properties in snake case to the Yum tokenize function, not camel case
            // https://developer.apple.com/documentation/passkit/apple_pay/payment_token_format_reference
            const adaptedToken: TokenizeApplePayOptions = {
                application_data: token.header.applicationData,
                data: token.data,
                decrypt_alias: applePayMerchantId,
                header: {
                    ephemeral_public_key: token.header.ephemeralPublicKey,
                    public_key_hash: token.header.publicKeyHash,
                    transaction_id: token.header.transactionId
                },
                signature: token.signature,
                version: token.version
            };
            return sdk.tokenizeApplePay(adaptedToken);
        }
    };

    const getApplePaySession = async () => {
        const sdk = await getYumSDK(applePaySessionConfig);
        if (sdk) {
            return sdk.getApplePayMerchantSession();
        }
    };

    const loadApplePaySDKIfNotAlreadyLoaded = () => {
        if (isLoadedApplePaySDK.current) {
            return;
        }
        isLoadedApplePaySDK.current = true;
        const loadScript = (
            FILE_URL: string,
            async = true,
            type = 'text/javascript'
        ) => {
            return new Promise((resolve, reject) => {
                try {
                    const scriptEle = document.createElement('script');
                    scriptEle.type = type;
                    scriptEle.async = async;
                    scriptEle.src = FILE_URL;

                    scriptEle.addEventListener('load', () => {
                        resolve({ status: true });
                    });

                    scriptEle.addEventListener('error', () => {
                        reject({
                            message: 'Failed to load apple pay SDK',
                            status: false
                        });
                    });

                    document.body.appendChild(scriptEle);
                } catch (error) {
                    console.error('catching error', error);
                    reject(error);
                }
            });
        };
        loadScript(
            'https://applepay.cdn-apple.com/jsapi/v1/apple-pay-sdk.js'
        ).catch(err => {
            console.error(err);
            isLoadedApplePaySDK.current = false;
        });
    };

    return {
        getApplePaySession,
        loadApplePaySDKIfNotAlreadyLoaded,
        tokenizeApplePay
    };
};
