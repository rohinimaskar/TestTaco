import { Router } from 'next/router';
import { useEffect } from 'react';

/**
 * Custom hook to handle modifying the 'next/data' call on route click.
 * Because of the nature of our microsites residing on individual servers,
 * the 'next/data' calls fail to prepend the site basePath, resulting in a 404 return.
 *
 * See https://github.com/vercel/next.js/discussions/25681 for a discussion
 * involving NextJS adding a possible future dataPathPrefix param to their config options
 * that would eliminate the need for this.
 *
 * @param {Router} router - The Next router required to check the selected route.
 * @param {string} basePath - The current site's server basePath.
 */

// Type as defined in
// node_modules/next/dist/client/page-loader.d.ts
interface GetDatHrefProps {
    asPath: string;
    href: string;
    locale?: string | false;
    skipInterpolation?: boolean;
}
export const useInterceptNextDataHref = ({
    router,
    basePath
}: {
    router: Router;
    basePath: string;
}) => {
    useEffect(() => {
        if (router.pageLoader?.getDataHref) {
            const originalGetDataHref = router.pageLoader.getDataHref;
            router.pageLoader.getDataHref = (args: GetDatHrefProps) => {
                const route = originalGetDataHref.call(router.pageLoader, args);
                return route && route.startsWith('/_next/data')
                    ? `${basePath}${route}`
                    : route;
            };
        }
    }, [router, basePath]);
};
