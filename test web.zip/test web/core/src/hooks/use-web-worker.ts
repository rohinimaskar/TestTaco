import { useEffect, useRef } from 'react';

export type WebWorker = new () => Worker;
export type WebWorkerSuccessHandler<T> = (ev: MessageEvent<T>) => any;
export type WebWorkerHandler<T> = (ev: MessageEvent<T>) => any;
export type WorkerName = keyof typeof workers;

export const workers = {
    cart: () =>
        new Worker(new URL('@tb-core/workers/cart.worker.js', import.meta.url)),
    cartValidation: () =>
        new Worker(
            new URL(
                '@tb-core/workers/cart-validation.worker.js',
                import.meta.url
            )
        ),
    indexeddb: () =>
        new Worker(
            new URL('@tb-core/workers/indexeddb.worker.js', import.meta.url)
        )
};

export const useWebWorker = <T>(
    name: WorkerName,
    onMessageSuccess?: WebWorkerHandler<T>,
    onMesageError?: WebWorkerHandler<T>
) => {
    const workerRef = useRef<Worker>();

    useEffect(() => {
        workerRef.current = workers[name]();

        if (onMessageSuccess) {
            workerRef.current.onmessage = onMessageSuccess;
        }

        workerRef.current.onmessageerror = onMesageError || console.error;

        workerRef.current.onerror = e =>
            console.error('Worker error occured', e);

        return () => workerRef.current?.terminate();
    }, [name]);

    return workerRef.current;
};
