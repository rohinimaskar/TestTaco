import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';

export const useCurrentPageMetadata = () => {
    const [currentPageMetadata, setCurrentPageMetadata] = useState({
        page_path: '',
        page_title: ''
    });

    const { basePath, pathname } = useRouter();

    useEffect(() => {
        setCurrentPageMetadata({
            page_path: basePath !== '' ? basePath : pathname,
            page_title: document.title
        });
    }, [basePath]);

    return { currentPageMetadata };
};
