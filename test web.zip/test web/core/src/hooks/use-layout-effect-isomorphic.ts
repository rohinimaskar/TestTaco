import { useEffect, useLayoutEffect } from 'react';

const useLayoutEffectIsomorphic =
    typeof window !== 'undefined' ? useLayoutEffect : useEffect;

export default useLayoutEffectIsomorphic;
