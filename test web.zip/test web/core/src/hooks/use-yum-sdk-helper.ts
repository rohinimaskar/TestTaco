import { datadogLogs } from '@datadog/browser-logs';
import {
    PaymentMethod,
    TokenizeApplePayOptions,
    YCCommercePaymentsAdmin
} from '@yc-commerce/payments-frontend-sdk';
import { useRef, useState } from 'react';

import {
    getYumPaymentSessionConfigObject,
    YumPaymentSessionConfigPayload
} from '@tb-core/helpers/get-yum-payment-session-config-object';
import { GetAndSetDeviceId } from '@tb-core/helpers/storage';
import {
    ApplePaySessionConfigParameters,
    useYumApplePay
} from '@tb-core/hooks/use-yum-apple-pay';
import {
    addGiftCardGuestUser,
    addGiftCardLoggedInUser,
    postAddGiftCardToUserAccount
} from '@tb-core/providers/post-add-gift-card';
import { FetchResponse, RealObject } from '@tb-core/types';
import { CartResponse } from '@tb-core/types/checkout/checkout-cart';
import {
    AddGiftCardGuestUserProps,
    AddGiftCardLoggedInUserProps,
    AddGiftCardToUserAccountProps,
    GiftCardInfoResponse
} from '@tb-core/types/checkout/credit-and-gift-cards';
import {
    YumPaymentLocaleCode,
    YumPaymentMethodType
} from '@tb-core/types/checkout/yum-payment.d';

interface YumSDKHelperProps {
    customerId?: string;
    guestAccessToken: string;
    isLoggedIn?: boolean;
    onCreditCardError: (err: RealObject) => void;
    onCreditCardSuccess: (paymentMethod: PaymentMethod) => void;
    onYumSDKTimeout: () => void;
    pageType?: 'GUEST_CHECKOUT' | 'USER_CHECKOUT' | 'USER_SAVE_NEW_CARD';
    paymentMethods: YumPaymentMethodType[];
}

export interface YumSDKHelperType {
    addGiftCardForGuestUser: (
        props: AddGiftCardGuestUserProps
    ) => Promise<CartResponse | GiftCardInfoResponse>;
    addGiftCardForLoggedInUser: (
        props: AddGiftCardLoggedInUserProps
    ) => Promise<CartResponse | GiftCardInfoResponse>;
    addGiftCardToUserAccount: (
        props: AddGiftCardToUserAccountProps
    ) => FetchResponse<GiftCardInfoResponse>;
    getApplePaySession: () => Promise<
        TokenizeApplePayOptions | undefined | unknown
    >;
    loadApplePaySDKIfNotAlreadyLoaded: () => void;
    tokenizeApplePay: (
        token: TokenizeApplePayOptions
    ) => Promise<string | undefined>;
    tokenizeGooglePay: (
        paymentData: google.payments.api.PaymentData
    ) => Promise<string | undefined>;
    populateIframeIfNotAlreadyPopulated: (
        iframeDiv: HTMLDivElement
    ) => Promise<boolean>;
    preInitSDK: () => void;
}
/**
 * Mitch's Words:
 * you do not need a second session config for Google Pay, and as
 * additional info, the limiting factor in session configs is bank cards
 * entered into the iframe. One a card is entered, that burns an encryption
 * token that must be regenerated with a new config. As long as a bank card
 * has not been submitted in that iframe, you may re-use the same session.
 */
export const useYumSDKHelper = ({
    customerId,
    guestAccessToken,
    isLoggedIn,
    onCreditCardError,
    onCreditCardSuccess,
    onYumSDKTimeout,
    pageType,
    paymentMethods
}: YumSDKHelperProps): YumSDKHelperType => {
    const [yumSDK, setYumSDK] = useState<YCCommercePaymentsAdmin>();
    const isConfigLoading = useRef(false);
    const isYumSDKLoading = useRef(false);
    const [timeoutId, setTimeoutId] = useState<ReturnType<typeof setTimeout>>();

    /**
     * 1 calls session-config to get yum token \
     * 2 uses yum token to init Yum payment sdk
     */
    const initYumSDK = async ({
        guestAccessToken,
        payload
    }: {
        guestAccessToken: string;
        payload: YumPaymentSessionConfigPayload;
    }) => {
        const result = await getYumPaymentSessionConfigObject(
            payload,
            guestAccessToken
        );
        const config = result?.message?.createCustomerPaymentSession;
        if (config?.session?.sessionId && config.sessionConfig) {
            const sdk = new YCCommercePaymentsAdmin({
                debug: false,
                session_config: config.sessionConfig,
                session_id: config.session.sessionId
            });
            return sdk;
        } else {
            datadogLogs.logger.log('yumSDKConfigCallFail', result, 'error');
        }
        return undefined;
    };

    const getYumSDK = async (
        applePayConfig?: ApplePaySessionConfigParameters
    ) => {
        let sdk: YCCommercePaymentsAdmin | undefined;
        const callInitSDK = async (customerId: string) => {
            const payload = {
                customerId,
                deviceId: GetAndSetDeviceId(),
                isGuest: !isLoggedIn,
                language: YumPaymentLocaleCode.EN,
                paymentMethods,
                ...applePayConfig
            };
            const initializedSDK = await initYumSDK({
                guestAccessToken,
                payload
            });
            if (initializedSDK) {
                setTimeoutId(
                    setTimeout(sdkExpired, 1200000) // 20 min = 1,200,000 ms
                );
            }
            setYumSDK(initializedSDK);
            return initializedSDK;
        };
        if (yumSDK && !applePayConfig) {
            sdk = yumSDK;
        } else if (customerId) {
            sdk = await callInitSDK(customerId);
        }

        return sdk;
    };

    const {
        getApplePaySession,
        loadApplePaySDKIfNotAlreadyLoaded,
        tokenizeApplePay
    } = useYumApplePay(getYumSDK);

    const invalidateYumSDK = () => {
        if (timeoutId) {
            clearTimeout(timeoutId);
        }
        setYumSDK(undefined);
    };
    const onError = (err: RealObject) => {
        datadogLogs.logger.log(
            'Yum Payment SDK Card Capture Error',
            err,
            'error'
        );
        invalidateYumSDK();
        onCreditCardError(err);
    };
    const onSuccess = (paymentMethod: PaymentMethod) => {
        invalidateYumSDK();
        onCreditCardSuccess(paymentMethod);
    };
    const sdkExpired = () => {
        invalidateYumSDK();
        onYumSDKTimeout();
    };
    /**
     * Note: on Checkout Page: \
     * This does not show the iframe, just verifies it is in the DOM \
     * The iframe container div is shown based on: \
     * [styles.hidden]: selectedOption.paymentType !== PaymentTypes.AddCard
     */
    const populateIframeIfNotAlreadyPopulated = async (
        iframeDiv: HTMLDivElement
    ) => {
        let isPopulated = false;
        if (customerId && !iframeDiv.innerHTML && !isConfigLoading.current) {
            if (timeoutId) {
                clearTimeout(timeoutId);
            }

            isConfigLoading.current = true;
            const sdk = await getYumSDK();
            if (sdk) {
                await sdk.captureCard({
                    html_element_id: iframeDiv.id,
                    onError,
                    onSuccess,
                    page_type: pageType
                });
                isPopulated = true;
            }
            isConfigLoading.current = false;
        }
        return isPopulated;
    };

    const tokenizeGooglePay = async (
        paymentData: google.payments.api.PaymentData
    ) => {
        const sdk = await getYumSDK();
        if (sdk) {
            const rawTokenString =
                paymentData.paymentMethodData.tokenizationData.token;
            const { protocolVersion, signature, signedMessage } = JSON.parse(
                rawTokenString
            );
            const paymentToken = sdk.tokenizeGooglePay({
                signature,
                signed_message: signedMessage,
                version: protocolVersion
            });

            return paymentToken;
        }
    };

    /**
     * preInitSDK is not needed to be called prior to other calls
     * it just speeds things up slightly by calling session-config now
     * rather than waiting to call it later
     */
    const preInitSDK = async () => {
        if (!isYumSDKLoading.current && !isConfigLoading.current) {
            isYumSDKLoading.current = true;
            await getYumSDK();
            isYumSDKLoading.current = false;
        }
    };

    const tokenizeGiftCard = async (giftCardNumber: string, pin: string) => {
        const sdk = await getYumSDK();
        return (
            sdk?.tokenizeGiftCard({
                card_number: giftCardNumber,
                security_code: pin
            }) || ''
        );
    };

    const addGiftCardForGuestUser = async ({
        giftCardNumber,
        pin,
        ...props
    }: AddGiftCardGuestUserProps) => {
        const yumGiftCardToken = await tokenizeGiftCard(giftCardNumber, pin);
        return await addGiftCardGuestUser({
            ...props,
            yumGiftCardToken
        });
    };

    const addGiftCardForLoggedInUser = async ({
        cartCode,
        giftCardNumber,
        pin
    }: AddGiftCardLoggedInUserProps) => {
        const yumGiftCardToken = await tokenizeGiftCard(giftCardNumber, pin);
        return await addGiftCardLoggedInUser({
            cartCode,
            yumGiftCardToken
        });
    };

    const addGiftCardToUserAccount = async ({
        customerId,
        giftCardNumber,
        pin
    }: AddGiftCardToUserAccountProps) => {
        const yumGiftCardToken = await tokenizeGiftCard(giftCardNumber, pin);
        return await postAddGiftCardToUserAccount({
            customerId,
            yumGiftCardToken
        });
    };

    return {
        addGiftCardForGuestUser,
        addGiftCardForLoggedInUser,
        addGiftCardToUserAccount,
        getApplePaySession,
        loadApplePaySDKIfNotAlreadyLoaded,
        populateIframeIfNotAlreadyPopulated,
        preInitSDK,
        tokenizeApplePay,
        tokenizeGooglePay
    };
};
