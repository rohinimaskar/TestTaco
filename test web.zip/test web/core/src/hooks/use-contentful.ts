import { useEffect, useState } from 'react';

import Fetch from '@tb-core/helpers/fetch';
import { contentfulSpace } from '@tb-core/helpers/next-env';

const useContentful = (query: any, isPreview: boolean) => {
    const [data, setData] = useState(null);
    const [errors, setErrors] = useState<any>(null);

    useEffect(() => {
        Fetch({
            body: JSON.stringify({ query, variables: { isPreview } }),
            credentials: 'omit',
            headers: {
                Authorization: 'Bearer',
                'Content-Type': 'application/json'
            },
            host: '',
            method: 'POST',
            url: `https://graphql.contentful.com/content/v1/spaces/${contentfulSpace}`
        })
            .then(response => response.json())
            .then(({ data, errors }) => {
                if (errors) {
                    console.error('Contentful Errors', errors);
                    setErrors(data);
                } else if (data) {
                    setData(data);
                }
            })
            .catch(error => setErrors(error));
    }, [query]);

    return { data, errors };
};

export default useContentful;
