import { useContext } from 'react';

import { ProductCategoriesContext } from '@tb-core/components/context/product-categories';

const useProductCategoriesContext = () => {
    const ctx = useContext(ProductCategoriesContext);

    if (ctx === undefined) {
        throw new Error(
            'useProductCategoriesContext must be used within a ProductCategoriesProvider'
        );
    }

    return ctx;
};

export default useProductCategoriesContext;
