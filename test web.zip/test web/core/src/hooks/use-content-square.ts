import { datadogLogs } from '@datadog/browser-logs';

const source = '//t.contentsquare.net/wvt/web-view.js';

/*
 * Script loader
 * Iomport directly in Class Component for use in componentDidMount() method
 * to use in funcitonal component, call from useEffect
 */
export const loadContentSquareScript = () => {
    try {
        const scripts = document.getElementsByTagName('script');
        const existingScript = [].slice
            .call(scripts)
            .find((s: HTMLScriptElement) => s.src.includes(source));
        if (existingScript) {
            return existingScript;
        } else {
            const contentSquareScript = document.createElement('script');
            contentSquareScript.type = 'text/javascript';
            contentSquareScript.async = true;
            contentSquareScript.src = source;
            document
                .getElementsByTagName('head')[0]
                .appendChild(contentSquareScript);
        }
    } catch (error) {
        const errorMsg = JSON.stringify({
            error: `Error creating content square script, ${error}`
        });
        datadogLogs.logger.log(
            'Setting content square script failed',
            { errorMsg },
            'error'
        );
    }
};
