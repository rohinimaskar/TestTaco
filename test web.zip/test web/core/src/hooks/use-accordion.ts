import { useReducer } from 'react';

interface UseAccordionProps {
    reducer: (
        openIndices: number[],
        action: { type: string; index: number }
    ) => number[];
}

export const actionTypes = { toggleIndex: 'toggleIndex' };

export function useAccordion(props: UseAccordionProps) {
    const [openIndices, dispatch] = useReducer(props.reducer, []);

    const toggleIndex = (index: number) => {
        dispatch({ index, type: actionTypes.toggleIndex });
    };

    return { openIndices, toggleIndex };
}
