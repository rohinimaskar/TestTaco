import { useState } from 'react';

/**
 * A count tracker which provides remaining count feedback ranging 0 to maxCount.
 * @param maxCount The count maximum value.
 * @param usedCount The count already used of the maximum.
 * @example
 *      const maxCount = 5;
 *      const { count, setCount } = useCounter(maxCount, 0);
 *
 *      return (<>
 *          <p>{count} of {maxCount}</p>
 *          <button onClick={() => setCount(count + 1)}>Increase Count</button>
 *      </>);
 */
export const useCounter: (
    maxCount?: number,
    usedCount?: number
) => [number, (usedCount: number) => void] = (maxCount = 0, usedCount = 0) => {
    const countResolver = (used = 0) =>
        Math.max(0, Math.min(maxCount, maxCount - used));
    const [count, setCount] = useState(countResolver(usedCount));

    function dispatch(used: number) {
        setCount(countResolver(used));
    }

    return [count, dispatch];
};
