import { useContext } from 'react';

import { MiniCartContext } from '@tb-core/components/context/mini-cart';

const useMiniCartContext = () => {
    const ctx = useContext(MiniCartContext);

    if (ctx === undefined) {
        throw new Error(
            'useMiniCartContext must be used within a MiniCartProvider'
        );
    }

    return ctx;
};

export default useMiniCartContext;
