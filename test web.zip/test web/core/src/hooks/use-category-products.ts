import { useEffect, useState } from 'react';

import { isValidMenu } from '@tb-core/components/context/menu';
import useMenuContext from '@tb-core/hooks/use-menu-context';
import { MenuProductCategory, ProductItem } from '@tb-core/types/products';

/**
 * Not used anywhere in the code base currently.
 * Possibly because menuPropsUtil() does same thing as this?
 *
 * A products tracker which provides the menu products of a given product category.
 * @param category the product category
 * @example
 *      const [products, setProducts] = useCategoryProducts();
 */
export const useCategoryProducts: (
    category: string
) => [ProductItem[], (products: ProductItem[]) => void] = category => {
    const [products, setProducts] = useState<ProductItem[]>([]);
    const menu = useMenuContext();

    useEffect(() => {
        if (isValidMenu(menu)) {
            const categoryMenu = menu.menuProductCategories.find(
                (cat: MenuProductCategory) =>
                    cat.code.toLowerCase() === category.toLowerCase()
            );

            if (categoryMenu && categoryMenu?.products) {
                setProducts(categoryMenu.products);
            }
        }
    }, [menu]);

    return [products, setProducts];
};
