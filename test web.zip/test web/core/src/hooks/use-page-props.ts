import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';

import { ProductCategoriesProviderProps } from '@tb-core/components/context/product-categories';
import { PageContextProps } from '@tb-core/components/context/webpage';
import pagePropsUtil from '@tb-core/helpers/contentful/page-props-util';

const usePageProps = (
    pageProps:
        | (PageContextProps & Partial<ProductCategoriesProviderProps>)
        | { notFound: boolean }
) => {
    const router = useRouter();
    const [props, setProps] = useState(pageProps);
    const getPageProps = async () => {
        // Client-side data-fetching.
        setProps(await pagePropsUtil(router.asPath, {}));
    };

    useEffect(() => {
        if (!props) {
            getPageProps();
        }
    }, [props]);

    return props;
};

export default usePageProps;
