import { useEffect, useState } from 'react';

import getLambdaSessionToken from '@tb-core/helpers/get-lambda-session-token';
import GetPlaceDetailAddressComponents from '@tb-core/helpers/get-place-detail-address-components';
import postPlaces from '@tb-core/providers/post-places';
import { LatLong, PlaceDetailsResponseProps } from '@tb-core/types/location';

interface ZipAddress {
    address: string;
    latLong: Partial<LatLong>;
    zip: string;
}

export const useZipAddress: () => [
    ZipAddress,
    (placeId: string) => void
] = () => {
    const defaultZipAddress = {
        address: '',
        latLong: {},
        zip: ''
    };

    const [placeId, setPlaceId] = useState('');
    const [zipAddress, setZipAddress] = useState(defaultZipAddress);

    useEffect(() => {
        if (placeId) {
            // Need await inside of an async function
            async function setPlace() {
                const res: PlaceDetailsResponseProps = await postPlaces({
                    place_id: placeId,
                    sessiontoken: getLambdaSessionToken()
                });

                const zipAddress = {
                    address: GetPlaceDetailAddressComponents({
                        components: res.address_components,
                        types: [
                            { level: 'locality', value: 'long_name' },
                            {
                                level: 'administrative_area_level_1',
                                value: 'short_name'
                            }
                        ]
                    }),
                    latLong: {
                        lat: res.geometry?.location.lat,
                        long: res.geometry?.location.lng
                    },
                    zip: GetPlaceDetailAddressComponents({
                        components: res.address_components,
                        types: [{ level: 'postal_code', value: 'long_name' }]
                    })
                };
                setZipAddress(zipAddress);
            }
            setPlace();
        }
    }, [placeId]);

    return [zipAddress, setPlaceId];
};
