export interface SuccessProps {
    coords: any;
    timestamp: number;
}
export interface FailProps {
    code: number;
    message: string;
}

interface OptionProps {
    enableHighAccuracy: boolean;
    maximumAge: number;
    timeout: number;
}

/**
 * A hook for using Navigator.geolocation. Get the user's Lat/Long, if allowed.
 * @example
 *      import { useGeoLocation } from '@tb-core/hooks';
 *
 *      useGeoLocation().then(res => res);
 */

export const useGeoLocationLegacy = () => {
    const options: OptionProps = {
        enableHighAccuracy: false,
        maximumAge: 30000,
        timeout: 3000
    };

    const promise = new Promise<SuccessProps>((resolve, reject) => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position: SuccessProps) => {
                    if (position) {
                        resolve(position);
                    }
                },
                (err: FailProps) => {
                    if (err) {
                        reject(err);
                    }
                },
                options
            );
        }

        if (!navigator.geolocation) {
            reject({ code: -1, message: 'Navigator not found' });
        }
    });

    return promise;
};
