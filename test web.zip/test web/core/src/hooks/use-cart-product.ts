import { useState } from 'react';

import { CartProductContextProps } from '@tb-core/components/context/cart-product';
import { ComboItem } from '@tb-core/components/products/styled/combo-item-card/combo-item-card';
import { getProductTotalCalories } from '@tb-core/helpers/products/calories';
import {
    getDefaultProduct,
    isFoodItem
} from '@tb-core/helpers/products/combo-item';
import {
    isCombo,
    isDrink,
    isPartyPack
} from '@tb-core/helpers/products/product-types';
import { Option } from '@tb-core/hooks/product/use-customize';
import { RealObject } from '@tb-core/types';
import { Price, Product } from '@tb-core/types/products';

export interface CartProductDetails {
    // TODO: extend to one of the types in core/src/client-side-cart.d.ts
    calories: string;
    groupCode?: string;
    plu: string;
    price: number;
    qty?: number;
    selectedOptions?: Option[];
}

export interface CartProductItem
    extends Omit<CartProductDetails, 'plu' | 'price'> {
    code: string;
    groupID?: string;
    isBYOB?: boolean;
    // TODO: Merge price and priceData and create an adapter for the
    //       hybris data so standard and drink can use the same price
    //       property
    // price and priceData are to account for standard/drink
    price?: RealObject;
    priceData?: Price;
    productGroups?: ComboItem[]; // optional because it is optional inside the `Product` interface.
}

export type UpdateProductList = (args: {
    index?: number;
    item: CartProductItem;
    productType?: string;
    qty?: number;
}) => void;

export type UpdateItem = (item: CartProductItem) => CartProductDetails;

export type CalculateProductTotals = (args: {
    isComboProduct: boolean;
    product: Product;
    qty?: number;
}) => void;

export interface ProductTotals {
    calories: string;
    plu: string;
    price: number;
    qty: number;
}

const updateDrink: UpdateItem = item => {
    const product: CartProductDetails = {
        calories: item.calories,
        groupCode: item.groupID,
        plu: item.code,
        price: item.priceData?.value || 0
    };

    if (item.qty) {
        product.qty = item.qty;
    }

    return product;
};

const updateStandard: UpdateItem = item => {
    const product: CartProductDetails = {
        calories: item.calories,
        groupCode: item.groupID,
        plu: item.code,
        price: item.price?.value || 0,
        selectedOptions: item?.selectedOptions || []
    };

    if (item.qty) {
        product.qty = item.qty;
    }
    return product;
};

const useCartProduct = (): CartProductContextProps => {
    const [productList, setProductList] = useState<CartProductDetails[]>([]);
    const [productTotals, setProductTotals] = useState<ProductTotals>({
        calories: '',
        plu: '',
        price: 0,
        qty: 0
    });

    const calculateProductTotals: CalculateProductTotals = ({
        isComboProduct,
        product,
        qty = 1
    }) => {
        let totalPrice = isComboProduct ? product?.price?.value || 0 : 0;
        const productGroups = product?.productGroups;

        productList.forEach(
            (cartProductDetail: CartProductDetails, index: number) => {
                const cartProductPrice = cartProductDetail?.price ?? 0;
                const options = cartProductDetail?.selectedOptions;
                let sum = 0;

                if (productList.length > 1 && options?.length) {
                    options.forEach(option => {
                        sum += option.includedWithStyle ? 0 : option.price;
                    });
                }

                const quantity = productGroups?.[index]?.defaultQuantity ?? 1;
                totalPrice += (cartProductPrice + sum) * quantity;
            }
        );

        let calories = getProductTotalCalories([...productList]);

        if (isPartyPack(product.productType)) {
            let min = Number(productList[0].calories);
            let max = Number(productList[0].calories);
            productList.forEach(product => {
                min = Math.min(min, Number(product.calories));
                max = Math.max(max, Number(product.calories));
            });
            calories = min !== max ? `${min}-${max}` : String(min);
        }

        if (Object.keys(productTotals).length) {
            setProductTotals({
                ...productTotals,
                calories,
                price: totalPrice,
                qty
            });
        }
    };

    const updateProductList: UpdateProductList = ({
        index = 0,
        item,
        productType,
        qty = 1
    }) => {
        const isComboProduct = !!productType && isCombo(productType);
        const isDrinkProduct = !!productType && isDrink(productType);
        // initialize the state
        if (isComboProduct && productList.length === 0) {
            // calories and qty are updated as changed but price reflects the
            // base price for the combo and will be used to calculate the
            // total price as different products are swapped
            setProductTotals({
                calories: item.calories,
                plu: item.code,
                price: item.price?.value || 0,
                qty
            });
            // each object represents a product (drink always first)
            const productGroupList =
                item.productGroups?.map(productGroup => {
                    const defaultProduct = getDefaultProduct(productGroup);
                    const data: CartProductDetails = {
                        calories: defaultProduct.calories,
                        plu: item?.isBYOB ? '' : defaultProduct.code,
                        price: 0,
                        qty: productGroup.defaultQuantity || 1
                    };

                    // Add the groupID to the productList data when present. In combos.
                    if (productGroup.groupID) {
                        data.groupCode = productGroup.groupID;
                    }
                    // add selectedOptions if a food product
                    if (isFoodItem(productGroup)) {
                        data.selectedOptions = [];
                    }

                    return data;
                }) || [];

            setProductList(productGroupList);
        } else if (!isComboProduct && productList.length === 0) {
            setProductTotals({
                calories: item.calories,
                plu: item.code,
                price: item.price?.value || 0,
                qty: 1
            });
            productList[index] = isDrinkProduct
                ? updateDrink(item)
                : updateStandard(item);
            setProductList([...productList]);
        } else {
            productList[index] = isDrinkProduct
                ? updateDrink(item)
                : updateStandard(item);
            setProductList([...productList]);
        }
    };

    const clearProductList = () => {
        setProductList([]);
    };

    return {
        calculateProductTotals,
        clearProductList,
        productList,
        productTotals,
        setProductList: updateProductList,
        setProductTotals
    };
};

export default useCartProduct;
