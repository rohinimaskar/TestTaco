const path = require('path');
const fs = require('fs');
const StylelintPlugin = require('stylelint-webpack-plugin');
const withBundleAnalyzer = require('@next/bundle-analyzer')({
    enabled: ['browser', 'server', 'both'].includes(process.env.BUNDLE_ANALYZE)
});

const CWD = process.cwd();
const { IS_DEV, IS_DEV_ALL, IS_PROD } = require(path.join(
    CWD,
    'utils/env-level'
));

// Set the environment variables.
const processEnv = require(path.join(CWD, 'utils/process-env'));

if (IS_DEV || IS_DEV_ALL) {
    processEnv(path.resolve(CWD, '.env'));
} else if (
    IS_PROD &&
    fs.existsSync(path.resolve(CWD, '.env.production.local'))
) {
    processEnv(path.resolve(CWD, '.env.production.local'));
}

processEnv(path.resolve(CWD, '.config'), path.resolve(__dirname, '.config'));

const {
    AMPLITUDE_EXPERIMENT_DEPLOYMENT_KEY,
    AMPLITUDE_KEY,
    API_HOST,
    ASSET_PATH = '',
    BASE_PATH,
    BRAZE_ENABLED,
    BRAZE_HOST,
    BRAZE_KEY,
    CSC_ENABLED,
    LOYALTY_LIFETIME_POINTS_ENABLED,
    CTF_ENV,
    CTF_HOST,
    CTF_SPACE_ID,
    CTF_TOKEN,
    DATA_DOG_ENV,
    ENV_ID,
    FAVORITES_ENABLED,
    GA_GLOBAL_ID,
    GA_ID,
    GOOGLE_TAG_MANAGER_ID,
    MOCKS,
    NEXT_API_HOST,
    SERVERLESS_API_URL,
    STORE_NATIONAL_ID,
    TB_API_HOST,
    WEB_ORIGIN,
    WEB_FIXED_VERSION,
    YUM_AUTH_URL,
    YUM_OIDC_CLIENT_ID,
    YUM_OIDC_CLIENT_ID_PASSWORDLESS,
    YUM_OIDC_CLIENT_NAME,
    YUM_OIDC_ENVIRONMENT
} = process.env;

// Configure environment-specific SASS variables.
const sassConfig = require(path.join(CWD, 'utils/sass-config'));
sassConfig(path.join(path.resolve(CWD, 'core/src/styles'), '_env.scss'), {
    'asset-path': ASSET_PATH
});

// Get the Next.js routes.
const routes = require('./routes');

module.exports = withBundleAnalyzer({
    transpilePackages: [path.resolve(__dirname, '../core')],
    assetPrefix: IS_PROD || IS_DEV_ALL ? BASE_PATH : '',
    basePath: IS_PROD || IS_DEV_ALL ? BASE_PATH : '',
    // Available server-side only (via process.env[key])
    env: {
        AMPLITUDE_EXPERIMENT_DEPLOYMENT_KEY,
        AMPLITUDE_KEY,
        API_HOST,
        ASSET_PATH,
        BASE_PATH,
        BRAZE_ENABLED,
        BRAZE_HOST,
        BRAZE_KEY,
        CSC_ENABLED,
        LOYALTY_LIFETIME_POINTS_ENABLED,
        CTF_ENV,
        CTF_HOST,
        CTF_SPACE_ID,
        CTF_TOKEN,
        DATA_DOG_ENV,
        ENV_ID,
        FAVORITES_ENABLED,
        GA_GLOBAL_ID,
        GA_ID,
        GOOGLE_TAG_MANAGER_ID,
        MOCKS,
        NEXT_API_BASE_PATH: IS_PROD ? BASE_PATH : '',
        NEXT_API_HOST,
        ROUTES: JSON.stringify(routes),
        SERVERLESS_API_URL,
        STORE_NATIONAL_ID,
        TB_API_HOST,
        WEB_FIXED_VERSION,
        WEB_ORIGIN,
        YUM_AUTH_URL,
        YUM_OIDC_CLIENT_ID,
        YUM_OIDC_CLIENT_ID_PASSWORDLESS,
        YUM_OIDC_CLIENT_NAME,
        YUM_OIDC_ENVIRONMENT
    },
    onDemandEntries: {
        maxInactiveAge: 120 * 1000,
        pagesBufferLength: 2
    },
    sassOptions: {
        includePaths: [
            path.resolve(CWD, 'core/src/styles'),
            path.resolve(CWD, 'profile/src/styles')
        ]
    },
    swcMinify: true,
    webpack(config, { defaultLoaders }) {
        config.plugins.push(
            new StylelintPlugin({
                fix: true,
                configFile: path.join(CWD, './.stylelintrc')
            })
        );

        return {
            ...config,
            module: {
                ...config.module,
                rules: [...config.module.rules]
            },

            output: {
                ...config.output,
                publicPath: path.resolve(CWD, 'core/src/public')
            },
            resolve: {
                ...config.resolve,
                alias: {
                    ...config.resolve.alias,
                    '@tb-core': path.join(CWD, 'core/src'),
                    '@tb-core/data': path.join(CWD, 'core/src/.data'),
                    '@tb-profile': path.join(CWD, 'tb-profile/src')
                },
                extensions: ['.js', '.ts', '.tsx', '.css', '.scss'],
                fallback: {
                    fs: false,
                    stream: require.resolve('stream-browserify'),
                    vm: require.resolve('vm-browserify')
                }
            }
        };
    }
});
