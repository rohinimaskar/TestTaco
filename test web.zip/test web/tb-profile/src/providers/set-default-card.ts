import { datadogLogs } from '@datadog/browser-logs';
import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import { getAccessToken } from '@tb-core/helpers/client/auth';
import Fetch from '@tb-core/helpers/fetch';
import { setProviderUrl } from '@tb-core/helpers/utils/set-provider-url';
import { setDefaultCreditCardUrl } from '@tb-core/next/api/urls';

export async function setDefaultCreditCard(paymentId: string) {
    let res: Response;
    const accessToken = await getAccessToken();
    const url = devProxyResolve(setProviderUrl(setDefaultCreditCardUrl), {
        paymentId
    });
    try {
        res = await Fetch({
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            },
            host: '',
            method: 'POST',
            url
        });
    } catch (error) {
        datadogLogs.logger.log(
            'Set card default request failed!',
            { error },
            'error'
        );
        return { success: false };
    }

    if (!res.ok) {
        return { ...(await res.json()), success: false };
    }

    return {
        ...(await res.json()),
        success: true
    };
}
