import { datadogLogs } from '@datadog/browser-logs';
import { getLowToken } from '@tb-core/helpers/client/auth';
import Fetch, { toError } from '@tb-core/helpers/fetch';
import { serverlessApiUrl } from '@tb-core/helpers/next-env';
import { customerNotificationsUrl } from '@tb-core/next/api/urls';
import { FetchResponse } from '@tb-core/types';
import { NotificationPreferences, Preference } from '@tb-profile/types';

export default async function putUserNotifications(
    values: Preference[]
): FetchResponse<NotificationPreferences> {
    let res: Response;
    const lowToken = await getLowToken();

    try {
        res = await Fetch({
            body: JSON.stringify({
                preferences: values
            }),
            headers: {
                Authorization: `Bearer ${lowToken}`
            },
            host: '',
            method: 'PUT',
            url: serverlessApiUrl + customerNotificationsUrl
        });
    } catch (e) {
        const error = toError(e);
        console.error('User notification put request failed!', error);
        datadogLogs.logger.log('putUserNotifications', error, 'error');
        return { success: false };
    }

    if (!res.ok) {
        const error = await res.json();
        datadogLogs.logger.log('putUserNotifications', error, 'error');
        return { ...error, success: false };
    }

    return { ...(await res.json()), success: true };
}
