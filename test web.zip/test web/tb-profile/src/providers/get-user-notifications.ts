import { datadogLogs } from '@datadog/browser-logs';
import { getLowToken } from '@tb-core/helpers/client/auth';
import Fetch, { toError } from '@tb-core/helpers/fetch';
import { serverlessApiUrl } from '@tb-core/helpers/next-env';
import { customerNotificationsUrl } from '@tb-core/next/api/urls';
import { FetchResponse } from '@tb-core/types';
import { NotificationPreferences } from '@tb-profile/types';

export default async function getUserNotifications(): FetchResponse<
    NotificationPreferences
> {
    let res: Response;
    const lowToken = await getLowToken();

    try {
        res = await Fetch({
            headers: {
                Authorization: `Bearer ${lowToken}`
            },
            host: '',
            method: 'GET',
            url: serverlessApiUrl + customerNotificationsUrl
        });
    } catch (e) {
        const error = toError(e);
        console.error('User notification get request failed!', error);
        datadogLogs.logger.log('getUserNotifications', error, 'error');
        return { success: false };
    }

    if (!res.ok) {
        const error = await res.json();
        datadogLogs.logger.log('getUserNotifications', error, 'error');
        return { ...error, success: false };
    }

    return { ...(await res.json()), success: true };
}
