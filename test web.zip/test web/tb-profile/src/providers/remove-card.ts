import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import { getAccessToken } from '@tb-core/helpers/client/auth';
import Fetch from '@tb-core/helpers/fetch';
import { setProviderUrl } from '@tb-core/helpers/utils/set-provider-url';
import { removeCreditCardUrl, removeGiftCardUrl } from '@tb-core/next/api/urls';

export async function removeCreditCard(creditCardId: string) {
    let res: Response;
    const accessToken = await getAccessToken();
    const url = devProxyResolve(setProviderUrl(removeCreditCardUrl), {
        creditCardId
    });

    try {
        res = await Fetch({
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            },
            host: '',
            method: 'DELETE',
            url
        });
    } catch (error) {
        console.error('Card Removal request failed!', error);
        return { success: false };
    }

    if (!res.ok) {
        return { ...(await res.json()), success: false };
    }

    return {
        success: true
    };
}

export async function removeGiftCard(giftCardId: string) {
    let res: Response;
    const accessToken = await getAccessToken();
    const url = devProxyResolve(setProviderUrl(removeGiftCardUrl), {
        giftCardId
    });

    try {
        res = await Fetch({
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            },
            host: '',
            method: 'DELETE',
            url
        });
    } catch (error) {
        console.error('Card Removal request failed!', error);
        return { success: false };
    }

    if (!res.ok) {
        return { ...(await res.json()), success: false };
    }

    return {
        success: true
    };
}
