import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import { getAccessToken } from '@tb-core/helpers/client/auth';
import Fetch from '@tb-core/helpers/fetch';
import { setProviderUrl } from '@tb-core/helpers/utils/set-provider-url';
import { getCustomerUrl } from '@tb-core/next/api/urls';
import { PatchPayloadValues, UserProfile } from '@tb-profile/types';

export default async function patchUserProfile(
    props: Partial<PatchPayloadValues>
) {
    let res: Response;
    const accessToken = await getAccessToken();
    const url = devProxyResolve(setProviderUrl(getCustomerUrl));

    try {
        res = await Fetch({
            body: JSON.stringify(props),
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            },
            host: '',
            method: 'PATCH',
            url
        });
    } catch (error) {
        console.error('User Profile request failed!', error);
        return { success: false };
    }

    if (!res.ok) {
        const error = await res.json();
        return { ...error, status: res.status, success: false };
    }

    return {
        ...((await res.json()) as Promise<UserProfile>),
        status: res.status,
        success: true
    };
}
