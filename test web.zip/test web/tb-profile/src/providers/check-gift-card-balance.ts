import { datadogLogs } from '@datadog/browser-logs';
import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import { getAccessToken } from '@tb-core/helpers/client/auth';
import Fetch, { toError } from '@tb-core/helpers/fetch';
import { setProviderUrl } from '@tb-core/helpers/utils/set-provider-url';
import { checkGiftCardBalanceUrl } from '@tb-core/next/api/urls';

export default async function checkGiftCardBalance(giftcard: string) {
    let res: Response;
    const accessToken = await getAccessToken();
    const url = devProxyResolve(setProviderUrl(checkGiftCardBalanceUrl));

    try {
        res = await Fetch({
            body: JSON.stringify({ giftcard }),
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'application/json'
            },
            host: '',
            method: 'POST',
            url
        });
    } catch (e) {
        const error = toError(e);
        console.error('Check giftcard balance request failed!', error);
        datadogLogs.logger.log('checkGiftCardBalance', error, 'error');
        return { success: false };
    }

    if (!res.ok) {
        const errors = await res.json();
        datadogLogs.logger.log('checkGiftCardBalance', errors, 'error');
        return { ...errors, success: false };
    }

    return {
        ...(await res.json()),
        success: true
    };
}
