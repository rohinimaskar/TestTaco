import { devProxyResolve } from '@tb-core/helpers/browser/dev-proxy-resolve';
import { getAccessToken } from '@tb-core/helpers/client/auth';
import Fetch from '@tb-core/helpers/fetch';
import { setProviderUrl } from '@tb-core/helpers/utils/set-provider-url';
import { getCustomerUrl } from '@tb-core/next/api/urls';
import { UserProfile } from '@tb-profile/types';

export default async function getUserProfile() {
    let res: Response;
    const url = devProxyResolve(setProviderUrl(getCustomerUrl));

    try {
        res = await Fetch({
            headers: {
                Authorization: `Bearer ${await getAccessToken()}`
            },
            host: '',
            method: 'GET',
            url
        });
    } catch (error) {
        console.error('User profile request failed!', error);
        return { success: false };
    }

    if (!res.ok) {
        const error = await res.json();
        return { ...error, success: false };
    }

    return res.json() as Promise<UserProfile>;
}
