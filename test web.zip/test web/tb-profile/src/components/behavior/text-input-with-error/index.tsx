import TextInput, { Input } from '@tb-core/components/behavior/text-input';
import InputWithError from '@tb-core/components/styled/input-with-error';
import { UserInputResponseError } from '@tb-profile/types';

import styles from './styles.module.scss';

export interface InputError {
    firstName: string;
    lastName: string;
    phoneNumber: string;
}

export interface TextInputWithError extends Input {
    errors?: UserInputResponseError[];
    error?: InputError;
    hasError?: boolean;
}

const TextInputWithError = ({
    errors,
    id,
    label,
    onChange,
    value,
    hasError = false,
    error,
    ...props
}: TextInputWithError) => {
    return (
        <div className={styles.wrapper}>
            <InputWithError
                error={hasError}
                message={error?.[id as keyof typeof error]}
                name={label}
                className={styles['error-no-margin']}
            >
                <TextInput
                    {...{
                        id,
                        label,
                        onChange,
                        value,
                        ...props
                    }}
                />
            </InputWithError>
        </div>
    );
};

export default TextInputWithError;
