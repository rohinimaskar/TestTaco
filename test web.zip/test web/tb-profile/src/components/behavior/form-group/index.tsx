import { ChangeEvent, FocusEvent } from 'react';

import BirthdaySelect from '@tb-profile/components/behavior/birthday-select';
import TextInputWithError from '@tb-profile/components/behavior/text-input-with-error';

export interface FormGroup {
    error?: any;
    hasError?: boolean;
    id: string;
    label: string;
    onBlur?: (e: FocusEvent<HTMLInputElement>) => void;
    onChange: (e: ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
    type?: string;
    userBirthday?: string;
    value?: string;
}

const FormGroup = ({
    id,
    label,
    onChange,
    userBirthday,
    value,
    ...props
}: FormGroup) =>
    id === 'birthday' ? (
        <BirthdaySelect
            {...{
                id,
                label,
                onChange,
                userBirthday,
                value,
                ...props
            }}
        />
    ) : (
        <TextInputWithError
            {...{
                disabled: id === 'birthday',
                id,
                label,
                onChange,
                value,
                ...props
            }}
        />
    );

export default FormGroup;
