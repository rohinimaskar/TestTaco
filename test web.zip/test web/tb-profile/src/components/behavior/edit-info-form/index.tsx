import { datadogLogs } from '@datadog/browser-logs';

import { ChangeEventHandler, FocusEvent, FormEvent, useState } from 'react';

import BrandedButton from '@tb-core/components/styled/buttons/branded-button';
import { MONTHS, monthsAndDays } from '@tb-core/constants/months';
import {
    NAME_REGEX,
    PHONE_NUMBER_REGEX_NO_PAREN
} from '@tb-core/constants/regex';
import { stripString } from '@tb-core/helpers/string';
import { formatBirthdayMMDDToISOString } from '@tb-core/helpers/utils/format-birthday';
import { formatPhoneNumber } from '@tb-core/helpers/utils/format-phone-number';
import FormGroup from '@tb-profile/components/behavior/form-group';
import Button from '@tb-profile/components/styled/button';
import patchUserProfile from '@tb-profile/providers/patch-user-profile';
import { PatchPayloadValues } from '@tb-profile/types';

import styles from './styles.module.scss';

export interface ProfileInformationModal {
    birthday: string;
    cancel: string;
    day: string;
    firstName: string;
    firstNameError: string;
    lastName: string;
    lastNameError: string;
    month: string;
    phoneNumber: string;
    phoneNumberError: string;
    profanityErrorMassage: string;
    save: string;
}
export interface EditInfoForm {
    onCloseEditInfoModal: ({
        refetchUserData
    }: {
        refetchUserData: boolean;
    }) => void;
    profileInformationModal: ProfileInformationModal;
    userBirthday?: string;
    userFirstName?: string;
    userLastName?: string;
    userPhoneNumber?: string;
}

const EditInfoForm = ({
    onCloseEditInfoModal,
    profileInformationModal,
    userBirthday,
    userFirstName,
    userLastName,
    userPhoneNumber
}: EditInfoForm) => {
    const {
        birthday,
        cancel,
        day,
        firstName,
        firstNameError,
        lastName,
        lastNameError,
        month,
        phoneNumber,
        phoneNumberError,
        profanityErrorMassage,
        save
    } = profileInformationModal;
    const [isProfanityFirstName, setIsProfanityFirstName] = useState(false);
    const [isProfanityLastName, setIsProfanityLastName] = useState(false);
    const inputErrors = {
        firstName: isProfanityFirstName
            ? profanityErrorMassage
            : firstNameError,
        lastName: isProfanityLastName ? profanityErrorMassage : lastNameError,
        phoneNumber: phoneNumberError
    };
    const [values, setValues] = useState<PatchPayloadValues>({
        firstName: userFirstName,
        lastName: userLastName,
        phoneNumber: userPhoneNumber
    });

    const [isValidPhoneNumber, setIsValidPhoneNumber] = useState(true);
    const [isValidFirstName, setIsValidFirstName] = useState(true);
    const [isValidLastName, setIsValidLastName] = useState(true);

    const onChange: ChangeEventHandler<
        HTMLInputElement | HTMLSelectElement
    > = e => {
        setValues({ ...values, [e.target.id]: e.target.value });
    };

    const onBlur = (e: FocusEvent<HTMLInputElement>) => {
        setValues({ ...values, [e.target.id]: e.target.value });
    };

    const onBlurPhoneNumber = (e: FocusEvent<HTMLInputElement>) => {
        if (e.target.value === '') {
            setIsValidPhoneNumber(true);
        } else {
            const strippedNumber = stripString(e.target.value);

            setIsValidPhoneNumber(
                PHONE_NUMBER_REGEX_NO_PAREN.test(strippedNumber)
            );
        }
        onBlur(e);
    };

    const onBlurFirstName = (e: FocusEvent<HTMLInputElement>) => {
        onBlur(e);
        setIsValidFirstName(NAME_REGEX.test(e.target.value));
    };

    const onBlurLastName = (e: FocusEvent<HTMLInputElement>) => {
        onBlur(e);
        setIsValidLastName(NAME_REGEX.test(e.target.value));
    };

    const patchUserData = async (values: Partial<PatchPayloadValues>) => {
        patchUserProfile(values)
            .then(data => {
                if (data.status === 412) {
                    if (data.errors[0].field === 'first_name') {
                        setIsProfanityFirstName(true);
                    } else if (data.errors[0].field === 'last_name') {
                        setIsProfanityLastName(true);
                    }
                } else if (data.success) {
                    onCloseEditInfoModal({ refetchUserData: true });
                }
            })
            .catch(error => {
                datadogLogs.logger.log('patchUserData', { error }, 'error');
            });
    };

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        setIsProfanityFirstName(false);
        setIsProfanityLastName(false);
        const updatedPayload: PatchPayloadValues = {};

        if (
            values.phoneNumber &&
            values.phoneNumber !== userPhoneNumber &&
            isValidPhoneNumber
        ) {
            updatedPayload.phoneNumber = stripString(values.phoneNumber);
        }

        if (
            values.firstName &&
            values.firstName !== userFirstName &&
            isValidFirstName
        ) {
            updatedPayload.firstName = values.firstName;
        }

        if (
            values.lastName &&
            values.lastName !== userLastName &&
            isValidLastName
        ) {
            updatedPayload.lastName = values.lastName;
        }

        if (!userBirthday && values.userBirthMonth && values.userBirthDay) {
            const birthMonth = monthsAndDays
                .map(obj => obj.month)
                .indexOf(values.userBirthMonth || MONTHS.JANUARY);

            updatedPayload.birthday = formatBirthdayMMDDToISOString(
                birthMonth,
                values.userBirthDay
            );
        }

        if (Object.keys(updatedPayload).length > 0) {
            patchUserData(updatedPayload);
        }
    };

    return (
        <div className={styles['form-wrapper']}>
            <form
                className={styles.form}
                id="edit-info"
                onSubmit={handleSubmit}
            >
                <div className={styles['inner-container']}>
                    <FormGroup
                        error={inputErrors}
                        hasError={!isValidFirstName || isProfanityFirstName}
                        id="firstName"
                        label={firstName}
                        onBlur={onBlurFirstName}
                        onChange={onChange}
                        value={values?.firstName || ''}
                    />
                    <FormGroup
                        error={inputErrors}
                        hasError={!isValidLastName || isProfanityLastName}
                        id="lastName"
                        label={lastName}
                        onBlur={onBlurLastName}
                        onChange={onChange}
                        value={values?.lastName || ''}
                    />
                </div>
                <div className={styles['inner-container']}>
                    <FormGroup
                        error={inputErrors}
                        hasError={!isValidPhoneNumber}
                        id="phoneNumber"
                        label={phoneNumber}
                        onBlur={onBlurPhoneNumber}
                        onChange={onChange}
                        value={formatPhoneNumber(values?.phoneNumber || '')}
                    />
                    <FormGroup
                        id="birthday"
                        label={birthday}
                        {...{
                            day,
                            month,
                            onChange,
                            userBirthday
                        }}
                    />
                </div>
                <BrandedButton className={styles.submit}>{save}</BrandedButton>
            </form>
            <Button
                onClick={() => onCloseEditInfoModal({ refetchUserData: false })}
                className={styles['cancel-button']}
            >
                {cancel}
            </Button>
        </div>
    );
};

export default EditInfoForm;
