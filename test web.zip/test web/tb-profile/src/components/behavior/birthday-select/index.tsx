import { ChangeEvent, useState } from 'react';

import { monthsAndDays } from '@tb-core/constants/months';
import { formatBirthdayMMDD } from '@tb-core/helpers/utils/format-birthday';
import TextInputWithError from '@tb-profile/components/behavior/text-input-with-error';

import styles from './styles.module.scss';

export interface BirthdaySelect {
    day?: string;
    id: string;
    label: string;
    month?: string;
    onChange: (e: ChangeEvent<HTMLSelectElement | HTMLInputElement>) => void;
    userBirthday?: string;
    value?: string;
}

const BirthdaySelect = ({
    day,
    id,
    label,
    month,
    onChange,
    userBirthday = '',
    value
}: BirthdaySelect) => {
    const [dayCount, setDayCount] = useState([...Array(32).keys()].slice(1));

    // On month change, update day dropdown to reflect correct amount of days in month.
    const captureMonthChange = (e: any) => {
        monthsAndDays.find(el => {
            if (el.month === e.target.value) {
                setDayCount([...Array(el.days + 1).keys()].slice(1));
            }
        });
        onChange(e);
    };

    return userBirthday ? (
        <TextInputWithError
            {...{
                disabled: true,
                id,
                label,
                onChange,
                placeholder: formatBirthdayMMDD(userBirthday),
                value
            }}
        />
    ) : (
        <div className={styles.wrapper}>
            <label className={styles['label-container']}>
                <span className={styles.label}>{label}</span>
                <select
                    className={styles.select}
                    onChange={onChange}
                    defaultValue={day}
                    id="userBirthDay"
                >
                    <option disabled className={styles.option}>
                        {day}
                    </option>
                    {dayCount &&
                        dayCount.map(val => (
                            <option key={`day-${val}`} value={val}>
                                {val}
                            </option>
                        ))}
                </select>
                <select
                    className={styles.select}
                    onChange={captureMonthChange}
                    defaultValue={month}
                    id="userBirthMonth"
                >
                    <option disabled className={styles.option}>
                        {month}
                    </option>
                    {/* {months && options(months)} */}
                    {monthsAndDays.map(({ month }) => (
                        <option key={`month-${month}`} value={month}>
                            {month}
                        </option>
                    ))}
                </select>
            </label>
        </div>
    );
};

export default BirthdaySelect;
