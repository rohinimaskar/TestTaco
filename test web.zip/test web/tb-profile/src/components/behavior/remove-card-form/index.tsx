import { datadogLogs } from '@datadog/browser-logs';
import { FormEvent } from 'react';

import BrandedButton from '@tb-core/components/styled/buttons/branded-button';
import Button from '@tb-profile/components/styled/button';
import {
    removeCreditCard,
    removeGiftCard
} from '@tb-profile/providers/remove-card';

import styles from './styles.module.scss';

interface RemoveCardModal {
    cancelLabel: string;
    confirmLabel: string;
}

export interface RemoveCardForm {
    cardId: string;
    onCloseRemoveCardModal: (refetchCard: boolean) => void;
    isGiftCard: boolean;
    removeCardModal: RemoveCardModal;
}

const RemoveCardForm = ({
    cardId,
    onCloseRemoveCardModal,
    isGiftCard,
    removeCardModal
}: RemoveCardForm) => {
    const deleteCard = async (cardId: string) => {
        if (isGiftCard) {
            removeGiftCard(cardId)
                .then(data => {
                    if (data.success) {
                        onCloseRemoveCardModal(true);
                    }
                    // TODO: add something to appear if the card removal fails.
                })
                .catch(error => {
                    datadogLogs.logger.log(
                        'removeGiftCard',
                        { error },
                        'error'
                    );
                });
        } else {
            removeCreditCard(cardId)
                .then(data => {
                    if (data.success) {
                        onCloseRemoveCardModal(true);
                    }
                    // TODO: add something to appear if the card removal fails.
                })
                .catch(error => {
                    datadogLogs.logger.log(
                        'removeCreditCard',
                        { error },
                        'error'
                    );
                });
        }
    };

    const handleCardRemovalSubmit = (e: FormEvent) => {
        e.preventDefault();
        deleteCard(cardId);
    };

    return (
        <div className={styles['form-wrapper']}>
            <form
                className={styles.form}
                id="remove-card"
                onSubmit={handleCardRemovalSubmit}
            >
                <BrandedButton className={styles.submit}>
                    {removeCardModal?.confirmLabel}
                </BrandedButton>
            </form>
            <Button
                className={styles['cancel-button']}
                onClick={() => onCloseRemoveCardModal(false)}
            >
                {removeCardModal?.cancelLabel}
            </Button>
        </div>
    );
};

export default RemoveCardForm;
