/**
 * isCreditCardExpired checks whether a credit card is expired
 * @param expMonth  number expired month value from 1-12
 * @param expYear   number expired year value in 4-digit
 * @returns boolean whether a provided credit card is expired
 */
export const isCreditCardExpired = (expMonth?: number, expYear?: number) => {
    if (!expMonth || !expYear) {
        return true;
    }

    const today = new Date();
    const expiryDate = new Date(expMonth + ' 1, ' + expYear + ', 00:00:00');

    return expiryDate < today;
};

export const expiryText = (isExpired: boolean): string =>
    isExpired ? 'Expired' : 'Exp';
