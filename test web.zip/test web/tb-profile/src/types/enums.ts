export enum PreferenceTypes {
    ACCOUNT_EMAIL = 'a-e',
    ACCOUNT_PUSH = 'a-p',
    ACCOUNT_SMS = 'a-s',
    MARKETING_EMAIL = 'm-e',
    MARKETING_PUSH = 'm-p',
    MARKETING_SMS = 'm-s',
    ORDER_EMAIL = 'o-e',
    ORDER_PUSH = 'o-p',
    ORDER_SMS = 'o-s'
}
