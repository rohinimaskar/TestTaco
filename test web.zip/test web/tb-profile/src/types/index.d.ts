import { MONTHS } from '@tb-core/constants/months';

import { PreferenceTypes } from '@tb-profile/types/enums';
export interface UpdateNotification {
    email: boolean;
    push: boolean;
    sms: boolean;
}

export interface AppPreferences {
    pushOptIn: boolean;
    smsOptIn: boolean;
    subscription: boolean;
}

export interface UserProfile {
    accountUpdateNotification: UpdateNotification;
    activationCode: string[];
    appPreferences: AppPreferences;
    birthday: string;
    customerID: string;
    displayUid: string;
    email: string;
    firstName: string;
    hasPassword: boolean;
    lastName: string;
    name: string;
    newsUpdateNotification: UpdateNotification;
    offersCount: string;
    orderUpdateNotification: UpdateNotification;
    ordersCount: string;
    phoneNumber: string;
    totalUnitCount: string;
    type: string;
    uid: string;
}

export interface Preference {
    key: PreferenceTypes;
    value: boolean;
}

export interface NotificationPreferences {
    preferences: Preference[];
}

export interface PatchPayloadValues {
    birthday?: string;
    firstName?: string;
    lastName?: string;
    phoneNumber?: string;
    userBirthDay?: number;
    userBirthMonth?: MONTHS;
}

export interface UserInputResponseError {
    message: string;
    reason: string;
    subject: string;
    subjectType: string;
    type: string;
}

export interface UserInputResponseError {
    message: string;
    reason: string;
    subject: string;
    subjectType: string;
    type: string;
}
