import '@tb-core/styles/base.scss';

export { default } from '@tb-core/next/pages/_app_guarded';
