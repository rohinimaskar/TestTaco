export { default } from '@tb-core/next/pages/_document';
