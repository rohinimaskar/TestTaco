export { default, getStaticProps } from '@tb-core/pages/404';
