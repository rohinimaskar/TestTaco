export { default } from '@tb-core/next/api/delete-auth-cookies';
