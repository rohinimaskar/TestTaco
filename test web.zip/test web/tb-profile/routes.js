module.exports = ['/account', '/account/*'];
